# 🚀 Real-Time Communication in Odoo - Complete Implementation Guide

This guide shows you how to implement real-time communication in Odoo modules using the built-in bus system. We'll cover both the database viewer enhancements and a complete auction system example.

## 📋 Table of Contents

1. [Overview](#overview)
2. [Odoo Bus System Architecture](#odoo-bus-system-architecture)
3. [Backend Implementation](#backend-implementation)
4. [Frontend Implementation](#frontend-implementation)
5. [Database Viewer Real-Time Features](#database-viewer-real-time-features)
6. [Auction System Example](#auction-system-example)
7. [Testing and Deployment](#testing-and-deployment)
8. [Best Practices](#best-practices)

## 🎯 Overview

Real-time communication in Odoo is achieved through the `bus.bus` system, which provides:
- WebSocket-based communication
- Channel-based messaging
- Automatic reconnection
- Security and authentication
- Scalable architecture

## 🏗️ Odoo Bus System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Bus Service   │    │   Backend       │
│   (JavaScript)  │◄──►│   (WebSocket)   │◄──►│   (Python)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Key Components:
- **bus.bus**: Core messaging system
- **bus_service**: JavaScript service for frontend
- **Channels**: Named communication channels
- **Notifications**: Structured message format

## 🔧 Backend Implementation

### 1. Basic Bus Integration

```python
from odoo.addons.bus.models.bus import dispatch
from odoo import models, fields

class MyModel(models.Model):
    _name = 'my.model'
    
    def send_realtime_update(self, message_type, data):
        """Send real-time update to connected clients"""
        try:
            self.env['bus.bus'].sendone(
                f'my_channel_{self.id}',
                {
                    'type': message_type,
                    'data': data,
                    'timestamp': fields.Datetime.now(),
                    'model_id': self.id
                }
            )
        except Exception as e:
            _logger.error(f"Error sending real-time update: {str(e)}")
```

### 2. Channel Naming Conventions

```python
# Global channel
'global_updates'

# Model-specific channel
'my_model_{record_id}'

# User-specific channel
'user_{user_id}'

# Custom channel
'custom_channel_name'
```

### 3. Message Structure

```python
{
    'type': 'message_type',           # Required: message category
    'data': {...},                    # Required: message payload
    'timestamp': fields.Datetime.now(), # Optional: timestamp
    'user_id': self.env.user.id,      # Optional: sender info
    'model_id': self.id               # Optional: related record
}
```

## 🎨 Frontend Implementation

### 1. Basic JavaScript Setup

```javascript
odoo.define('my_module.realtime', function (require) {
    'use strict';

    const busService = require('bus.bus_service');
    const { onWillStart, onWillDestroy, useService } = require('@web/core/utils/hooks');

    class MyRealtimeComponent {
        setup() {
            this.busService = useService("bus_service");
            
            onWillStart(() => {
                this._setupBusConnection();
            });
            
            onWillDestroy(() => {
                this._cleanupBusConnection();
            });
        }

        _setupBusConnection() {
            // Subscribe to channels
            const channels = ['my_channel_global'];
            
            channels.forEach(channel => {
                this.busService.addChannel(channel);
            });

            // Listen for notifications
            this.busService.on("notification", this, (notifications) => {
                notifications.forEach((notif) => {
                    this._handleNotification(notif);
                });
            });
        }

        _handleNotification(notification) {
            const { payload } = notification;
            
            switch (payload.type) {
                case 'update':
                    this._handleUpdate(payload.data);
                    break;
                case 'notification':
                    this._showNotification(payload.data);
                    break;
                default:
                    console.log('Unknown notification type:', payload.type);
            }
        }

        _cleanupBusConnection() {
            if (this.busService) {
                this.busService.off("notification", this);
            }
        }
    }

    return MyRealtimeComponent;
});
```

### 2. Toast Notifications

```javascript
_showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${this._getToastColor(type)};
        color: white;
        padding: 12px 20px;
        border-radius: 5px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        max-width: 300px;
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 5000);
}

_getToastColor(type) {
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    };
    return colors[type] || colors.info;
}
```

## 🔍 Database Viewer Real-Time Features

### Enhanced Features Added:

1. **Real-time Connection Status**
   - Notifications when database connections are tested
   - Success/error messages for all users

2. **Table Activity Tracking**
   - Notifications when tables are viewed
   - User activity tracking across sessions

3. **Live Updates**
   - Real-time notifications for database operations
   - Channel-based communication per database viewer

### Implementation:

```python
# In models/database_viewer.py
def notify_table_update(self, table_name, action='viewed'):
    """Notify when a table is accessed"""
    self.send_realtime_update('table_activity', {
        'table_name': table_name,
        'action': action,
        'user': self.env.user.name,
        'database': self.database
    })

def notify_connection_status(self, status, message):
    """Notify connection status changes"""
    self.send_realtime_update('connection_status', {
        'status': status,
        'message': message,
        'database': self.database
    })
```

## 🏆 Auction System Example

### Complete Real-Time Auction System

The auction system demonstrates:
- Real-time bidding
- Live price updates
- Participant tracking
- Countdown timers
- Winner determination

### Key Features:

1. **Real-time Bidding**
   ```python
   def place_bid(self, bidder_id, amount):
       # Validate bid
       if amount <= self.current_price:
           raise UserError(_('Bid must be higher than current price'))
       
       # Create bid
       bid = self.env['auction.bid'].create({
           'auction_id': self.id,
           'bidder_id': bidder_id,
           'amount': amount
       })
       
       # Send real-time notification
       self._send_bid_update(bid)
       
       return bid
   ```

2. **Live Auction Page**
   - WebSocket connection for real-time updates
   - Live countdown timer
   - Real-time bid list updates
   - Toast notifications for new bids

3. **Auction Management**
   - Start/end auctions
   - Reserve price validation
   - Winner determination
   - Status tracking

## 🧪 Testing and Deployment

### 1. Testing Real-time Features

```python
# Test bus communication
def test_bus_communication(self):
    viewer = self.env['database.viewer'].create({
        'name': 'Test DB',
        'host': 'localhost',
        'database': 'test_db',
        'username': 'test',
        'password': 'test'
    })
    
    # Test notification
    viewer.notify_table_update('test_table')
    
    # Verify bus message was sent
    bus_messages = self.env['bus.bus'].search([
        ('channel', '=', f'database_viewer_{viewer.id}')
    ])
    self.assertTrue(bus_messages)
```

### 2. Frontend Testing

```javascript
// Test bus connection
test('Bus connection setup', function(assert) {
    const component = new MyRealtimeComponent();
    component.setup();
    
    assert.ok(component.busService, 'Bus service should be available');
    assert.ok(component.state.isConnected, 'Should be connected to bus');
});
```

### 3. Deployment Considerations

- **Scaling**: Bus system supports multiple workers
- **Security**: All messages go through Odoo's security layer
- **Performance**: Messages are queued and processed efficiently
- **Monitoring**: Log bus activity for debugging

## 📚 Best Practices

### 1. Channel Management

```python
# Good: Specific channels
'auction_123'  # Specific auction
'user_456'     # Specific user

# Avoid: Too broad channels
'global'       # Too many messages
'all'          # Performance issues
```

### 2. Message Structure

```python
# Good: Structured messages
{
    'type': 'bid_placed',
    'data': {
        'auction_id': 123,
        'bidder_name': 'John Doe',
        'amount': 100.50
    },
    'timestamp': fields.Datetime.now()
}

# Avoid: Unstructured data
{
    'message': 'New bid placed',
    'details': 'John bid $100.50'
}
```

### 3. Error Handling

```python
def send_realtime_update(self, message_type, data):
    try:
        self.env['bus.bus'].sendone(
            f'channel_{self.id}',
            {
                'type': message_type,
                'data': data,
                'timestamp': fields.Datetime.now()
            }
        )
    except Exception as e:
        _logger.error(f"Error sending real-time update: {str(e)}")
        # Don't break the main flow
```

### 4. Performance Optimization

```python
# Batch updates when possible
def send_batch_updates(self, updates):
    for update in updates:
        self.env['bus.bus'].sendone(
            'batch_updates',
            update
        )

# Use appropriate channels
def send_user_specific_update(self, user_id, data):
    self.env['bus.bus'].sendone(
        f'user_{user_id}',
        data
    )
```

## 🚀 Getting Started

### 1. Install Dependencies

```bash
# Ensure bus module is installed
pip install odoo-bus
```

### 2. Update Manifest

```python
# __manifest__.py
{
    'depends': ['base', 'web', 'bus'],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/js/realtime.js',
        ],
    },
}
```

### 3. Create Models

```python
# models/my_model.py
from odoo.addons.bus.models.bus import dispatch

class MyModel(models.Model):
    _name = 'my.model'
    
    def send_update(self, data):
        self.env['bus.bus'].sendone(
            f'my_model_{self.id}',
            {'type': 'update', 'data': data}
        )
```

### 4. Create JavaScript

```javascript
// static/src/js/realtime.js
odoo.define('my_module.realtime', function (require) {
    const busService = require('bus.bus_service');
    // ... implementation
});
```

## 📖 Additional Resources

- [Odoo Bus Documentation](https://www.odoo.com/documentation/18.0/developer/reference/addons/bus.html)
- [WebSocket Implementation](https://www.odoo.com/documentation/18.0/developer/reference/addons/websocket.html)
- [Real-time Examples](https://github.com/odoo/odoo/tree/18.0/addons/bus)

## 🤝 Support

For questions and support:
- Check the Odoo documentation
- Review the bus module source code
- Test with simple examples first
- Monitor logs for debugging

---

**Happy Real-time Coding! 🎉** 