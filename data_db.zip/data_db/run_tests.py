#!/usr/bin/env python3
"""
Test Runner for Database Data Viewer Module
This script runs all tests and generates a comprehensive report.
"""

import sys
import os
import unittest
import time
from datetime import datetime

def run_tests():
    """Run all tests and generate a report"""
    
    print("🔍 Database Data Viewer Module - Test Suite")
    print("=" * 60)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Add the module path to sys.path
    module_path = os.path.dirname(os.path.abspath(__file__))
    if module_path not in sys.path:
        sys.path.insert(0, module_path)
    
    # Discover and run tests
    loader = unittest.TestLoader()
    start_dir = os.path.join(module_path, 'tests')
    
    if not os.path.exists(start_dir):
        print("❌ Tests directory not found!")
        return False
    
    # Discover tests
    suite = loader.discover(start_dir, pattern='test_*.py')
    
    if not suite.countTestCases():
        print("❌ No tests found!")
        return False
    
    print(f"📋 Found {suite.countTestCases()} test cases")
    print()
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    start_time = time.time()
    
    try:
        result = runner.run(suite)
        end_time = time.time()
        
        # Generate report
        print()
        print("=" * 60)
        print("📊 TEST RESULTS SUMMARY")
        print("=" * 60)
        
        total_tests = result.testsRun
        failures = len(result.failures)
        errors = len(result.errors)
        skipped = len(result.skipped) if hasattr(result, 'skipped') else 0
        
        print(f"Total Tests Run: {total_tests}")
        print(f"Passed: {total_tests - failures - errors - skipped}")
        print(f"Failed: {failures}")
        print(f"Errors: {errors}")
        print(f"Skipped: {skipped}")
        print(f"Success Rate: {((total_tests - failures - errors - skipped) / total_tests * 100):.1f}%")
        print(f"Execution Time: {end_time - start_time:.2f} seconds")
        
        # Show failures
        if failures > 0:
            print()
            print("❌ FAILURES:")
            print("-" * 30)
            for test, traceback in result.failures:
                print(f"• {test}: {traceback.split('AssertionError:')[-1].strip()}")
        
        # Show errors
        if errors > 0:
            print()
            print("💥 ERRORS:")
            print("-" * 30)
            for test, traceback in result.errors:
                print(f"• {test}: {traceback.split('Exception:')[-1].strip()}")
        
        # Show skipped tests
        if skipped > 0:
            print()
            print("⏭️  SKIPPED:")
            print("-" * 30)
            for test, reason in result.skipped:
                print(f"• {test}: {reason}")
        
        print()
        print("=" * 60)
        
        if failures == 0 and errors == 0:
            print("✅ ALL TESTS PASSED!")
            return True
        else:
            print("❌ SOME TESTS FAILED!")
            return False
            
    except Exception as e:
        print(f"💥 Error running tests: {str(e)}")
        return False

def run_specific_test(test_name):
    """Run a specific test by name"""
    print(f"🔍 Running specific test: {test_name}")
    print("=" * 60)
    
    # Add the module path to sys.path
    module_path = os.path.dirname(os.path.abspath(__file__))
    if module_path not in sys.path:
        sys.path.insert(0, module_path)
    
    # Create test suite for specific test
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Try to load the specific test
    try:
        test = loader.loadTestsFromName(test_name)
        suite.addTest(test)
    except Exception as e:
        print(f"❌ Could not load test '{test_name}': {str(e)}")
        return False
    
    # Run the test
    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)
    
    return len(result.failures) == 0 and len(result.errors) == 0

def run_security_tests():
    """Run security-focused tests"""
    print("🔒 Running Security Tests")
    print("=" * 60)
    
    # Add the module path to sys.path
    module_path = os.path.dirname(os.path.abspath(__file__))
    if module_path not in sys.path:
        sys.path.insert(0, module_path)
    
    # Import security test classes
    try:
        from tests.test_controllers import TestControllerSecurity
        from tests.test_database_viewer import TestDatabaseViewer
        
        # Create test suite for security tests
        suite = unittest.TestSuite()
        
        # Add security-related tests
        security_tests = [
            'test_01_sql_injection_protection',
            'test_02_xss_protection',
            'test_04_input_validation',
            'test_05_parameter_limits',
            'test_10_execute_custom_query_security',
            'test_11_execute_custom_query_invalid_input',
        ]
        
        for test_name in security_tests:
            try:
                test = TestControllerSecurity(test_name)
                suite.addTest(test)
            except:
                try:
                    test = TestDatabaseViewer(test_name)
                    suite.addTest(test)
                except:
                    pass
        
        # Run security tests
        runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
        result = runner.run(suite)
        
        print()
        print("🔒 SECURITY TEST RESULTS:")
        print(f"Security Tests Run: {result.testsRun}")
        print(f"Security Tests Passed: {result.testsRun - len(result.failures) - len(result.errors)}")
        print(f"Security Tests Failed: {len(result.failures)}")
        print(f"Security Tests Errors: {len(result.errors)}")
        
        return len(result.failures) == 0 and len(result.errors) == 0
        
    except ImportError as e:
        print(f"❌ Could not import security tests: {str(e)}")
        return False

def main():
    """Main function"""
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'security':
            return run_security_tests()
        elif command == 'specific':
            if len(sys.argv) > 2:
                test_name = sys.argv[2]
                return run_specific_test(test_name)
            else:
                print("❌ Please provide a test name: python run_tests.py specific <test_name>")
                return False
        elif command == 'help':
            print("🔍 Database Data Viewer Module - Test Runner")
            print()
            print("Usage:")
            print("  python run_tests.py              # Run all tests")
            print("  python run_tests.py security     # Run security tests only")
            print("  python run_tests.py specific <test_name>  # Run specific test")
            print("  python run_tests.py help         # Show this help")
            print()
            print("Examples:")
            print("  python run_tests.py")
            print("  python run_tests.py security")
            print("  python run_tests.py specific test_01_create_database_viewer")
            return True
        else:
            print(f"❌ Unknown command: {command}")
            print("Use 'python run_tests.py help' for usage information")
            return False
    else:
        return run_tests()

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1) 