try:
    import psycopg2
    PSYCOPG2_AVAILABLE = True
except ImportError:
    PSYCOPG2_AVAILABLE = False
    import logging
    _logger = logging.getLogger(__name__)
    _logger.warning("psycopg2 not available. Database connections will not work.")

import json
import re
from odoo import models, fields, api
from odoo.exceptions import UserError
from odoo.addons.bus.models.bus import dispatch
import logging

_logger = logging.getLogger(__name__)

class DatabaseViewer(models.Model):
    _name = 'database.viewer'
    _description = 'Database Viewer Configuration'

    name = fields.Char(string='Name', required=True)
    host = fields.Char(string='Database Host', default='localhost', required=True)
    port = fields.Integer(string='Database Port', default=5432, required=True)
    database = fields.Char(string='Database Name', required=True)
    username = fields.Char(string='Username', required=True)
    password = fields.Char(string='Password', required=True)
    active = fields.Boolean(string='Active', default=True)

    def send_realtime_update(self, message_type, data):
        """Send real-time update to connected clients"""
        try:
            self.env['bus.bus'].sendone(
                f'database_viewer_{self.id}',
                {
                    'type': message_type,
                    'data': data,
                    'timestamp': fields.Datetime.now(),
                    'viewer_id': self.id
                }
            )
        except Exception as e:
            _logger.error(f"Error sending real-time update: {str(e)}")

    def notify_table_update(self, table_name, action='viewed'):
        """Notify when a table is accessed"""
        self.send_realtime_update('table_activity', {
            'table_name': table_name,
            'action': action,
            'user': self.env.user.name,
            'database': self.database
        })

    def notify_connection_status(self, status, message):
        """Notify connection status changes"""
        self.send_realtime_update('connection_status', {
            'status': status,
            'message': message,
            'database': self.database
        })

    def open_web_viewer(self):
        """Open the web database viewer"""
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Database Viewer',
                'message': f'Web viewer is available at: /database-viewer',
                'type': 'info',
                'sticky': True,
            }
        }

    def show_current_database_data(self):
        """Show data from current Odoo database"""
        return {
            'type': 'ir.actions.act_window',
            'name': f'Current Database Data - {self.env.cr.dbname}',
            'res_model': 'database.data.display',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_database_viewer_id': self.id,
                'default_database_name': self.env.cr.dbname,
                'default_is_current_database': True,
            }
        }

    def get_odoo_db_config(self):
        """Get current Odoo database configuration"""
        # Try to get from environment variables first
        import os
        db_host = os.environ.get('HOST', 'localhost')
        db_port = int(os.environ.get('PORT', '5432'))
        db_user = os.environ.get('USER', 'odoo')
        db_password = os.environ.get('PASSWORD', 'odoo')
        
        # Fallback to config parameters
        if db_host == 'localhost':
            db_host = self.env['ir.config_parameter'].sudo().get_param('db_host', 'localhost')
        if db_port == 5432:
            db_port = int(self.env['ir.config_parameter'].sudo().get_param('db_port', '5432'))
        if db_user == 'odoo':
            db_user = self.env['ir.config_parameter'].sudo().get_param('db_user', 'odoo')
        if db_password == 'odoo':
            db_password = self.env['ir.config_parameter'].sudo().get_param('db_password', 'odoo')
        
        return {
            'host': db_host,
            'port': db_port,
            'database': self.env.cr.dbname,
            'user': db_user,
            'password': db_password,
        }

    def auto_fill_current_db_config(self):
        """Auto-fill current database configuration"""
        config = self.get_odoo_db_config()
        self.write({
            'host': config['host'],
            'port': config['port'],
            'database': config['database'],
            'username': config['user'],
            'password': config['password'],
        })
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Configuration Updated',
                'message': f'Database configuration updated with current Odoo settings',
                'type': 'success',
                'sticky': False,
            }
        }
    


    def show_data_in_odoo(self):
        """Show database data directly in Odoo interface"""
        return {
            'type': 'ir.actions.act_window',
            'name': f'Database Data - {self.database}',
            'res_model': 'database.data.display',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_database_viewer_id': self.id,
                'default_database_name': self.database,
            }
        }

    def test_connection(self):
        """Test database connection"""
        if not PSYCOPG2_AVAILABLE:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Library Missing',
                    'message': 'psycopg2 library is not available. Please install it first.',
                    'type': 'warning',
                    'sticky': True,
                }
            }
        
        try:
            connection = self.get_database_connection()
            connection.close()
            # Send real-time notification
            self.notify_connection_status('success', f'Successfully connected to database {self.database}')
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Success',
                    'message': f'Successfully connected to database {self.database}',
                    'type': 'success',
                    'sticky': False,
                }
            }
        except Exception as e:
            error_msg = f'Connection failed: {str(e)}'
            self.notify_connection_status('error', error_msg)
            raise UserError(error_msg)

    def get_tables(self):
        """Get and display table list"""
        if not PSYCOPG2_AVAILABLE:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Library Missing',
                    'message': 'psycopg2 library is not available. Cannot get tables.',
                    'type': 'warning',
                    'sticky': True,
                }
            }
        
        try:
            tables = self.get_table_list()
            message = f'Found {len(tables)} tables: {", ".join(tables[:10])}'
            if len(tables) > 10:
                message += f' and {len(tables) - 10} more...'
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Tables Found',
                    'message': message,
                    'type': 'info',
                    'sticky': False,
                }
            }
        except Exception as e:
            raise UserError(f'Error getting tables: {str(e)}')

    def get_database_connection(self):
        """Establish connection to the database"""
        if not PSYCOPG2_AVAILABLE:
            raise UserError("psycopg2 library is not available. Please install it first: pip install psycopg2-binary")
        
        # If connecting to current Odoo database, use the current connection
        current_db_config = self.env.cr.dbname
        if (self.host in ['localhost', '127.0.0.1', 'db', 'odoo'] and 
            self.database == current_db_config):
            # Use current Odoo database connection
            return self.env.cr.connection
        
        # Get database connection parameters from Odoo configuration
        config = self.get_odoo_db_config()
        
        try:
            connection = psycopg2.connect(
                host=config['host'],
                port=config['port'],
                database=self.database,
                user=config['user'],
                password=config['password']
            )
            return connection
        except Exception as e:
            _logger.error(f"Database connection failed: {str(e)}")
            raise UserError(f"Failed to connect to database: {str(e)}")

    def _get_safe_connection(self):
        """Get a safe database connection that handles cursor properly"""
        try:
            connection = self.get_database_connection()
            # Test the connection
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            return connection
        except Exception as e:
            _logger.error(f"Safe connection test failed: {str(e)}")
            raise UserError(f"Database connection test failed: {str(e)}")

    def _validate_table_name(self, table_name):
        """Validate table name to prevent SQL injection"""
        if not table_name or not isinstance(table_name, str):
            raise UserError("Invalid table name")
        
        # Only allow alphanumeric characters, underscores, and hyphens
        if not re.match(r'^[a-zA-Z0-9_-]+$', table_name):
            raise UserError("Invalid table name format")
        
        return table_name

    def get_table_list(self):
        """Get list of all tables in the database"""
        connection = None
        cursor = None
        try:
            connection = self._get_safe_connection()
            cursor = connection.cursor()
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public'
                ORDER BY table_name
            """)
            tables = [row[0] for row in cursor.fetchall()]
            return tables
        except Exception as e:
            _logger.error(f"Error getting table list: {str(e)}")
            raise UserError(f"Error retrieving table list: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if connection and connection != self.env.cr.connection:
                try:
                    connection.close()
                except:
                    pass

    def get_table_data(self, table_name, limit=100, offset=0):
        """Get data from a specific table"""
        # Validate inputs
        table_name = self._validate_table_name(table_name)
        limit = max(1, min(1000, int(limit)))  # Limit between 1 and 1000
        offset = max(0, int(offset))  # Offset must be non-negative
        
        connection = None
        cursor = None
        try:
            connection = self._get_safe_connection()
            cursor = connection.cursor()
            
            # Get column names using parameterized query
            cursor.execute("""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = %s
                ORDER BY ordinal_position
            """, (table_name,))
            columns = [{'name': row[0], 'type': row[1]} for row in cursor.fetchall()]
            
            if not columns:
                return {
                    'columns': [],
                    'data': [],
                    'total_rows': 0
                }
            
            # Get data using parameterized query
            cursor.execute(f"""
                SELECT * FROM "{table_name}"
                LIMIT %s OFFSET %s
            """, (limit, offset))
            rows = cursor.fetchall()
            
            # Convert to list of dictionaries
            data = []
            for row in rows:
                row_dict = {}
                for i, value in enumerate(row):
                    if isinstance(value, (dict, list)):
                        row_dict[columns[i]['name']] = json.dumps(value)
                    else:
                        row_dict[columns[i]['name']] = value
                data.append(row_dict)
            
            # Send real-time notification about table access
            self.notify_table_update(table_name, 'viewed')
            
            return {
                'columns': columns,
                'data': data,
                'total_rows': len(data)
            }
        except Exception as e:
            _logger.error(f"Error getting table data: {str(e)}")
            raise UserError(f"Error retrieving data from table {table_name}: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if connection and connection != self.env.cr.connection:
                try:
                    connection.close()
                except:
                    pass

    def get_table_count(self, table_name):
        """Get total number of rows in a table"""
        table_name = self._validate_table_name(table_name)
        connection = None
        cursor = None
        try:
            connection = self._get_safe_connection()
            cursor = connection.cursor()
            cursor.execute('SELECT COUNT(*) FROM "{}"'.format(table_name))
            count = cursor.fetchone()[0]
            return count
        except Exception as e:
            _logger.error(f"Error getting table count: {str(e)}")
            raise UserError(f"Error getting row count for table {table_name}: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if connection and connection != self.env.cr.connection:
                try:
                    connection.close()
                except:
                    pass

    def execute_custom_query(self, query):
        """Execute a custom SQL query"""
        if not query or not isinstance(query, str):
            raise UserError("Invalid query")
        
        # Basic security check - prevent dangerous operations
        dangerous_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'CREATE', 'ALTER', 'TRUNCATE']
        query_upper = query.upper()
        for keyword in dangerous_keywords:
            if keyword in query_upper:
                raise UserError(f"Query contains forbidden keyword: {keyword}")
        
        connection = None
        cursor = None
        try:
            connection = self._get_safe_connection()
            cursor = connection.cursor()
            cursor.execute(query)
            
            # Get column names
            columns = [desc[0] for desc in cursor.description]
            
            # Get data
            rows = cursor.fetchall()
            
            # Convert to list of dictionaries
            data = []
            for row in rows:
                row_dict = {}
                for i, value in enumerate(row):
                    if isinstance(value, (dict, list)):
                        row_dict[columns[i]] = json.dumps(value)
                    else:
                        row_dict[columns[i]] = value
                data.append(row_dict)
            
            return {
                'columns': [{'name': col, 'type': 'unknown'} for col in columns],
                'data': data,
                'total_rows': len(data)
            }
        except Exception as e:
            _logger.error(f"Error executing custom query: {str(e)}")
            raise UserError(f"Error executing query: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if connection and connection != self.env.cr.connection:
                try:
                    connection.close()
                except:
                    pass

    def generate_html_data_display(self, selected_tables=None, limit_per_table=50):
        """Generate HTML content for displaying data in Odoo"""
        try:
            if not selected_tables:
                tables = self.get_table_list()
            else:
                tables = [t for t in selected_tables if self._validate_table_name(t)]
            
            html_content = f"""
            <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 100%;">
                <div style="background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h1 style="margin: 0; font-size: 2em;">🔍 Database Data Viewer</h1>
                    <p style="margin: 5px 0 0 0; opacity: 0.9;">Database: {self.database} | Host: {self.host}:{self.port}</p>
                </div>
                
                <div style="display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
                    <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 150px; text-align: center;">
                        <div style="font-size: 2em; font-weight: bold; color: #3498db;">{len(tables)}</div>
                        <div style="color: #6c757d; margin-top: 5px;">Total Tables</div>
                    </div>
                    <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 150px; text-align: center;">
                        <div style="font-size: 2em; font-weight: bold; color: #27ae60;" id="total-rows">-</div>
                        <div style="color: #6c757d; margin-top: 5px;">Total Rows</div>
                    </div>
                </div>
            """
            
            total_rows = 0
            
            for table in tables:
                try:
                    data = self.get_table_data(table, limit=limit_per_table)
                    total_rows += data['total_rows']
                    
                    html_content += f"""
                    <div style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; margin-bottom: 20px; overflow: hidden;">
                        <div style="background: #6c757d; color: white; padding: 15px 20px; font-weight: bold; display: flex; justify-content: space-between; align-items: center;">
                            <span>📄 {table}</span>
                            <span style="background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 4px; font-size: 0.9em;">{data['total_rows']} rows</span>
                        </div>
                        <div style="padding: 20px;">
                    """
                    
                    if data['data']:
                        html_content += '<div style="overflow-x: auto;"><table style="width: 100%; border-collapse: collapse; font-size: 14px;">'
                        
                        # Headers
                        html_content += '<thead><tr style="background: #495057; color: white;">'
                        for col in data['columns']:
                            html_content += f'<th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-weight: 600;">{col["name"]}</th>'
                        html_content += '</tr></thead><tbody>'
                        
                        # Data rows
                        for i, row in enumerate(data['data']):
                            bg_color = '#f8f9fa' if i % 2 == 0 else 'white'
                            html_content += f'<tr style="background: {bg_color};">'
                            for col in data['columns']:
                                value = row.get(col['name'], '')
                                if value is None:
                                    html_content += '<td style="border: 1px solid #dee2e6; padding: 8px 12px; text-align: left; font-style: italic; color: #6c757d;">null</td>'
                                else:
                                    # Truncate long values
                                    display_value = str(value)
                                    if len(display_value) > 100:
                                        display_value = display_value[:100] + '...'
                                    html_content += f'<td style="border: 1px solid #dee2e6; padding: 8px 12px; text-align: left; word-wrap: break-word; max-width: 200px;">{display_value}</td>'
                            html_content += '</tr>'
                        
                        html_content += '</tbody></table></div>'
                        
                        if data['total_rows'] > limit_per_table:
                            html_content += f'<p style="margin-top: 10px; color: #6c757d; font-style: italic;">Showing {limit_per_table} of {data["total_rows"]} rows</p>'
                    else:
                        html_content += '<p style="color: #6c757d; font-style: italic;">No data found in this table.</p>'
                    
                    html_content += """
                        </div>
                    </div>
                    """
                    
                except Exception as e:
                    html_content += f"""
                    <div style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; margin-bottom: 20px; overflow: hidden;">
                        <div style="background: #6c757d; color: white; padding: 15px 20px; font-weight: bold;">
                            📄 {table}
                        </div>
                        <div style="padding: 20px;">
                            <div style="color: #dc3545; background: #f8d7da; padding: 15px; border-radius: 5px;">
                                Error loading data: {str(e)}
                            </div>
                        </div>
                    </div>
                    """
            
            html_content += f"""
                </div>
                <script>
                    document.getElementById('total-rows').textContent = '{total_rows:,}';
                </script>
            """
            
            return html_content
            
        except Exception as e:
            return f"""
            <div style="color: #dc3545; background: #f8d7da; padding: 20px; border-radius: 5px; margin: 20px;">
                <h3>Error Loading Database Data</h3>
                <p>{str(e)}</p>
            </div>
            """


class DatabaseDataDisplay(models.TransientModel):
    _name = 'database.data.display'
    _description = 'Database Data Display'

    database_viewer_id = fields.Many2one('database.viewer', string='Database Viewer', required=True)
    database_name = fields.Char(string='Database Name', readonly=True)
    is_current_database = fields.Boolean(string='Current Database', default=False)
    selected_tables = fields.Text(string='Selected Tables (comma separated)', 
                                 help='Leave empty to show all tables')
    limit_per_table = fields.Integer(string='Rows per Table', default=50, help='Maximum rows to show per table')
    html_content = fields.Html(string='Data Display', readonly=True)
    
    @api.onchange('database_viewer_id')
    def _onchange_database_viewer(self):
        if self.database_viewer_id:
            self.database_name = self.database_viewer_id.database
    
    def generate_data_display(self):
        """Generate HTML display of database data"""
        if not self.database_viewer_id:
            raise UserError('Please select a database viewer configuration.')
        
        selected_tables = None
        if self.selected_tables:
            selected_tables = [t.strip() for t in self.selected_tables.split(',') if t.strip()]
        
        html_content = self.database_viewer_id.generate_html_data_display(
            selected_tables=selected_tables,
            limit_per_table=self.limit_per_table
        )
        
        # Use sudo to avoid cursor issues
        self.sudo().write({'html_content': html_content})
        
        return {
            'type': 'ir.actions.act_window',
            'name': f'Database Data - {self.database_name}',
            'res_model': 'database.data.display',
            'view_mode': 'form',
            'target': 'new',
            'res_id': self.id,
        } 