# Database Data Viewer - API Documentation

## Overview

The Database Data Viewer module provides a comprehensive API for programmatic access to database data through Odoo. This document describes all available API endpoints, models, and methods.

## Table of Contents

- [Models](#models)
- [Web API Endpoints](#web-api-endpoints)
- [Odoo Model Methods](#odoo-model-methods)
- [Command Line Interface](#command-line-interface)
- [Authentication](#authentication)
- [Error Handling](#error-handling)
- [Examples](#examples)

## Models

### Database Viewer Model

**Model Name**: `database.viewer`

**Description**: Main model for managing database connections and data retrieval.

#### Fields

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `name` | Char | Descriptive name for the connection | Yes |
| `host` | Char | Database server hostname | Yes |
| `port` | Integer | Database port number | Yes |
| `database` | Char | Database name | Yes |
| `username` | Char | Database username | Yes |
| `password` | Char | Database password | Yes |
| `active` | Boolean | Whether the connection is active | No |

#### Methods

##### `get_database_connection()`
Establishes a connection to the configured database.

**Returns**: `psycopg2.connection` object

**Raises**: `UserError` if connection fails

```python
connection = database_viewer.get_database_connection()
```

##### `get_table_list()`
Retrieves list of all tables in the database.

**Returns**: `list` of table names

**Raises**: `UserError` if query fails

```python
tables = database_viewer.get_table_list()
# Returns: ['users', 'products', 'orders']
```

##### `get_table_data(table_name, limit=100, offset=0)`
Retrieves data from a specific table.

**Parameters**:
- `table_name` (str): Name of the table
- `limit` (int): Maximum number of rows (1-1000)
- `offset` (int): Number of rows to skip

**Returns**: `dict` with structure:
```python
{
    'columns': [
        {'name': 'id', 'type': 'integer'},
        {'name': 'name', 'type': 'varchar'}
    ],
    'data': [
        {'id': 1, 'name': 'John Doe'},
        {'id': 2, 'name': 'Jane Smith'}
    ],
    'total_rows': 2
}
```

**Raises**: `UserError` if table name is invalid or query fails

```python
data = database_viewer.get_table_data('users', limit=50, offset=0)
```

##### `get_table_count(table_name)`
Gets the total number of rows in a table.

**Parameters**:
- `table_name` (str): Name of the table

**Returns**: `int` - Total number of rows

**Raises**: `UserError` if table name is invalid

```python
count = database_viewer.get_table_count('users')
```

##### `execute_custom_query(query)`
Executes a custom SQL query (SELECT only).

**Parameters**:
- `query` (str): SQL SELECT query

**Returns**: `dict` with columns and data

**Raises**: `UserError` if query contains forbidden keywords or is not SELECT

```python
result = database_viewer.execute_custom_query("SELECT id, name FROM users WHERE active = true")
```

##### `test_connection()`
Tests the database connection.

**Returns**: `dict` - Odoo action for notification

**Raises**: `UserError` if connection fails

```python
result = database_viewer.test_connection()
```

##### `get_tables()`
Gets table list and shows notification.

**Returns**: `dict` - Odoo action for notification

**Raises**: `UserError` if query fails

```python
result = database_viewer.get_tables()
```

##### `generate_html_data_display(selected_tables=None, limit_per_table=100)`
Generates HTML content for data display.

**Parameters**:
- `selected_tables` (list): List of table names to include
- `limit_per_table` (int): Maximum rows per table

**Returns**: `str` - HTML content

```python
html_content = database_viewer.generate_html_data_display(
    selected_tables=['users', 'products'],
    limit_per_table=50
)
```

##### `open_web_viewer()`
Opens the web interface.

**Returns**: `dict` - Odoo action to open URL

```python
result = database_viewer.open_web_viewer()
```

##### `show_data_in_odoo()`
Opens the Odoo data display form.

**Returns**: `dict` - Odoo action to open form

```python
result = database_viewer.show_data_in_odoo()
```

### Database Data Display Model

**Model Name**: `database.data.display`

**Description**: Transient model for displaying database data in Odoo.

#### Fields

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `database_viewer_id` | Many2one | Reference to database viewer | Yes |
| `database_name` | Char | Database name | No |
| `selected_tables` | Char | Comma-separated table names | No |
| `limit_per_table` | Integer | Maximum rows per table | No |
| `html_content` | Text | Generated HTML content | No |

#### Methods

##### `_onchange_database_viewer()`
Updates database name when viewer is changed.

```python
data_display._onchange_database_viewer()
```

##### `generate_data_display()`
Generates HTML data display.

**Returns**: `dict` - Odoo action to open form

**Raises**: `UserError` if no viewer is selected

```python
result = data_display.generate_data_display()
```

## Web API Endpoints

### Base URL
All API endpoints are relative to your Odoo instance URL.

### Authentication
All endpoints require Odoo user authentication. Users must be logged in to access the API.

### Endpoints

#### 1. Main Web Interface

**URL**: `/database-viewer`

**Method**: `GET`

**Description**: Returns the main web interface HTML page.

**Response**: HTML page with interactive database viewer

**Example**:
```bash
curl -X GET "http://localhost:8069/database-viewer" \
  -H "Cookie: session_id=your_session_id"
```

#### 2. Table Data API

**URL**: `/database-viewer/api/table-data/{table_name}`

**Method**: `GET`

**Description**: Retrieves data from a specific table.

**Parameters**:
- `table_name` (path): Name of the table
- `limit` (query): Maximum number of rows (default: 100, max: 1000)
- `offset` (query): Number of rows to skip (default: 0)

**Response**: JSON object
```json
{
    "columns": [
        {"name": "id", "type": "integer"},
        {"name": "name", "type": "varchar"}
    ],
    "data": [
        {"id": 1, "name": "John Doe"},
        {"id": 2, "name": "Jane Smith"}
    ],
    "total_rows": 2
}
```

**Error Responses**:
- `400 Bad Request`: Invalid table name
- `404 Not Found`: No active database configuration
- `500 Internal Server Error`: Database error

**Example**:
```bash
curl -X GET "http://localhost:8069/database-viewer/api/table-data/users?limit=50&offset=0" \
  -H "Cookie: session_id=your_session_id"
```

#### 3. Statistics API

**URL**: `/database-viewer/api/stats`

**Method**: `GET`

**Description**: Returns database statistics.

**Response**: JSON object
```json
{
    "total_tables": 5,
    "total_rows": 1250,
    "database_name": "production_db",
    "loaded_tables": 2
}
```

**Error Responses**:
- `404 Not Found`: No active database configuration
- `500 Internal Server Error`: Database error

**Example**:
```bash
curl -X GET "http://localhost:8069/database-viewer/api/stats" \
  -H "Cookie: session_id=your_session_id"
```

## Odoo Model Methods

### Using Models in Odoo Shell

```python
# Start Odoo shell
python odoo-bin shell -d your_database

# Get database viewer
viewer = env['database.viewer'].search([('active', '=', True)])[0]

# Get table list
tables = viewer.get_table_list()

# Get table data
data = viewer.get_table_data('users', limit=100)

# Execute custom query
result = viewer.execute_custom_query("SELECT COUNT(*) FROM users")
```

### Using Models in Custom Code

```python
class CustomModel(models.Model):
    _name = 'custom.model'
    
    def process_database_data(self):
        # Get active database viewer
        viewer = self.env['database.viewer'].search([('active', '=', True)])[0]
        
        # Get data from specific table
        data = viewer.get_table_data('users')
        
        # Process the data
        for row in data['data']:
            # Process each row
            pass
```

## Command Line Interface

### Build Interface Command

**Script**: `commands/build_interface.py`

**Description**: Generates static HTML file with database data.

**Usage**:
```bash
# From Odoo installation directory
python commands/build_interface.py
```

**Output**: Static HTML file at `/path/to/odoo/data/database_data_viewer.html`

### Main Function

```python
def main():
    """Main function for command line execution."""
    try:
        # Initialize Odoo environment
        odoo.cli.server.main()
        
        # Build interface
        success = build_database_html_interface(env)
        
        if success:
            print("HTML interface generated successfully")
            return 0
        else:
            print("Failed to generate HTML interface")
            return 1
            
    except Exception as e:
        print(f"Error: {e}")
        return 1
```

### Helper Functions

```python
def build_database_html_interface(env):
    """Build HTML interface for database data."""
    # Implementation details...

def generate_html_content(database_viewer, tables, limit_per_table=100):
    """Generate HTML content for database data."""
    # Implementation details...
```

## Authentication

### Odoo User Authentication

All API endpoints require Odoo user authentication:

1. **Login**: Users must be logged into Odoo
2. **Session**: Valid session cookie required
3. **Permissions**: User must have access to database.viewer model

### Access Control

```python
# Check user permissions
if not env.user.has_group('base.group_user'):
    raise AccessError("Insufficient permissions")

# Check model access
if not env.user.has_group('base.group_system'):
    # Limited access for regular users
    pass
```

## Error Handling

### Error Response Format

All API endpoints return consistent error responses:

```json
{
    "error": "Error message description",
    "code": "ERROR_CODE",
    "details": "Additional error details"
}
```

### Common Error Codes

| Code | Description | HTTP Status |
|------|-------------|-------------|
| `INVALID_TABLE` | Invalid table name | 400 |
| `NO_CONFIG` | No active database configuration | 404 |
| `CONNECTION_FAILED` | Database connection failed | 500 |
| `QUERY_ERROR` | Database query error | 500 |
| `PERMISSION_DENIED` | Insufficient permissions | 403 |

### Exception Handling

```python
try:
    data = viewer.get_table_data('users')
except UserError as e:
    # Handle user errors (validation, permissions)
    logger.warning(f"User error: {e}")
    raise
except psycopg2.Error as e:
    # Handle database errors
    logger.error(f"Database error: {e}")
    raise UserError("Database operation failed")
except Exception as e:
    # Handle unexpected errors
    logger.error(f"Unexpected error: {e}")
    raise UserError("An unexpected error occurred")
```

## Examples

### Complete Workflow Example

```python
# 1. Create database viewer configuration
viewer = env['database.viewer'].create({
    'name': 'Production Database',
    'host': 'localhost',
    'port': 5432,
    'database': 'production_db',
    'username': 'db_user',
    'password': 'db_password',
    'active': True
})

# 2. Test connection
result = viewer.test_connection()

# 3. Get table list
tables = viewer.get_table_list()

# 4. Get data from specific table
data = viewer.get_table_data('users', limit=100)

# 5. Process data
for row in data['data']:
    print(f"User: {row['name']}")

# 6. Execute custom query
result = viewer.execute_custom_query("""
    SELECT COUNT(*) as total_users 
    FROM users 
    WHERE created_date >= '2024-01-01'
""")
```

### Web API Example

```javascript
// Get table data via AJAX
async function loadTableData(tableName) {
    try {
        const response = await fetch(`/database-viewer/api/table-data/${tableName}?limit=50`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Display data
        displayTableData(data);
        
    } catch (error) {
        console.error('Error loading table data:', error);
        showError('Failed to load table data');
    }
}

// Get database statistics
async function loadStats() {
    try {
        const response = await fetch('/database-viewer/api/stats');
        const stats = await response.json();
        
        // Update statistics display
        updateStatsDisplay(stats);
        
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}
```

### Integration Example

```python
# Integrate with other Odoo modules
class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    def get_customer_data(self):
        """Get customer data from external database."""
        viewer = self.env['database.viewer'].search([('active', '=', True)])[0]
        
        # Get customer data from external database
        customer_data = viewer.execute_custom_query("""
            SELECT customer_id, name, email, phone
            FROM customers
            WHERE customer_id = %s
        """, (self.partner_id.external_id,))
        
        return customer_data['data'][0] if customer_data['data'] else None
```

## Rate Limiting

### API Rate Limits

- **Table Data API**: 100 requests per minute per user
- **Statistics API**: 50 requests per minute per user
- **Web Interface**: No rate limiting

### Implementation

```python
from odoo.http import request
import time

def check_rate_limit(user_id, endpoint, limit=100, window=60):
    """Check rate limit for API endpoint."""
    cache_key = f"rate_limit:{user_id}:{endpoint}"
    current_time = time.time()
    
    # Get current request count
    request_count = request.env.cache.get(cache_key, 0)
    
    if request_count >= limit:
        raise UserError("Rate limit exceeded")
    
    # Increment request count
    request.env.cache[cache_key] = request_count + 1
    
    # Set expiration
    request.env.cache[f"{cache_key}:expires"] = current_time + window
```

## Security Considerations

### Input Validation

All API inputs are validated:

```python
def validate_table_name(table_name):
    """Validate table name to prevent SQL injection."""
    if not table_name or not isinstance(table_name, str):
        raise UserError("Invalid table name")
    
    # Check for dangerous characters
    dangerous_chars = [';', "'", '"', '--', '/*', '*/']
    for char in dangerous_chars:
        if char in table_name:
            raise UserError(f"Table name contains forbidden character: {char}")
    
    return table_name
```

### SQL Injection Protection

All queries use parameterized statements:

```python
# Safe: Parameterized query
cursor.execute('SELECT * FROM "{}" WHERE id = %s'.format(table_name), (record_id,))

# Unsafe: String concatenation (NOT USED)
# cursor.execute(f'SELECT * FROM {table_name} WHERE id = {record_id}')
```

### XSS Protection

All output is HTML-escaped:

```python
import html

def escape_html(text):
    """Escape HTML content to prevent XSS."""
    if text is None:
        return '<em>null</em>'
    
    return html.escape(str(text))
```

## Performance Optimization

### Caching

```python
from functools import lru_cache

@lru_cache(maxsize=100)
def get_cached_table_list():
    """Cache table list for better performance."""
    return get_table_list()
```

### Connection Pooling

```python
def get_connection_from_pool():
    """Get database connection from pool."""
    # Implementation for connection pooling
    pass
```

### Query Optimization

```python
def optimize_query(table_name, limit, offset):
    """Optimize query for better performance."""
    # Add appropriate LIMIT and OFFSET
    # Use indexes effectively
    # Minimize data transfer
    pass
```

## Monitoring and Logging

### API Logging

```python
import logging

logger = logging.getLogger('database_viewer_api')

def log_api_request(endpoint, user_id, success, duration):
    """Log API request for monitoring."""
    logger.info(f"API Request: {endpoint} by user {user_id}, success: {success}, duration: {duration}ms")
```

### Performance Monitoring

```python
import time

def monitor_performance(func):
    """Decorator to monitor function performance."""
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        
        duration = (end_time - start_time) * 1000  # Convert to milliseconds
        logger.info(f"{func.__name__} took {duration:.2f}ms")
        
        return result
    return wrapper
```

## Conclusion

The Database Data Viewer API provides comprehensive access to database data through multiple interfaces. The API is designed to be secure, performant, and easy to use while maintaining compatibility with Odoo's architecture.

For more information, refer to:
- [README.md](README.md) - General documentation
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - Troubleshooting guide
- [SECURITY.md](SECURITY.md) - Security documentation
- [PERFORMANCE.md](PERFORMANCE.md) - Performance optimization guide 