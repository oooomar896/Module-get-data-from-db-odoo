# Quick Installation Guide

## Prerequisites

Before installing the Database Data Viewer module, ensure you have:

### System Requirements
- **Python 3.8+**
- **Odoo 16.0+**
- **PostgreSQL 12+**
- **psycopg2-binary** Python package

### Database Requirements
- PostgreSQL server running
- Database user with SELECT permissions
- Network access to database server

## Quick Installation

### 1. Install Dependencies

```bash
# Install PostgreSQL adapter
pip install psycopg2-binary
```

### 2. Copy Module

```bash
# Copy module to Odoo addons directory
cp -r data_db /path/to/odoo/addons/

# Example for Linux
sudo cp -r data_db /opt/odoo/addons/

# Example for Windows
xcopy data_db C:\Odoo\addons\ /E /I
```

### 3. Update Odoo Configuration

Add the module path to your Odoo configuration file (`odoo.conf`):

```ini
[options]
addons_path = /path/to/odoo/addons,/path/to/odoo/addons/data_db
```

### 4. Restart Odoo

```bash
# Restart Odoo service
sudo systemctl restart odoo

# Or stop and start manually
sudo systemctl stop odoo
sudo systemctl start odoo
```

### 5. Install Module

1. **Access Odoo**: Open your Odoo instance in a web browser
2. **Go to Apps**: Navigate to Apps menu
3. **Update Apps List**: Click "Update Apps List" if needed
4. **Search Module**: Search for "Database Data Viewer"
5. **Install**: Click "Install" button

## Configuration

### 1. Create Database Connection

1. **Go to Tools**: Navigate to Tools → Database Viewer
2. **Create New**: Click "Create" button
3. **Fill Details**:
   - **Name**: Descriptive name (e.g., "Production Database")
   - **Host**: Database server hostname (e.g., "localhost")
   - **Port**: Database port (default: 5432)
   - **Database**: Database name
   - **Username**: Database username
   - **Password**: Database password
   - **Active**: Check to enable
4. **Test Connection**: Click "Test Connection" button
5. **Save**: Click "Save" button

### 2. Verify Installation

1. **Test Connection**: Use "Test Connection" button
2. **Get Tables**: Use "Get Tables" button to see available tables
3. **Access Web Interface**: Go to Tools → Open Web Viewer

## Troubleshooting

### Common Issues

#### 1. Module Not Found
```bash
# Check module path
ls -la /path/to/odoo/addons/data_db/

# Verify Odoo configuration
grep addons_path /etc/odoo/odoo.conf

# Restart Odoo
sudo systemctl restart odoo
```

#### 2. Database Connection Failed
```bash
# Test database connection manually
psql -h localhost -p 5432 -U your_username -d your_database

# Check PostgreSQL service
sudo systemctl status postgresql

# Check firewall
sudo ufw status
```

#### 3. Permission Denied
```bash
# Grant database permissions
sudo -u postgres psql
GRANT CONNECT ON DATABASE your_database TO your_user;
GRANT USAGE ON SCHEMA public TO your_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO your_user;
\q
```

#### 4. psycopg2 Not Found
```bash
# Install PostgreSQL adapter
pip install psycopg2-binary

# For system-wide installation
sudo pip3 install psycopg2-binary

# For virtual environment
source venv/bin/activate
pip install psycopg2-binary
```

### Log Files

Check Odoo logs for detailed error information:

```bash
# Odoo logs
tail -f /var/log/odoo/odoo.log

# PostgreSQL logs
tail -f /var/log/postgresql/postgresql-*.log

# System logs
journalctl -u odoo -f
```

## Quick Start

### 1. Basic Usage

1. **Configure Database**: Set up database connection
2. **Test Connection**: Verify connectivity
3. **View Data**: Use web interface or Odoo display

### 2. Web Interface

1. **Access**: Go to Tools → Open Web Viewer
2. **Browse Tables**: Click on table names to view data
3. **Interactive**: Data loads dynamically

### 3. Odoo Display

1. **Generate Display**: Go to Tools → Show Data in Odoo
2. **Configure**: Select tables and limits
3. **View**: See formatted data in Odoo

### 4. Command Line

```bash
# Generate static HTML file
cd /path/to/odoo
python commands/build_interface.py
```

## Security Notes

### Important Security Considerations

1. **Database Access**: Use dedicated database user with minimal permissions
2. **Network Security**: Ensure database server is properly secured
3. **User Authentication**: Only authorized Odoo users should access the module
4. **Data Protection**: Be aware of data privacy and protection requirements

### Security Checklist

- [ ] Database user has only SELECT permissions
- [ ] Database server is not exposed to public network
- [ ] Strong passwords are used for database access
- [ ] Odoo user access is properly configured
- [ ] Regular security updates are applied

## Support

### Getting Help

1. **Check Documentation**: Review README.md and TROUBLESHOOTING.md
2. **Run Tests**: Use `python run_tests.py` to check for issues
3. **Check Logs**: Review Odoo and system logs
4. **Community**: Check Odoo community forums

### Contact Information

- **GitHub Issues**: For bug reports and feature requests
- **Documentation**: Check project documentation
- **Community**: Odoo community forums

## Uninstallation

### Remove Module

1. **Uninstall**: Go to Apps → Database Data Viewer → Uninstall
2. **Remove Files**: Delete module directory
3. **Update Configuration**: Remove from addons_path
4. **Restart Odoo**: Restart Odoo service

```bash
# Remove module files
sudo rm -rf /path/to/odoo/addons/data_db

# Restart Odoo
sudo systemctl restart odoo
```

### Clean Database

```sql
-- Remove module data (optional)
DELETE FROM ir_model_data WHERE module = 'data_db';
DELETE FROM ir_model WHERE model LIKE 'database.%';
```

## Performance Tips

### Optimization

1. **Database Indexes**: Add indexes to frequently queried columns
2. **Connection Pooling**: Use connection pooling for better performance
3. **Data Limits**: Set appropriate row limits to prevent memory issues
4. **Caching**: Enable caching for frequently accessed data

### Monitoring

1. **Query Performance**: Monitor database query performance
2. **Memory Usage**: Check memory consumption
3. **Response Times**: Monitor web interface response times
4. **Error Rates**: Track error rates and types

## Next Steps

After successful installation:

1. **Read Documentation**: Review README.md for detailed usage
2. **Configure Security**: Set up proper access controls
3. **Test Functionality**: Try all features and interfaces
4. **Customize**: Modify for your specific needs
5. **Monitor**: Set up monitoring and alerting

## Version Information

- **Current Version**: 1.0.0
- **Odoo Compatibility**: 16.0+
- **Python Compatibility**: 3.8+
- **Database Compatibility**: PostgreSQL 12+

For the latest version and updates, check the project repository. 