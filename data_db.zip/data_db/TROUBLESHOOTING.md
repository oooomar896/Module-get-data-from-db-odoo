# Database Data Viewer - Troubleshooting Guide

## Common Issues and Solutions

### 1. Database Connection Issues

#### Issue: "Failed to connect to database"
**Symptoms:**
- Connection test fails
- Error message: "Failed to connect to database"
- Web interface shows connection error

**Possible Causes:**
- Incorrect database credentials
- PostgreSQL service not running
- Network connectivity issues
- Firewall blocking connection
- Database server not accepting connections

**Solutions:**
1. **Verify Database Credentials:**
   ```bash
   # Test connection manually
   psql -h localhost -p 5432 -U your_username -d your_database
   ```

2. **Check PostgreSQL Service:**
   ```bash
   # Windows
   net start postgresql-x64-15
   
   # Linux
   sudo systemctl status postgresql
   sudo systemctl start postgresql
   ```

3. **Check Network Connectivity:**
   ```bash
   # Test if port is accessible
   telnet localhost 5432
   
   # Or use nmap
   nmap -p 5432 localhost
   ```

4. **Verify PostgreSQL Configuration:**
   - Check `postgresql.conf` for `listen_addresses`
   - Check `pg_hba.conf` for authentication settings
   - Ensure database allows connections from your IP

#### Issue: "Permission denied for database"
**Symptoms:**
- Connection succeeds but queries fail
- Error: "permission denied for table"

**Solutions:**
1. **Grant Database Permissions:**
   ```sql
   -- Connect as superuser
   GRANT CONNECT ON DATABASE your_database TO your_user;
   GRANT USAGE ON SCHEMA public TO your_user;
   GRANT SELECT ON ALL TABLES IN SCHEMA public TO your_user;
   ```

2. **Check User Roles:**
   ```sql
   -- Check user permissions
   \du your_user
   ```

### 2. Module Installation Issues

#### Issue: "Module not found"
**Symptoms:**
- Module doesn't appear in Apps list
- Installation fails with "Module not found"

**Solutions:**
1. **Verify Module Path:**
   ```bash
   # Check if module is in correct location
   ls -la /path/to/odoo/addons/data_db/
   ```

2. **Update Apps List:**
   - Go to Apps → Update Apps List
   - Or restart Odoo server

3. **Check Addons Path:**
   ```bash
   # Verify addons path in Odoo config
   grep addons_path /etc/odoo/odoo.conf
   ```

4. **Restart Odoo:**
   ```bash
   # Restart Odoo service
   sudo systemctl restart odoo
   ```

#### Issue: "Dependencies not found"
**Symptoms:**
- Installation fails with dependency errors
- Module loads but functionality doesn't work

**Solutions:**
1. **Install Python Dependencies:**
   ```bash
   pip install psycopg2-binary
   ```

2. **Check Odoo Version Compatibility:**
   - Ensure module is compatible with your Odoo version
   - Check `__manifest__.py` for version requirements

### 3. Web Interface Issues

#### Issue: "Web interface not loading"
**Symptoms:**
- Page shows blank or error
- JavaScript errors in browser console
- 404 or 500 errors

**Solutions:**
1. **Check User Authentication:**
   - Ensure user is logged into Odoo
   - Check user has proper access rights

2. **Check Browser Console:**
   - Open Developer Tools (F12)
   - Look for JavaScript errors
   - Check Network tab for failed requests

3. **Verify URL Configuration:**
   - Check if Odoo is accessible at configured URL
   - Ensure proxy settings are correct

4. **Check Odoo Logs:**
   ```bash
   tail -f /var/log/odoo/odoo.log
   ```

#### Issue: "Tables not loading"
**Symptoms:**
- Web interface loads but no tables appear
- "No tables found" message

**Solutions:**
1. **Check Database Configuration:**
   - Verify database connection is active
   - Test connection from Odoo interface

2. **Check Database Permissions:**
   - Ensure user can list tables
   - Check schema permissions

3. **Verify Table Names:**
   ```sql
   -- List all tables
   \dt
   
   -- Check specific schema
   \dt public.*
   ```

### 4. HTML Display Issues

#### Issue: "HTML content not displaying"
**Symptoms:**
- Button click doesn't show data
- Empty or malformed HTML content
- Error messages in Odoo interface

**Solutions:**
1. **Check Database Connection:**
   - Test connection from configuration
   - Verify database is accessible

2. **Check Table Selection:**
   - Ensure selected tables exist
   - Verify table names are correct

3. **Check Odoo Logs:**
   - Look for Python errors
   - Check for database connection issues

4. **Verify HTML Generation:**
   - Test HTML generation manually
   - Check for encoding issues

#### Issue: "Large datasets causing performance issues"
**Symptoms:**
- Slow loading times
- Browser freezing
- Memory usage spikes

**Solutions:**
1. **Reduce Row Limits:**
   - Set lower limit per table
   - Use pagination for large tables

2. **Optimize Queries:**
   - Add indexes to frequently queried columns
   - Use LIMIT clauses in queries

3. **Use Web Interface:**
   - Web interface loads data on-demand
   - More efficient for large datasets

### 5. Security Issues

#### Issue: "SQL injection attempts detected"
**Symptoms:**
- Error messages about forbidden keywords
- Queries being rejected

**Solutions:**
1. **This is Expected Behavior:**
   - Module correctly blocks malicious queries
   - Use only SELECT queries for data viewing

2. **Check Query Syntax:**
   - Ensure queries are valid SELECT statements
   - Avoid using forbidden keywords

#### Issue: "XSS warnings in browser"
**Symptoms:**
- Browser security warnings
- Content Security Policy violations

**Solutions:**
1. **Check HTML Content:**
   - Module should escape all user content
   - Verify HTML generation is secure

2. **Update Browser:**
   - Use latest browser version
   - Check browser security settings

### 6. Performance Issues

#### Issue: "Slow data loading"
**Symptoms:**
- Long loading times
- Timeout errors
- Poor responsiveness

**Solutions:**
1. **Optimize Database:**
   ```sql
   -- Add indexes to frequently queried columns
   CREATE INDEX idx_table_column ON table_name(column_name);
   
   -- Analyze table statistics
   ANALYZE table_name;
   ```

2. **Reduce Data Volume:**
   - Use smaller row limits
   - Select specific tables only
   - Use WHERE clauses to filter data

3. **Check Network:**
   - Ensure good network connectivity
   - Check database server performance

#### Issue: "Memory usage too high"
**Symptoms:**
- High memory consumption
- System slowdown
- Out of memory errors

**Solutions:**
1. **Limit Data Retrieval:**
   - Reduce row limits
   - Use pagination
   - Process data in chunks

2. **Optimize Queries:**
   - Use specific column selection
   - Add WHERE clauses
   - Use indexes effectively

### 7. Testing Issues

#### Issue: "Tests failing"
**Symptoms:**
- Test runner reports failures
- Specific test errors
- Integration test failures

**Solutions:**
1. **Check Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Individual Tests:**
   ```bash
   # Run specific test
   python run_tests.py specific test_name
   
   # Run security tests only
   python run_tests.py security
   ```

3. **Check Database for Tests:**
   - Ensure test database is accessible
   - Check test user permissions

4. **Debug Test Failures:**
   ```bash
   # Run with verbose output
   python -m unittest tests.test_database_viewer -v
   ```

### 8. Configuration Issues

#### Issue: "Configuration not saving"
**Symptoms:**
- Settings not persisted
- Configuration reverts to defaults
- Database connection lost

**Solutions:**
1. **Check User Permissions:**
   - Ensure user can create/edit records
   - Check access rights for database.viewer model

2. **Verify Database:**
   - Check Odoo database is working
   - Verify table structure is correct

3. **Check Odoo Logs:**
   - Look for database errors
   - Check for permission issues

### 9. Export Issues

#### Issue: "Static HTML file not generated"
**Symptoms:**
- Command line tool fails
- No output file created
- Permission errors

**Solutions:**
1. **Check File Permissions:**
   ```bash
   # Ensure write permissions
   chmod 755 /path/to/odoo/data/
   ```

2. **Verify Command:**
   ```bash
   # Run with verbose output
   python commands/build_interface.py --verbose
   ```

3. **Check Odoo Environment:**
   - Ensure Odoo is properly configured
   - Check database connection

### 10. Browser Compatibility Issues

#### Issue: "Interface not working in specific browser"
**Symptoms:**
- Features not working in certain browsers
- JavaScript errors
- Styling issues

**Solutions:**
1. **Check Browser Compatibility:**
   - Use modern browsers (Chrome, Firefox, Safari, Edge)
   - Update browser to latest version

2. **Check JavaScript Console:**
   - Look for browser-specific errors
   - Check for unsupported features

3. **Test Responsive Design:**
   - Check mobile compatibility
   - Test different screen sizes

## Getting Help

### Log Files to Check

1. **Odoo Logs:**
   ```bash
   tail -f /var/log/odoo/odoo.log
   ```

2. **PostgreSQL Logs:**
   ```bash
   tail -f /var/log/postgresql/postgresql-*.log
   ```

3. **System Logs:**
   ```bash
   journalctl -u odoo -f
   ```

### Debug Mode

Enable debug mode in Odoo for more detailed error messages:

1. **Edit Odoo Configuration:**
   ```ini
   [options]
   log_level = debug
   ```

2. **Restart Odoo:**
   ```bash
   sudo systemctl restart odoo
   ```

### Contact Information

For additional help:
- Check the main README.md file
- Review Odoo documentation
- Contact your system administrator
- Check Odoo community forums

## Prevention

### Best Practices

1. **Regular Testing:**
   - Run test suite regularly
   - Test after configuration changes
   - Monitor performance

2. **Security:**
   - Use strong passwords
   - Limit database user permissions
   - Keep software updated

3. **Backup:**
   - Regular database backups
   - Configuration backups
   - Test restore procedures

4. **Monitoring:**
   - Monitor system resources
   - Check logs regularly
   - Set up alerts for issues 