#!/usr/bin/env python3
"""
Standalone Test Suite for Database Data Viewer Module
====================================================

This test suite can run without Odoo dependencies to test core functionality.
"""

import unittest
import sys
import os
import tempfile
import json
from unittest.mock import Mock, patch, MagicMock
import sqlite3
import html

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Mock Odoo imports
class MockOdoo:
    class models:
        class Model:
            pass
        
        class TransientModel:
            pass
    
    class fields:
        Char = str
        Text = str
        Integer = int
        Boolean = bool
        Selection = list
        Many2one = str
        One2many = list
        Many2many = list
        Date = str
        Datetime = str
        Binary = bytes
        Html = str
    
    class api:
        @staticmethod
        def depends(*args):
            def decorator(func):
                return func
            return decorator
        
        @staticmethod
        def onchange(*args):
            def decorator(func):
                return func
            return decorator
        
        @staticmethod
        def model(*args):
            def decorator(func):
                return func
            return decorator
        
        @staticmethod
        def multi(*args):
            def decorator(func):
                return func
            return decorator
    
    class exceptions:
        class ValidationError(Exception):
            pass
        
        class UserError(Exception):
            pass
    
    class tools:
        @staticmethod
        def config_get(key, default=None):
            return default
    
    class http:
        class Controller:
            pass
        
        class request:
            @staticmethod
            def render(template, values):
                return f"<html>{values}</html>"
        
        class Response:
            def __init__(self, data, content_type='text/html'):
                self.data = data
                self.content_type = content_type

# Mock the odoo module
sys.modules['odoo'] = MockOdoo()
sys.modules['odoo.models'] = MockOdoo.models
sys.modules['odoo.fields'] = MockOdoo.fields
sys.modules['odoo.api'] = MockOdoo.api
sys.modules['odoo.exceptions'] = MockOdoo.exceptions
sys.modules['odoo.tools'] = MockOdoo.tools
sys.modules['odoo.http'] = MockOdoo.http

# Now we can import our modules
try:
    from models.database_viewer import DatabaseViewer
    from commands.build_interface import BuildInterfaceCommand
    MODULES_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not import modules: {e}")
    MODULES_AVAILABLE = False


class TestDatabaseViewer(unittest.TestCase):
    """Test the DatabaseViewer model functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        # Create a temporary SQLite database for testing
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        # Create test data
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self.cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE products (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                price REAL,
                category TEXT
            )
        ''')
        
        # Insert test data
        self.cursor.execute('''
            INSERT INTO users (name, email, age) VALUES 
            ('John Doe', 'john@example.com', 30),
            ('Jane Smith', 'jane@example.com', 25),
            ('Bob Johnson', 'bob@example.com', 35)
        ''')
        
        self.cursor.execute('''
            INSERT INTO products (name, price, category) VALUES 
            ('Laptop', 999.99, 'Electronics'),
            ('Phone', 599.99, 'Electronics'),
            ('Book', 19.99, 'Books')
        ''')
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_validate_connection_params(self):
        """Test connection parameter validation."""
        viewer = DatabaseViewer()
        
        # Test valid parameters
        valid_params = {
            'host': 'localhost',
            'port': 5432,
            'database': 'testdb',
            'username': 'testuser',
            'password': 'testpass'
        }
        
        # This should not raise an exception
        try:
            viewer._validate_connection_params(valid_params)
        except Exception as e:
            self.fail(f"Valid parameters should not raise exception: {e}")
        
        # Test invalid parameters
        invalid_params = {
            'host': '',  # Empty host
            'port': 'invalid',  # Invalid port
            'database': '',  # Empty database
            'username': '',  # Empty username
            'password': ''  # Empty password
        }
        
        with self.assertRaises(Exception):
            viewer._validate_connection_params(invalid_params)
    
    def test_02_get_tables_sqlite(self):
        """Test getting tables from SQLite database."""
        viewer = DatabaseViewer()
        
        # Test with SQLite database
        tables = viewer._get_tables_sqlite(self.temp_db.name)
        
        self.assertIsInstance(tables, list)
        self.assertIn('users', tables)
        self.assertIn('products', tables)
    
    def test_03_get_table_data_sqlite(self):
        """Test getting data from SQLite table."""
        viewer = DatabaseViewer()
        
        # Test getting users table data
        data = viewer._get_table_data_sqlite(self.temp_db.name, 'users', limit=10)
        
        self.assertIsInstance(data, dict)
        self.assertIn('columns', data)
        self.assertIn('rows', data)
        self.assertEqual(len(data['rows']), 3)  # 3 users
        self.assertEqual(len(data['columns']), 4)  # id, name, email, age
    
    def test_04_sanitize_sql_identifier(self):
        """Test SQL identifier sanitization."""
        viewer = DatabaseViewer()
        
        # Test valid identifiers
        valid_identifiers = ['users', 'products', 'user_table', 'table_123']
        for identifier in valid_identifiers:
            sanitized = viewer._sanitize_sql_identifier(identifier)
            self.assertEqual(sanitized, identifier)
        
        # Test invalid identifiers (should be sanitized or rejected)
        invalid_identifiers = [
            'users; DROP TABLE users; --',
            'products\' OR 1=1 --',
            'table" UNION SELECT * FROM users --'
        ]
        
        for identifier in invalid_identifiers:
            with self.assertRaises(Exception):
                viewer._sanitize_sql_identifier(identifier)
    
    def test_05_escape_html(self):
        """Test HTML escaping."""
        viewer = DatabaseViewer()
        
        # Test HTML escaping
        test_data = [
            '<script>alert("xss")</script>',
            'User & Company < 100 > 50',
            'Line1\nLine2\tTabbed',
            'Normal text'
        ]
        
        expected_results = [
            '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;',
            'User &amp; Company &lt; 100 &gt; 50',
            'Line1\nLine2\tTabbed',
            'Normal text'
        ]
        
        for i, test_input in enumerate(test_data):
            result = viewer._escape_html(test_input)
            self.assertEqual(result, expected_results[i])


class TestBuildInterfaceCommand(unittest.TestCase):
    """Test the BuildInterfaceCommand functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        # Create a temporary SQLite database for testing
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        # Create test data
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        self.cursor.execute('''
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                value REAL
            )
        ''')
        
        self.cursor.execute('''
            INSERT INTO test_table (name, value) VALUES 
            ('Test1', 10.5),
            ('Test2', 20.7)
        ''')
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_command_initialization(self):
        """Test command initialization."""
        command = BuildInterfaceCommand()
        
        self.assertIsInstance(command, BuildInterfaceCommand)
        self.assertIsInstance(command.help, str)
        self.assertGreater(len(command.help), 0)
    
    def test_02_generate_html_content(self):
        """Test HTML content generation."""
        command = BuildInterfaceCommand()
        
        # Mock database connection
        with patch('sqlite3.connect') as mock_connect:
            mock_conn = Mock()
            mock_cursor = Mock()
            
            # Mock table list
            mock_cursor.fetchall.return_value = [('test_table',)]
            
            # Mock table data
            mock_cursor.description = [('id',), ('name',), ('value',)]
            mock_cursor.fetchall.side_effect = [
                [('test_table',)],  # First call for tables
                [(1, 'Test1', 10.5), (2, 'Test2', 20.7)]  # Second call for data
            ]
            
            mock_conn.cursor.return_value = mock_cursor
            mock_connect.return_value = mock_conn
            
            # Generate HTML
            html_content = command._generate_html_content(
                'sqlite:///' + self.temp_db.name,
                'Test Database',
                'test_table'
            )
            
            # Verify HTML content
            self.assertIsInstance(html_content, str)
            self.assertIn('<!DOCTYPE html>', html_content)
            self.assertIn('Test Database', html_content)
            self.assertIn('test_table', html_content)
            self.assertIn('Test1', html_content)
            self.assertIn('Test2', html_content)
    
    def test_03_save_html_file(self):
        """Test HTML file saving."""
        command = BuildInterfaceCommand()
        
        test_html = '<html><body><h1>Test</h1></body></html>'
        test_filename = 'test_output.html'
        
        try:
            # Save HTML file
            command._save_html_file(test_html, test_filename)
            
            # Verify file exists and contains correct content
            self.assertTrue(os.path.exists(test_filename))
            
            with open(test_filename, 'r', encoding='utf-8') as f:
                content = f.read()
                self.assertEqual(content, test_html)
        
        finally:
            # Clean up
            if os.path.exists(test_filename):
                os.unlink(test_filename)


class TestSecurityFeatures(unittest.TestCase):
    """Test security features and protections."""
    
    def test_01_sql_injection_protection(self):
        """Test SQL injection protection."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        viewer = DatabaseViewer()
        
        # Test malicious table names
        malicious_tables = [
            "users; DROP TABLE users; --",
            "products' OR 1=1 --",
            'table" UNION SELECT * FROM users --',
            "table; INSERT INTO users VALUES (1, 'hacker', 'hack@evil.com'); --"
        ]
        
        for malicious_table in malicious_tables:
            with self.assertRaises(Exception):
                viewer._sanitize_sql_identifier(malicious_table)
    
    def test_02_xss_protection(self):
        """Test XSS protection through HTML escaping."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        viewer = DatabaseViewer()
        
        # Test XSS payloads
        xss_payloads = [
            '<script>alert("XSS")</script>',
            '<img src="x" onerror="alert(\'XSS\')">',
            '<iframe src="javascript:alert(\'XSS\')"></iframe>',
            '<svg onload="alert(\'XSS\')"></svg>'
        ]
        
        for payload in xss_payloads:
            escaped = viewer._escape_html(payload)
            # Verify that script tags are escaped
            self.assertNotIn('<script>', escaped)
            self.assertNotIn('javascript:', escaped)
            self.assertIn('&lt;', escaped)  # < should be escaped
            self.assertIn('&gt;', escaped)  # > should be escaped
    
    def test_03_input_validation(self):
        """Test input validation."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        viewer = DatabaseViewer()
        
        # Test invalid connection parameters
        invalid_params = [
            {'host': '', 'port': 5432, 'database': 'test', 'username': 'user', 'password': 'pass'},
            {'host': 'localhost', 'port': -1, 'database': 'test', 'username': 'user', 'password': 'pass'},
            {'host': 'localhost', 'port': 5432, 'database': '', 'username': 'user', 'password': 'pass'},
            {'host': 'localhost', 'port': 5432, 'database': 'test', 'username': '', 'password': 'pass'},
        ]
        
        for params in invalid_params:
            with self.assertRaises(Exception):
                viewer._validate_connection_params(params)


class TestErrorHandling(unittest.TestCase):
    """Test error handling and edge cases."""
    
    def test_01_database_connection_errors(self):
        """Test database connection error handling."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        viewer = DatabaseViewer()
        
        # Test with invalid database path
        with self.assertRaises(Exception):
            viewer._get_tables_sqlite('/nonexistent/database.db')
        
        # Test with invalid table name
        with self.assertRaises(Exception):
            viewer._get_table_data_sqlite('/nonexistent/database.db', 'nonexistent_table')
    
    def test_02_empty_database(self):
        """Test handling of empty database."""
        if not MODULES_AVAILABLE:
            self.skipTest("Modules not available")
        
        # Create empty database
        temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        temp_db.close()
        
        try:
            conn = sqlite3.connect(temp_db.name)
            conn.close()
            
            viewer = DatabaseViewer()
            tables = viewer._get_tables_sqlite(temp_db.name)
            
            # Should return empty list, not raise exception
            self.assertEqual(tables, [])
        
        finally:
            os.unlink(temp_db.name)


def run_standalone_tests():
    """Run the standalone test suite."""
    print("🔍 Database Data Viewer Module - Standalone Test Suite")
    print("=" * 60)
    print()
    
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test classes
    test_classes = [
        TestDatabaseViewer,
        TestBuildInterfaceCommand,
        TestSecurityFeatures,
        TestErrorHandling
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 STANDALONE TEST RESULTS SUMMARY")
    print("=" * 60)
    print(f"Total Tests Run: {result.testsRun}")
    print(f"Passed: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failed: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success Rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print("\n💥 FAILURES:")
        print("-" * 30)
        for test, traceback in result.failures:
            print(f"• {test}: {traceback.split('AssertionError:')[-1].strip()}")
    
    if result.errors:
        print("\n❌ ERRORS:")
        print("-" * 30)
        for test, traceback in result.errors:
            print(f"• {test}: {traceback.split('Exception:')[-1].strip()}")
    
    if result.wasSuccessful():
        print("\n✅ ALL TESTS PASSED!")
        return 0
    else:
        print("\n❌ SOME TESTS FAILED!")
        return 1


if __name__ == '__main__':
    sys.exit(run_standalone_tests()) 