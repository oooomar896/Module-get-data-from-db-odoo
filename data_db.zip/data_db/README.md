# Database Data Viewer Module

A comprehensive Odoo module that provides multiple ways to view data from PostgreSQL databases including web interface, command-line tool, and direct Odoo HTML display.

## Features / المميزات

- **Web Interface**: Interactive HTML page accessible directly from Odoo
- **Odoo HTML Display**: Show data directly in Odoo interface with beautiful HTML formatting
- **Database Connection Management**: Configure multiple database connections
- **Real-time Data Display**: View data dynamically without page refresh
- **Table Browsing**: Click to expand and view table data
- **Custom Queries**: Execute custom SQL queries
- **Export Capabilities**: Export data in various formats
- **Security**: Proper access controls and password protection
- **Responsive Design**: Works on desktop and mobile devices
- **Comprehensive Testing**: Full test suite with unit, integration, and security tests

## Installation / التثبيت

### Prerequisites / المتطلبات الأساسية

1. **Python Dependencies**:
   ```bash
   pip install psycopg2-binary
   ```

2. **Odoo Installation**: Make sure you have Odoo installed and running

### Module Installation / تثبيت الوحدة

1. **Copy the module** to your Odoo addons directory:
   ```bash
   cp -r data_db /path/to/odoo/addons/
   ```

2. **Update the addons list** in Odoo:
   - Go to Apps → Update Apps List
   - Or restart Odoo server

3. **Install the module**:
   - Go to Apps → Search for "Database Data Viewer"
   - Click Install

## Configuration / الإعداد

### 1. Database Connection Setup / إعداد الاتصال بقاعدة البيانات

1. Go to **Tools → Database Viewer**
2. Click **Create** to add a new database connection
3. Fill in the connection details:
   - **Name**: A descriptive name for this connection
   - **Host**: Database server hostname (default: localhost)
   - **Port**: Database port (default: 5432)
   - **Database**: Database name
   - **Username**: Database username
   - **Password**: Database password
   - **Active**: Check to enable this connection

4. Click **Test Connection** to verify the settings
5. Click **Get Tables** to see available tables
6. Save the configuration

## Usage / الاستخدام

### 🖥️ Odoo HTML Display (Recommended) / عرض HTML في Odoo (موصى به)

#### Method 1: From Database Configuration / الطريقة الأولى: من إعدادات قاعدة البيانات
1. Go to **Tools → Database Viewer**
2. Open your database configuration
3. Click **"Show Data in Odoo"** button
4. Configure display options:
   - Select specific tables (optional)
   - Set rows per table limit
5. Click **"Generate Data Display"**
6. View beautiful HTML formatted data directly in Odoo

#### Method 2: From Menu / الطريقة الثانية: من القائمة
1. Go to **Tools → Show Data in Odoo**
2. Select your database configuration
3. Configure display options
4. Click **"Generate Data Display"**

### 🌐 Web Interface / الواجهة الإلكترونية

#### Method 1: From Menu / الطريقة الأولى: من القائمة
1. Go to **Tools → Open Web Viewer**
2. The database viewer will open in a new tab
3. Click on any table to view its data
4. Data loads dynamically as you browse

#### Method 2: From Configuration / الطريقة الثانية: من الإعدادات
1. Go to **Tools → Database Viewer**
2. Open your database configuration
3. Click **"Open Web Viewer"** button
4. The interface will open in a new tab

### 📊 Display Features / مميزات العرض

#### Odoo HTML Display Features / مميزات عرض HTML في Odoo
- **Beautiful HTML Formatting**: Professional styling with gradients and modern design
- **Inline Styling**: All styles embedded for consistent display
- **Table Selection**: Choose specific tables to display
- **Row Limits**: Control how many rows to show per table
- **Responsive Tables**: Horizontal scroll for wide tables
- **Data Truncation**: Long values are truncated with ellipsis
- **Error Handling**: Clear error messages for failed operations
- **Statistics Dashboard**: Shows total tables and rows

#### Web Interface Features / مميزات الواجهة الإلكترونية
- **Interactive Tables**: Click to expand/collapse table data
- **Real-time Loading**: Data loads only when you click on a table
- **Statistics Dashboard**: Shows total tables, rows, and loaded tables
- **Database Connection Info**: Displays connection details with clickable link
- **Responsive Design**: Works on all devices
- **Error Handling**: Clear error messages if something goes wrong

### 💻 Command Line Interface / واجهة سطر الأوامر

#### Generate Static HTML File / إنشاء ملف HTML ثابت

```bash
# Navigate to your Odoo installation
cd /path/to/odoo

# Run the build interface command
python -m odoo -d your_database_name --stop-after-init -i data_db
python commands/build_interface.py
```

The HTML file will be generated in:
```
/path/to/odoo/data/database_data_viewer.html
```

#### Odoo Shell Method / طريقة Odoo Shell

```python
# Start Odoo shell
python odoo-bin shell -d your_database_name

# In the shell, run:
from data_db.commands.build_interface import build_database_html_interface
env = self.env
build_database_html_interface(env)
```

### 🔍 Custom Queries / استعلامات مخصصة

You can execute custom SQL queries through the Odoo interface:

```python
# In Odoo shell or through API
viewer = env['database.viewer'].search([('active', '=', True)])[0]
result = viewer.execute_custom_query("SELECT * FROM your_table LIMIT 10")
```

## Testing / الاختبار

### Running Tests / تشغيل الاختبارات

The module includes a comprehensive test suite covering unit tests, integration tests, and security tests.

#### Run All Tests / تشغيل جميع الاختبارات

```bash
# From the module directory
python run_tests.py
```

#### Run Security Tests Only / تشغيل اختبارات الأمان فقط

```bash
python run_tests.py security
```

#### Run Specific Test / تشغيل اختبار محدد

```bash
python run_tests.py specific test_01_create_database_viewer
```

#### Run Tests with Odoo / تشغيل الاختبارات مع Odoo

```bash
# From Odoo installation directory
python odoo-bin -d your_database_name --test-enable --test-tags data_db
```

### Test Coverage / تغطية الاختبارات

The test suite includes:

#### Unit Tests / اختبارات الوحدات
- **Database Viewer Model Tests**: Connection, data retrieval, validation
- **Controller Tests**: Web interface and API endpoints
- **Command Line Tests**: Static HTML generation
- **Security Tests**: SQL injection protection, XSS prevention

#### Integration Tests / اختبارات التكامل
- **Complete Workflow Tests**: End-to-end functionality
- **Error Recovery Tests**: Handling of failures and errors
- **Multiple Configuration Tests**: Managing multiple database connections
- **Large Dataset Tests**: Performance with large amounts of data
- **Concurrent Access Tests**: Multiple simultaneous requests

#### Security Tests / اختبارات الأمان
- **SQL Injection Protection**: Prevents malicious SQL queries
- **XSS Protection**: Escapes HTML content to prevent cross-site scripting
- **Input Validation**: Validates all user inputs
- **Parameter Limits**: Prevents resource exhaustion attacks
- **Authentication**: Ensures proper access controls

### Test Results / نتائج الاختبارات

The test runner provides detailed reports including:
- Total tests run
- Passed/Failed/Error counts
- Success rate percentage
- Execution time
- Detailed error messages for failures

Example output:
```
🔍 Database Data Viewer Module - Test Suite
============================================================
Started at: 2024-01-15 10:30:00

📋 Found 45 test cases

📊 TEST RESULTS SUMMARY
============================================================
Total Tests Run: 45
Passed: 43
Failed: 1
Errors: 1
Skipped: 0
Success Rate: 95.6%
Execution Time: 12.34 seconds

✅ ALL TESTS PASSED!
```

## API Endpoints / نقاط النهاية API

The module provides REST API endpoints for programmatic access:

- `GET /database-viewer` - Main web interface
- `GET /database-viewer/api/table-data/<table_name>` - Get table data
- `GET /database-viewer/api/stats` - Get database statistics

## Security / الأمان

- **Password Protection**: Database passwords are stored securely
- **Access Control**: Only authorized users can access database connections
- **Connection Validation**: All connections are tested before use
- **Error Handling**: Comprehensive error handling and logging
- **User Authentication**: Web interface requires Odoo user login
- **SQL Injection Protection**: Parameterized queries and input validation
- **XSS Protection**: HTML content is properly escaped
- **Input Validation**: All user inputs are validated and sanitized
- **Resource Limits**: Query limits prevent resource exhaustion

## Troubleshooting / حل المشاكل

### Common Issues / المشاكل الشائعة

1. **Connection Failed**:
   - Verify database credentials
   - Check if PostgreSQL is running
   - Ensure network connectivity

2. **Module Not Found**:
   - Check addons path configuration
   - Restart Odoo server
   - Update apps list

3. **Permission Denied**:
   - Check file permissions
   - Verify user access rights
   - Ensure proper Odoo user permissions

4. **Web Interface Not Loading**:
   - Check if Odoo server is running
   - Verify user is logged in
   - Check browser console for JavaScript errors

5. **HTML Display Not Working**:
   - Check if database connection is active
   - Verify table names are correct
   - Check Odoo logs for errors

6. **Tests Failing**:
   - Ensure all dependencies are installed
   - Check database connectivity for integration tests
   - Verify Odoo configuration is correct

### Logs / السجلات

Check Odoo logs for detailed error information:
```bash
tail -f /var/log/odoo/odoo.log
```

### Test Debugging / تصحيح الاختبارات

If tests are failing, you can run individual tests for debugging:

```bash
# Run a specific test class
python -m unittest tests.test_database_viewer.TestDatabaseViewer

# Run a specific test method
python -m unittest tests.test_database_viewer.TestDatabaseViewer.test_01_create_database_viewer
```

## File Structure / هيكل الملفات

```
data_db/
├── __init__.py                 # Module initialization
├── __manifest__.py            # Module manifest
├── requirements.txt           # Python dependencies
├── README.md                  # This file
├── run_tests.py              # Test runner script
├── models/
│   ├── __init__.py
│   └── database_viewer.py     # Main model with HTML generation
├── commands/
│   ├── __init__.py
│   └── build_interface.py     # Command line tool
├── controllers/
│   ├── __init__.py
│   └── main.py               # Web interface controller
├── views/
│   └── database_viewer_views.xml  # Odoo views including HTML display
├── tests/
│   ├── __init__.py
│   ├── test_database_viewer.py    # Model tests
│   ├── test_controllers.py        # Controller tests
│   ├── test_commands.py           # Command line tests
│   └── test_integration.py        # Integration tests
├── static/description/
│   └── index.html            # Module description
└── security/
    └── ir.model.access.csv    # Access rights
```

## Support / الدعم

For issues and questions:
- Check the troubleshooting section
- Review Odoo logs
- Run the test suite to identify problems
- Contact your system administrator

## License / الترخيص

This module is provided as-is for educational and development purposes.

---

**Note**: This module requires proper database permissions and should be used in secure environments only. Always run tests before deploying to production. 