# Database Data Viewer - Security Guide

## Security Overview

The Database Data Viewer module implements comprehensive security measures to protect against common web application vulnerabilities and ensure safe database access.

## Security Features

### 1. SQL Injection Protection

#### Input Validation
```python
def _validate_table_name(self, table_name):
    """Validate table name to prevent SQL injection"""
    if not table_name or not isinstance(table_name, str):
        raise UserError("Invalid table name")
    
    # Check for dangerous characters
    dangerous_chars = [';', "'", '"', '--', '/*', '*/', 'DROP', 'DELETE', 'UPDATE', 'INSERT', 'CREATE', 'ALTER', 'TRUNCATE']
    
    for char in dangerous_chars:
        if char.upper() in table_name.upper():
            raise UserError(f"Table name contains forbidden keyword: {char}")
    
    return table_name
```

#### Parameterized Queries
```python
# Use parameterized queries instead of string concatenation
cursor.execute('SELECT * FROM "{}" LIMIT %s OFFSET %s'.format(table_name), (limit, offset))
```

#### Query Whitelisting
```python
def execute_custom_query(self, query):
    """Execute custom query with security restrictions"""
    # Only allow SELECT queries
    forbidden_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'CREATE', 'ALTER', 'TRUNCATE', 'EXEC', 'EXECUTE']
    
    for keyword in forbidden_keywords:
        if keyword.upper() in query.upper():
            raise UserError(f"Query contains forbidden keyword: {keyword}")
    
    # Validate query starts with SELECT
    if not query.strip().upper().startswith('SELECT'):
        raise UserError("Only SELECT queries are allowed")
```

### 2. Cross-Site Scripting (XSS) Protection

#### HTML Escaping
```python
import html

def escape_html(text):
    """Escape HTML content to prevent XSS"""
    if text is None:
        return '<em>null</em>'
    
    # Convert to string and escape HTML
    text_str = str(text)
    escaped_text = html.escape(text_str)
    
    # Truncate long values
    if len(escaped_text) > 100:
        escaped_text = escaped_text[:100] + '...'
    
    return escaped_text
```

#### Content Security Policy
```html
<!-- Add CSP headers in web interface -->
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';">
```

#### Input Sanitization
```python
def sanitize_input(input_data):
    """Sanitize user input"""
    if isinstance(input_data, str):
        # Remove potentially dangerous characters
        dangerous_chars = ['<script>', '</script>', 'javascript:', 'onerror=', 'onload=']
        for char in dangerous_chars:
            input_data = input_data.replace(char, '')
    
    return input_data
```

### 3. Authentication and Authorization

#### Odoo User Authentication
```python
from odoo.http import request

def require_authentication(func):
    """Decorator to require user authentication"""
    def wrapper(*args, **kwargs):
        if not request.env.user.id:
            raise AccessError("Authentication required")
        return func(*args, **kwargs)
    return wrapper
```

#### Access Control
```python
# Security access rights defined in ir.model.access.csv
# database.viewer,access_database_viewer_user,database.viewer,model_database_viewer,base.group_user,1,1,1,1
# database.data.display,access_database_data_display_user,database.data.display,model_database_data_display,base.group_user,1,1,1,1
```

#### Role-Based Access
```python
def check_user_permissions(self):
    """Check if user has required permissions"""
    user = self.env.user
    
    # Check if user is admin or has specific group
    if not user.has_group('base.group_system'):
        raise AccessError("Insufficient permissions")
```

### 4. Input Validation

#### Comprehensive Validation
```python
def validate_database_config(self, config_data):
    """Validate database configuration data"""
    required_fields = ['name', 'host', 'port', 'database', 'username', 'password']
    
    for field in required_fields:
        if not config_data.get(field):
            raise UserError(f"Missing required field: {field}")
    
    # Validate port number
    try:
        port = int(config_data['port'])
        if port < 1 or port > 65535:
            raise UserError("Invalid port number")
    except ValueError:
        raise UserError("Port must be a number")
    
    # Validate host
    host = config_data['host']
    if not host or len(host) > 255:
        raise UserError("Invalid host name")
    
    # Validate database name
    db_name = config_data['database']
    if not db_name or len(db_name) > 63:
        raise UserError("Invalid database name")
```

#### Parameter Limits
```python
def validate_parameters(self, limit=None, offset=None):
    """Validate and limit query parameters"""
    # Limit maximum rows to prevent resource exhaustion
    if limit is not None:
        limit = max(1, min(limit, 1000))  # Between 1 and 1000
    
    # Ensure offset is non-negative
    if offset is not None:
        offset = max(0, offset)
    
    return limit, offset
```

### 5. Error Handling and Information Disclosure

#### Safe Error Messages
```python
def safe_error_message(self, error):
    """Return safe error message without sensitive information"""
    if isinstance(error, psycopg2.OperationalError):
        return "Database connection failed. Please check your configuration."
    elif isinstance(error, psycopg2.Error):
        return "Database error occurred. Please try again."
    else:
        return "An error occurred. Please contact your administrator."
```

#### Logging Security
```python
import logging

def log_security_event(self, event_type, details):
    """Log security events without sensitive data"""
    logger = logging.getLogger('security')
    
    # Sanitize details to remove sensitive information
    safe_details = self.sanitize_log_details(details)
    
    logger.warning(f"Security event: {event_type} - {safe_details}")
```

### 6. Database Security

#### Connection Security
```python
def secure_database_connection(self):
    """Establish secure database connection"""
    try:
        connection = psycopg2.connect(
            host=self.host,
            port=self.port,
            database=self.database,
            user=self.username,
            password=self.password,
            # Security settings
            sslmode='prefer',  # Use SSL if available
            connect_timeout=10,  # Connection timeout
            options='-c statement_timeout=30000'  # Query timeout
        )
        
        # Set connection to read-only mode
        connection.set_session(autocommit=False, readonly=True)
        
        return connection
    except Exception as e:
        raise UserError(self.safe_error_message(e))
```

#### Query Timeouts
```python
def execute_with_timeout(self, query, timeout=30):
    """Execute query with timeout"""
    import signal
    
    def timeout_handler(signum, frame):
        raise TimeoutError("Query execution timeout")
    
    # Set timeout
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(timeout)
    
    try:
        result = self.execute_query(query)
        signal.alarm(0)  # Cancel timeout
        return result
    except TimeoutError:
        raise UserError("Query execution timed out")
```

### 7. Session Security

#### Session Management
```python
def validate_session(self):
    """Validate user session"""
    if not self.env.user.id:
        raise AccessError("Invalid session")
    
    # Check session timeout
    session_timeout = 3600  # 1 hour
    if hasattr(self.env.user, 'last_activity'):
        if time.time() - self.env.user.last_activity > session_timeout:
            raise AccessError("Session expired")
```

#### CSRF Protection
```python
# Odoo automatically includes CSRF protection
# All forms include CSRF tokens
```

### 8. File Security

#### File Upload Validation
```python
def validate_file_upload(self, file_data):
    """Validate file uploads"""
    allowed_extensions = ['.csv', '.json', '.txt']
    max_file_size = 10 * 1024 * 1024  # 10MB
    
    # Check file size
    if len(file_data) > max_file_size:
        raise UserError("File too large")
    
    # Check file extension
    file_extension = os.path.splitext(file_name)[1].lower()
    if file_extension not in allowed_extensions:
        raise UserError("Invalid file type")
```

#### Path Traversal Protection
```python
import os

def safe_file_path(self, file_path):
    """Ensure file path is safe"""
    # Normalize path
    normalized_path = os.path.normpath(file_path)
    
    # Check for path traversal attempts
    if '..' in normalized_path or normalized_path.startswith('/'):
        raise UserError("Invalid file path")
    
    return normalized_path
```

### 9. Network Security

#### HTTPS Enforcement
```python
def require_https(self):
    """Require HTTPS for sensitive operations"""
    if not request.is_secure():
        raise UserError("HTTPS required for this operation")
```

#### IP Whitelisting
```python
def check_ip_whitelist(self):
    """Check if client IP is in whitelist"""
    client_ip = request.httprequest.remote_addr
    allowed_ips = ['127.0.0.1', '::1', '192.168.1.0/24']
    
    for allowed_ip in allowed_ips:
        if self.ip_in_range(client_ip, allowed_ip):
            return True
    
    raise AccessError("Access denied from this IP address")
```

### 10. Audit Logging

#### Security Audit Trail
```python
def log_security_audit(self, action, user, details):
    """Log security audit events"""
    audit_log = self.env['security.audit.log'].create({
        'user_id': user.id,
        'action': action,
        'details': details,
        'ip_address': request.httprequest.remote_addr,
        'user_agent': request.httprequest.headers.get('User-Agent'),
        'timestamp': fields.Datetime.now(),
    })
```

#### Database Access Logging
```python
def log_database_access(self, table_name, operation):
    """Log database access operations"""
    logger = logging.getLogger('database_access')
    logger.info(f"Database access: {operation} on table {table_name} by user {self.env.user.name}")
```

## Security Best Practices

### 1. Configuration Security

#### Secure Defaults
```python
# Use secure defaults
DEFAULT_PORT = 5432
DEFAULT_TIMEOUT = 30
MAX_ROWS = 1000
ALLOWED_QUERY_TYPES = ['SELECT']
```

#### Environment Variables
```python
import os

# Use environment variables for sensitive data
DATABASE_PASSWORD = os.environ.get('DATABASE_PASSWORD')
API_KEY = os.environ.get('API_KEY')
```

### 2. Code Security

#### Input Validation
- Always validate and sanitize user input
- Use parameterized queries
- Implement proper error handling
- Avoid string concatenation in queries

#### Output Encoding
- Escape all output data
- Use proper content types
- Implement CSP headers
- Validate file uploads

### 3. Infrastructure Security

#### Network Security
- Use HTTPS for all communications
- Implement proper firewall rules
- Use VPN for remote access
- Monitor network traffic

#### Database Security
- Use strong passwords
- Implement connection encryption
- Regular security updates
- Access logging and monitoring

### 4. Monitoring and Alerting

#### Security Monitoring
```python
def monitor_security_events(self):
    """Monitor security events"""
    # Monitor failed login attempts
    # Monitor unusual access patterns
    # Monitor system resource usage
    # Alert on security violations
```

#### Incident Response
```python
def handle_security_incident(self, incident_type, details):
    """Handle security incidents"""
    # Log the incident
    # Block suspicious IPs
    # Notify administrators
    # Take corrective action
```

## Security Checklist

### Before Deployment

- [ ] **Input Validation**
  - [ ] All user inputs are validated
  - [ ] SQL injection protection implemented
  - [ ] XSS protection implemented
  - [ ] File upload validation

- [ ] **Authentication & Authorization**
  - [ ] User authentication required
  - [ ] Role-based access control
  - [ ] Session management
  - [ ] Password policies

- [ ] **Data Protection**
  - [ ] Sensitive data encrypted
  - [ ] Database connections secured
  - [ ] Audit logging enabled
  - [ ] Backup security

- [ ] **Network Security**
  - [ ] HTTPS enforced
  - [ ] Firewall configured
  - [ ] IP restrictions
  - [ ] Rate limiting

### Regular Security Review

- [ ] **Vulnerability Assessment**
  - [ ] Regular security scans
  - [ ] Dependency updates
  - [ ] Code security review
  - [ ] Penetration testing

- [ ] **Monitoring**
  - [ ] Security event monitoring
  - [ ] Access log review
  - [ ] Performance monitoring
  - [ ] Error tracking

- [ ] **Updates**
  - [ ] Security patches applied
  - [ ] Dependencies updated
  - [ ] Configuration reviewed
  - [ ] Documentation updated

## Security Testing

### Automated Security Tests

```python
def test_sql_injection_protection(self):
    """Test SQL injection protection"""
    malicious_inputs = [
        "'; DROP TABLE users; --",
        "' OR 1=1; --",
        "'; INSERT INTO users VALUES (1, 'hacker'); --"
    ]
    
    for malicious_input in malicious_inputs:
        with self.assertRaises(UserError):
            self.database_viewer._validate_table_name(malicious_input)
```

### Manual Security Testing

1. **SQL Injection Testing**
   - Test with malicious SQL queries
   - Verify input validation
   - Check error handling

2. **XSS Testing**
   - Test with script tags
   - Verify HTML escaping
   - Check CSP headers

3. **Authentication Testing**
   - Test unauthorized access
   - Verify session management
   - Check password policies

4. **Authorization Testing**
   - Test role-based access
   - Verify permission checks
   - Check data isolation

## Incident Response

### Security Incident Response Plan

1. **Detection**
   - Monitor security events
   - Identify suspicious activity
   - Alert security team

2. **Assessment**
   - Evaluate incident severity
   - Identify affected systems
   - Determine root cause

3. **Containment**
   - Isolate affected systems
   - Block malicious access
   - Preserve evidence

4. **Eradication**
   - Remove security threats
   - Patch vulnerabilities
   - Update security measures

5. **Recovery**
   - Restore affected systems
   - Verify security measures
   - Monitor for recurrence

6. **Lessons Learned**
   - Document incident details
   - Update security procedures
   - Train staff on lessons learned

## Conclusion

Security is an ongoing process that requires constant vigilance and regular updates. This module implements multiple layers of security to protect against common vulnerabilities while maintaining usability.

Remember to:
- Regularly update security measures
- Monitor for security threats
- Train users on security best practices
- Maintain security documentation
- Conduct regular security audits 