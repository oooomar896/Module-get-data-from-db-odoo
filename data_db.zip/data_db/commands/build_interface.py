import os
import sys
from odoo import api, SUPERUSER_ID
from odoo.tools import config
from odoo.modules.registry import Registry
from odoo.service import db
import logging

_logger = logging.getLogger(__name__)

def build_database_html_interface(env):
    """Build HTML interface for database data"""
    try:
        DatabaseViewer = env['database.viewer']
        viewers = DatabaseViewer.search([('active', '=', True)])
        
        if not viewers:
            print('❌ No active database viewer configuration found.')
            print('Please configure a database connection in Odoo first.')
            return False
        
        viewer = viewers[0]
        print(f'🔍 Building HTML interface for database: {viewer.database}')
        
        # Get table list
        try:
            tables = viewer.get_table_list()
            print(f'📋 Found {len(tables)} tables')
        except Exception as e:
            print(f'❌ Error getting table list: {str(e)}')
            return False
        
        # Generate HTML content
        html_content = generate_html_content(viewer, tables)
        
        # Write to file
        output_path = os.path.join(config['data_dir'], 'database_data_viewer.html')
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f'✅ HTML interface generated successfully at: {output_path}')
            return True
        except Exception as e:
            print(f'❌ Error writing HTML file: {str(e)}')
            return False
            
    except Exception as e:
        print(f'❌ Error building HTML interface: {str(e)}')
        return False

def generate_html_content(viewer, tables):
    """Generate HTML content for the database viewer"""
    
    # Start HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Database Data Viewer - {viewer.database}</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }}
        .connection-info {{
            background: #ecf0f1;
            padding: 20px;
            margin: 20px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
        }}
        .connection-info h3 {{
            margin-top: 0;
            color: #2c3e50;
        }}
        .db-link {{
            color: #3498db;
            text-decoration: none;
            font-weight: bold;
        }}
        .db-link:hover {{
            text-decoration: underline;
        }}
        .tables-section {{
            padding: 20px;
        }}
        .table-card {{
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
        }}
        .table-header {{
            background: #6c757d;
            color: white;
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .table-content {{
            padding: 20px;
        }}
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 14px;
        }}
        .data-table th, .data-table td {{
            border: 1px solid #dee2e6;
            padding: 8px 12px;
            text-align: left;
            word-wrap: break-word;
            max-width: 200px;
        }}
        .data-table th {{
            background: #495057;
            color: white;
            font-weight: 600;
        }}
        .data-table tr:nth-child(even) {{
            background: #f8f9fa;
        }}
        .data-table tr:hover {{
            background: #e9ecef;
        }}
        .stats {{
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        .stat-card {{
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            flex: 1;
            text-align: center;
            min-width: 150px;
        }}
        .stat-number {{
            font-size: 2em;
            font-weight: bold;
            color: #3498db;
        }}
        .stat-label {{
            color: #6c757d;
            margin-top: 5px;
        }}
        .error {{
            color: #dc3545;
            background: #f8d7da;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }}
        @media (max-width: 768px) {{
            .stats {{
                flex-direction: column;
            }}
            .data-table {{
                font-size: 12px;
            }}
            .data-table th, .data-table td {{
                padding: 6px 8px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Database Data Viewer</h1>
            <p>Static Database Explorer</p>
        </div>
        
        <div class="connection-info">
            <h3>📊 Database Connection</h3>
            <p><strong>Database:</strong> {viewer.database}</p>
            <p><strong>Host:</strong> {viewer.host}:{viewer.port}</p>
            <p><strong>User:</strong> {viewer.username}</p>
            <p><strong>Connection String:</strong> 
                <a href="postgresql://{viewer.username}:{viewer.password}@{viewer.host}:{viewer.port}/{viewer.database}" 
                   class="db-link" target="_blank">
                    postgresql://{viewer.username}@{viewer.host}/{viewer.database}
                </a>
            </p>
        </div>
        
        <div class="tables-section">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number">{len(tables)}</div>
                    <div class="stat-label">Total Tables</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="total-rows">-</div>
                    <div class="stat-label">Total Rows</div>
                </div>
            </div>
            
            <h2>📋 Database Tables</h2>
            <p>Showing data from all tables:</p>
"""
    
    # Add tables
    total_rows = 0
    for table in tables:
        try:
            print(f'📄 Processing table: {table}')
            data = viewer.get_table_data(table, limit=20)
            total_rows += data['total_rows']
            
            html += f"""
            <div class="table-card">
                <div class="table-header">
                    <span>📄 {table}</span>
                    <span>({data['total_rows']} rows)</span>
                </div>
                <div class="table-content">
"""
            
            if data['data']:
                html += '<table class="data-table"><thead><tr>'
                for col in data['columns']:
                    html += f'<th>{col["name"]}</th>'
                html += '</tr></thead><tbody>'
                
                for row in data['data']:
                    html += '<tr>'
                    for col in data['columns']:
                        value = row.get(col['name'], '')
                        if value is None:
                            html += '<td><em>null</em></td>'
                        else:
                            html += f'<td>{str(value)}</td>'
                    html += '</tr>'
                
                html += '</tbody></table>'
            else:
                html += '<p><em>No data found in this table.</em></p>'
            
            html += """
                </div>
            </div>
"""
            
        except Exception as e:
            print(f'⚠️  Error processing table {table}: {str(e)}')
            html += f"""
            <div class="table-card">
                <div class="table-header">
                    <span>📄 {table}</span>
                </div>
                <div class="table-content">
                    <div class="error">Error loading data: {str(e)}</div>
                </div>
            </div>
"""
    
    # Close HTML
    html += f"""
        </div>
    </div>
    
    <script>
        // Update total rows count
        document.getElementById('total-rows').textContent = '{total_rows:,}';
        
        // Add click to expand functionality
        document.querySelectorAll('.table-header').forEach(header => {{
            header.addEventListener('click', function() {{
                const content = this.nextElementSibling;
                if (content.style.display === 'none') {{
                    content.style.display = 'block';
                }} else {{
                    content.style.display = 'none';
                }}
            }});
        }});
    </script>
</body>
</html>
"""
    
    return html

def main():
    """Main function to run the command"""
    try:
        import odoo
        odoo.cli.server.setup_pid_file()
        odoo.tools.config.parse_config(['-c', config['config_file']])
        
        db_name = config['db_name']
        if not db_name:
            print('❌ No database specified. Use -d option to specify database.')
            return False
        
        registry = Registry(db_name)
        with registry.cursor() as cr:
            env = api.Environment(cr, SUPERUSER_ID, {})
            success = build_database_html_interface(env)
            return success
            
    except Exception as e:
        print(f'❌ Error: {str(e)}')
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1) 