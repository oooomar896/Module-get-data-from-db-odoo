odoo.define('data_db.database_viewer_realtime', function (require) {
    'use strict';

    const busService = require('bus.bus_service');
    const { onWillStart, onWillDestroy, useService } = require('@web/core/utils/hooks');
    const { Component, useState } = require('@web/core/utils/components');
    const { useRef } = require('@web/core/utils/hooks');

    class DatabaseViewerRealtime extends Component {
        setup() {
            this.state = useState({
                notifications: [],
                isConnected: false,
                lastActivity: null
            });
            
            this.busService = useService("bus_service");
            this.notificationRef = useRef("notificationContainer");
            
            onWillStart(() => {
                this._setupBusConnection();
            });
            
            onWillDestroy(() => {
                this._cleanupBusConnection();
            });
        }

        _setupBusConnection() {
            // Subscribe to database viewer channels
            const channels = ['database_viewer_global'];
            
            // Add specific viewer channels if we have viewer IDs
            if (this.props.viewerIds) {
                this.props.viewerIds.forEach(id => {
                    channels.push(`database_viewer_${id}`);
                });
            }

            channels.forEach(channel => {
                this.busService.addChannel(channel);
            });

            // Listen for notifications
            this.busService.on("notification", this, (notifications) => {
                notifications.forEach((notif) => {
                    this._handleNotification(notif);
                });
            });

            this.state.isConnected = true;
        }

        _handleNotification(notification) {
            const { payload } = notification;
            
            if (payload.type === 'table_activity') {
                this._showTableActivity(payload.data);
            } else if (payload.type === 'connection_status') {
                this._showConnectionStatus(payload.data);
            }
            
            this.state.lastActivity = new Date();
            this.state.notifications.unshift({
                ...payload,
                timestamp: new Date(),
                id: Date.now()
            });
            
            // Keep only last 10 notifications
            if (this.state.notifications.length > 10) {
                this.state.notifications.pop();
            }
        }

        _showTableActivity(data) {
            const message = `${data.user} viewed table ${data.table_name} in ${data.database}`;
            this._showToast(message, 'info');
        }

        _showConnectionStatus(data) {
            const icon = data.status === 'success' ? '✅' : '❌';
            const message = `${icon} ${data.message}`;
            this._showToast(message, data.status);
        }

        _showToast(message, type = 'info') {
            // Create toast notification
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.innerHTML = `
                <div class="toast-content">
                    <span class="toast-message">${message}</span>
                    <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
            `;
            
            // Add styles
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1'};
                color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460'};
                padding: 12px 20px;
                border-radius: 5px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 9999;
                max-width: 300px;
                animation: slideIn 0.3s ease-out;
            `;
            
            document.body.appendChild(toast);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 5000);
        }

        _cleanupBusConnection() {
            if (this.busService) {
                this.busService.off("notification", this);
            }
            this.state.isConnected = false;
        }

        // Method to manually send a notification (for testing)
        sendTestNotification() {
            this._showToast('Test notification from database viewer', 'info');
        }
    }

    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .toast-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .toast-close {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            margin-left: 10px;
            opacity: 0.7;
        }
        
        .toast-close:hover {
            opacity: 1;
        }
    `;
    document.head.appendChild(style);

    return DatabaseViewerRealtime;
}); 