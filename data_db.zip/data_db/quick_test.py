#!/usr/bin/env python3
"""
Quick Test Script for Real-time Features
سكريبت اختبار سريع للميزات في الوقت الفعلي
"""

import os
import sys
from datetime import datetime

def check_file_exists(file_path, description):
    """Check if file exists and print result"""
    if os.path.exists(file_path):
        print(f"✅ {description}: {file_path}")
        return True
    else:
        print(f"❌ {description}: {file_path} (NOT FOUND)")
        return False

def check_file_content(file_path, required_content, description):
    """Check if file contains required content"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        missing_content = []
        for item in required_content:
            if item not in content:
                missing_content.append(item)
        
        if not missing_content:
            print(f"✅ {description}: All required content found")
            return True
        else:
            print(f"❌ {description}: Missing content: {', '.join(missing_content)}")
            return False
            
    except FileNotFoundError:
        print(f"❌ {description}: File not found")
        return False
    except Exception as e:
        print(f"❌ {description}: Error reading file - {str(e)}")
        return False

def main():
    """Main test function"""
    print("🚀 Quick Test for Real-time Features")
    print("=" * 50)
    
    test_results = []
    
    # Test 1: Check Database Viewer Files
    print("\n📁 Checking Database Viewer Files:")
    
    db_viewer_files = [
        ('models/database_viewer.py', 'Database Viewer Model'),
        ('static/src/js/database_viewer_realtime.js', 'Database Viewer JavaScript'),
        ('controllers/main.py', 'Database Viewer Controller'),
        ('__manifest__.py', 'Module Manifest'),
        ('security/ir.model.access.csv', 'Security Rules'),
        ('views/database_viewer_views.xml', 'Database Viewer Views')
    ]
    
    for file_path, description in db_viewer_files:
        result = check_file_exists(file_path, description)
        test_results.append(('file_exists', file_path, result))
    
    # Test 2: Check Auction Module Files
    print("\n📁 Checking Auction Module Files:")
    
    auction_files = [
        ('../auction_module/__manifest__.py', 'Auction Module Manifest'),
        ('../auction_module/models/auction.py', 'Auction Model'),
        ('../auction_module/static/src/js/auction_realtime.js', 'Auction JavaScript'),
        ('../auction_module/controllers/auction_controller.py', 'Auction Controller')
    ]
    
    for file_path, description in auction_files:
        result = check_file_exists(file_path, description)
        test_results.append(('file_exists', file_path, result))
    
    # Test 3: Check Database Viewer Model Content
    print("\n🔍 Checking Database Viewer Model Content:")
    
    if check_file_exists('models/database_viewer.py', 'Database Viewer Model'):
        required_methods = [
            'send_realtime_update',
            'notify_table_update',
            'notify_connection_status',
            'from odoo.addons.bus.models.bus import dispatch'
        ]
        
        result = check_file_content('models/database_viewer.py', required_methods, 'Real-time Methods')
        test_results.append(('content_check', 'database_viewer_model', result))
    
    # Test 4: Check JavaScript Content
    print("\n🔍 Checking JavaScript Content:")
    
    if check_file_exists('static/src/js/database_viewer_realtime.js', 'Database Viewer JavaScript'):
        required_js_content = [
            'odoo.define',
            'busService',
            '_setupBusConnection',
            '_handleNotification',
            '_showToast'
        ]
        
        result = check_file_content('static/src/js/database_viewer_realtime.js', required_js_content, 'JavaScript Components')
        test_results.append(('content_check', 'database_viewer_js', result))
    
    # Test 5: Check Auction Model Content
    print("\n🔍 Checking Auction Model Content:")
    
    if check_file_exists('../auction_module/models/auction.py', 'Auction Model'):
        required_auction_content = [
            'class Auction',
            'place_bid',
            '_send_bid_update',
            '_send_auction_update',
            'bus.bus'
        ]
        
        result = check_file_content('../auction_module/models/auction.py', required_auction_content, 'Auction Methods')
        test_results.append(('content_check', 'auction_model', result))
    
    # Test 6: Check Manifest Dependencies
    print("\n🔍 Checking Manifest Dependencies:")
    
    if check_file_exists('__manifest__.py', 'Module Manifest'):
        required_manifest_content = [
            "'depends':",
            "'base'",
            "'web'"
        ]
        
        result = check_file_content('__manifest__.py', required_manifest_content, 'Manifest Dependencies')
        test_results.append(('content_check', 'manifest', result))
    
    # Test 7: Check Auction Manifest
    print("\n🔍 Checking Auction Manifest:")
    
    if check_file_exists('../auction_module/__manifest__.py', 'Auction Manifest'):
        required_auction_manifest = [
            "'depends':",
            "'base'",
            "'web'",
            "'bus'",
            "'mail'"
        ]
        
        result = check_file_content('../auction_module/__manifest__.py', required_auction_manifest, 'Auction Manifest Dependencies')
        test_results.append(('content_check', 'auction_manifest', result))
    
    # Test 8: Check Controller Endpoints
    print("\n🔍 Checking Controller Endpoints:")
    
    if check_file_exists('../auction_module/controllers/auction_controller.py', 'Auction Controller'):
        required_endpoints = [
            '@http.route',
            '/auction/get_status',
            '/auction/place_bid',
            '/auction/live/'
        ]
        
        result = check_file_content('../auction_module/controllers/auction_controller.py', required_endpoints, 'Auction Endpoints')
        test_results.append(('content_check', 'auction_controller', result))
    
    # Test 9: Check Documentation
    print("\n🔍 Checking Documentation:")
    
    doc_files = [
        ('REALTIME_IMPLEMENTATION_GUIDE.md', 'Implementation Guide'),
        ('test_realtime_features.py', 'Comprehensive Test Suite'),
        ('interactive_test.py', 'Interactive Test Script')
    ]
    
    for file_path, description in doc_files:
        result = check_file_exists(file_path, description)
        test_results.append(('file_exists', file_path, result))
    
    # Print Summary
    print("\n" + "=" * 50)
    print("📊 Test Summary:")
    
    total_tests = len(test_results)
    passed_tests = sum(1 for result in test_results if result[2])
    failed_tests = total_tests - passed_tests
    
    print(f"   Total Tests: {total_tests}")
    print(f"   ✅ Passed: {passed_tests}")
    print(f"   ❌ Failed: {failed_tests}")
    print(f"   📈 Success Rate: {(passed_tests/total_tests)*100:.1f}%" if total_tests > 0 else "N/A")
    
    if failed_tests == 0:
        print("\n🎉 All tests passed! Real-time features are ready.")
    else:
        print(f"\n⚠️ {failed_tests} tests failed. Please check the issues above.")
    
    # Print failed tests details
    if failed_tests > 0:
        print("\n❌ Failed Tests Details:")
        for test_type, file_path, result in test_results:
            if not result:
                print(f"   - {test_type}: {file_path}")
    
    print("\n" + "=" * 50)
    print("🏁 Quick Test Completed")
    print("=" * 50)
    
    return failed_tests == 0

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1) 