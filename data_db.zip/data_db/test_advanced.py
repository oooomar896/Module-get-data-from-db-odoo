#!/usr/bin/env python3
"""
اختبارات متقدمة للموديول - Advanced Module Tests
================================================

هذه الاختبارات تختبر الوظائف المتقدمة والسيناريوهات المعقدة
"""

import unittest
import sys
import os
import tempfile
import sqlite3
import json
import re
import html
from unittest.mock import Mock, patch
import datetime

print("🔍 بدء الاختبارات المتقدمة للموديول")
print("=" * 50)

class TestAdvancedDatabaseFeatures(unittest.TestCase):
    """اختبار المميزات المتقدمة لقاعدة البيانات"""
    
    def setUp(self):
        """إعداد قاعدة بيانات متقدمة للاختبار"""
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        # إنشاء جداول متقدمة
        self.cursor.execute('''
            CREATE TABLE employees (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                salary REAL,
                department TEXT,
                hire_date TEXT,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE departments (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                manager_id INTEGER,
                budget REAL,
                created_date TEXT
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                start_date TEXT,
                end_date TEXT,
                status TEXT DEFAULT 'active',
                budget REAL
            )
        ''')
        
        # إدخال بيانات متقدمة
        self.cursor.execute('''
            INSERT INTO employees (name, email, salary, department, hire_date, is_active) VALUES 
            ('أحمد محمد', 'ahmed@company.com', 5000.00, 'IT', '2023-01-15', 1),
            ('فاطمة علي', 'fatima@company.com', 4500.00, 'HR', '2023-02-20', 1),
            ('محمد حسن', 'mohamed@company.com', 6000.00, 'IT', '2022-11-10', 1),
            ('سارة أحمد', 'sara@company.com', 3800.00, 'Marketing', '2023-03-05', 0),
            ('علي محمود', 'ali@company.com', 5200.00, 'Finance', '2022-08-12', 1)
        ''')
        
        self.cursor.execute('''
            INSERT INTO departments (name, manager_id, budget, created_date) VALUES 
            ('IT', 1, 100000.00, '2022-01-01'),
            ('HR', 2, 50000.00, '2022-01-01'),
            ('Marketing', 4, 75000.00, '2022-01-01'),
            ('Finance', 5, 120000.00, '2022-01-01')
        ''')
        
        self.cursor.execute('''
            INSERT INTO projects (name, description, start_date, end_date, status, budget) VALUES 
            ('تطوير النظام الجديد', 'تطوير نظام إدارة الموظفين', '2023-01-01', '2023-12-31', 'active', 50000.00),
            ('تحديث الموقع', 'تحديث موقع الشركة', '2023-03-01', '2023-06-30', 'completed', 25000.00),
            ('حملة تسويقية', 'حملة تسويقية للربع الثاني', '2023-04-01', '2023-06-30', 'active', 15000.00)
        ''')
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """تنظيف الملفات المؤقتة"""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_complex_queries(self):
        """اختبار الاستعلامات المعقدة"""
        print("✅ اختبار الاستعلامات المعقدة")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # استعلام معقد: الموظفون النشطون مع رواتبهم
        cursor.execute("""
            SELECT name, email, salary, department 
            FROM employees 
            WHERE is_active = 1 
            ORDER BY salary DESC
        """)
        active_employees = cursor.fetchall()
        
        self.assertEqual(len(active_employees), 4)  # 4 موظفين نشطين
        self.assertEqual(active_employees[0][2], 6000.00)  # أعلى راتب
        
        # استعلام مع JOIN
        cursor.execute("""
            SELECT e.name, e.salary, d.name as dept_name
            FROM employees e
            LEFT JOIN departments d ON e.department = d.name
            WHERE e.is_active = 1
        """)
        joined_data = cursor.fetchall()
        
        self.assertEqual(len(joined_data), 4)
        
        conn.close()
        print("   ✅ تم تنفيذ الاستعلامات المعقدة بنجاح")
    
    def test_02_data_aggregation(self):
        """اختبار تجميع البيانات"""
        print("✅ اختبار تجميع البيانات")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # إجمالي الرواتب حسب القسم
        cursor.execute("""
            SELECT department, 
                   COUNT(*) as employee_count,
                   AVG(salary) as avg_salary,
                   SUM(salary) as total_salary
            FROM employees 
            WHERE is_active = 1
            GROUP BY department
            ORDER BY total_salary DESC
        """)
        dept_stats = cursor.fetchall()
        
        self.assertEqual(len(dept_stats), 4)  # 4 أقسام
        
        # التحقق من إجمالي الرواتب
        total_salary = sum(row[3] for row in dept_stats)
        self.assertGreater(total_salary, 19000)  # إجمالي الرواتب
        
        conn.close()
        print("   ✅ تم تجميع البيانات بنجاح")
    
    def test_03_data_filtering_and_sorting(self):
        """اختبار التصفية والترتيب"""
        print("✅ اختبار التصفية والترتيب")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # تصفية الموظفين حسب الراتب
        cursor.execute("""
            SELECT name, salary 
            FROM employees 
            WHERE salary > 4500 AND is_active = 1
            ORDER BY salary DESC
        """)
        high_salary_employees = cursor.fetchall()
        
        self.assertEqual(len(high_salary_employees), 3)
        self.assertEqual(high_salary_employees[0][1], 6000.00)  # أعلى راتب أولاً
        
        # تصفية المشاريع النشطة
        cursor.execute("""
            SELECT name, budget 
            FROM projects 
            WHERE status = 'active'
            ORDER BY budget DESC
        """)
        active_projects = cursor.fetchall()
        
        self.assertEqual(len(active_projects), 2)
        
        conn.close()
        print("   ✅ تم التصفية والترتيب بنجاح")


class TestDataExportFeatures(unittest.TestCase):
    """اختبار ميزات تصدير البيانات"""
    
    def setUp(self):
        """إعداد بيانات اختبار للتصدير"""
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        # إنشاء جدول بسيط للتصدير
        self.cursor.execute('''
            CREATE TABLE export_test (
                id INTEGER PRIMARY KEY,
                name TEXT,
                value REAL,
                date TEXT
            )
        ''')
        
        # إدخال بيانات اختبار
        self.cursor.execute('''
            INSERT INTO export_test (name, value, date) VALUES 
            ('Item 1', 100.50, '2024-01-01'),
            ('Item 2', 200.75, '2024-01-02'),
            ('Item 3', 150.25, '2024-01-03')
        ''')
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """تنظيف الملفات المؤقتة"""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_json_export(self):
        """اختبار تصدير البيانات بصيغة JSON"""
        print("✅ اختبار تصدير البيانات بصيغة JSON")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على البيانات
        cursor.execute("SELECT * FROM export_test")
        rows = cursor.fetchall()
        
        # تحويل إلى JSON
        data = []
        for row in rows:
            data.append({
                'id': row[0],
                'name': row[1],
                'value': row[2],
                'date': row[3]
            })
        
        json_data = json.dumps(data, ensure_ascii=False, indent=2)
        
        # التحقق من JSON
        self.assertIsInstance(json_data, str)
        self.assertIn('Item 1', json_data)
        self.assertIn('100.5', json_data)
        
        # اختبار تحليل JSON
        parsed_data = json.loads(json_data)
        self.assertEqual(len(parsed_data), 3)
        self.assertEqual(parsed_data[0]['name'], 'Item 1')
        
        conn.close()
        print("   ✅ تم تصدير البيانات بصيغة JSON بنجاح")
    
    def test_02_csv_export(self):
        """اختبار تصدير البيانات بصيغة CSV"""
        print("✅ اختبار تصدير البيانات بصيغة CSV")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على أسماء الأعمدة
        cursor.execute("PRAGMA table_info(export_test)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # الحصول على البيانات
        cursor.execute("SELECT * FROM export_test")
        rows = cursor.fetchall()
        
        # إنشاء CSV
        csv_lines = [','.join(columns)]  # رأس الجدول
        for row in rows:
            csv_line = ','.join(str(cell) for cell in row)
            csv_lines.append(csv_line)
        
        csv_content = '\n'.join(csv_lines)
        
        # التحقق من CSV
        self.assertIn('id,name,value,date', csv_content)
        self.assertIn('Item 1', csv_content)
        self.assertIn('100.5', csv_content)
        
        # حساب عدد الأسطر
        lines = csv_content.split('\n')
        self.assertEqual(len(lines), 4)  # رأس + 3 صفوف
        
        conn.close()
        print("   ✅ تم تصدير البيانات بصيغة CSV بنجاح")
    
    def test_03_html_table_export(self):
        """اختبار تصدير البيانات كجدول HTML"""
        print("✅ اختبار تصدير البيانات كجدول HTML")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على أسماء الأعمدة
        cursor.execute("PRAGMA table_info(export_test)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # الحصول على البيانات
        cursor.execute("SELECT * FROM export_test")
        rows = cursor.fetchall()
        
        # إنشاء جدول HTML
        html_table = '<table border="1">\n'
        
        # رأس الجدول
        html_table += '<thead>\n<tr>\n'
        for column in columns:
            html_table += f'<th>{html.escape(str(column))}</th>\n'
        html_table += '</tr>\n</thead>\n'
        
        # جسم الجدول
        html_table += '<tbody>\n'
        for row in rows:
            html_table += '<tr>\n'
            for cell in row:
                html_table += f'<td>{html.escape(str(cell))}</td>\n'
            html_table += '</tr>\n'
        html_table += '</tbody>\n'
        html_table += '</table>'
        
        # التحقق من الجدول HTML
        self.assertIn('<table', html_table)
        self.assertIn('<thead>', html_table)
        self.assertIn('<tbody>', html_table)
        self.assertIn('Item 1', html_table)
        self.assertIn('100.5', html_table)
        
        conn.close()
        print("   ✅ تم تصدير البيانات كجدول HTML بنجاح")


class TestPerformanceFeatures(unittest.TestCase):
    """اختبار ميزات الأداء"""
    
    def setUp(self):
        """إعداد قاعدة بيانات كبيرة للاختبار"""
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        # إنشاء جدول كبير
        self.cursor.execute('''
            CREATE TABLE performance_test (
                id INTEGER PRIMARY KEY,
                name TEXT,
                value REAL,
                category TEXT,
                created_date TEXT
            )
        ''')
        
        # إدخال بيانات كثيرة
        for i in range(1000):
            name = f'Item {i}'
            value = i * 1.5
            category = f'Category {i % 10}'
            date = f'2024-01-{(i % 30) + 1:02d}'
            
            self.cursor.execute('''
                INSERT INTO performance_test (name, value, category, created_date) 
                VALUES (?, ?, ?, ?)
            ''', (name, value, category, date))
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """تنظيف الملفات المؤقتة"""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_pagination_performance(self):
        """اختبار أداء الصفحات"""
        print("✅ اختبار أداء الصفحات")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # اختبار الصفحة الأولى
        cursor.execute("SELECT * FROM performance_test LIMIT 50 OFFSET 0")
        page1 = cursor.fetchall()
        self.assertEqual(len(page1), 50)
        
        # اختبار الصفحة الثانية
        cursor.execute("SELECT * FROM performance_test LIMIT 50 OFFSET 50")
        page2 = cursor.fetchall()
        self.assertEqual(len(page2), 50)
        
        # اختبار أن البيانات مختلفة
        self.assertNotEqual(page1[0], page2[0])
        
        conn.close()
        print("   ✅ تم اختبار الصفحات بنجاح")
    
    def test_02_indexed_queries(self):
        """اختبار الاستعلامات المفهرسة"""
        print("✅ اختبار الاستعلامات المفهرسة")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # إنشاء فهرس
        cursor.execute("CREATE INDEX idx_category ON performance_test(category)")
        cursor.execute("CREATE INDEX idx_value ON performance_test(value)")
        
        # اختبار استعلام مفهرس
        cursor.execute("SELECT COUNT(*) FROM performance_test WHERE category = 'Category 1'")
        count = cursor.fetchone()[0]
        self.assertEqual(count, 100)  # 100 عنصر في كل فئة
        
        # اختبار استعلام مفهرس آخر
        cursor.execute("SELECT COUNT(*) FROM performance_test WHERE value > 500")
        high_value_count = cursor.fetchone()[0]
        self.assertGreater(high_value_count, 0)
        
        conn.close()
        print("   ✅ تم اختبار الاستعلامات المفهرسة بنجاح")
    
    def test_03_memory_usage(self):
        """اختبار استخدام الذاكرة"""
        print("✅ اختبار استخدام الذاكرة")
        
        import psutil
        import os
        
        # قياس الذاكرة قبل الاستعلام
        process = psutil.Process(os.getpid())
        memory_before = process.memory_info().rss
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # استعلام كبير
        cursor.execute("SELECT * FROM performance_test")
        rows = cursor.fetchall()
        
        # قياس الذاكرة بعد الاستعلام
        memory_after = process.memory_info().rss
        memory_used = memory_after - memory_before
        
        # التحقق من أن استخدام الذاكرة معقول (أقل من 100MB)
        self.assertLess(memory_used, 100 * 1024 * 1024)  # 100MB
        
        conn.close()
        print(f"   ✅ استخدام الذاكرة: {memory_used / 1024 / 1024:.2f} MB")


class TestSecurityAdvancedFeatures(unittest.TestCase):
    """اختبار ميزات الأمان المتقدمة"""
    
    def test_01_sql_injection_prevention_advanced(self):
        """اختبار متقدم للحماية من حقن SQL"""
        print("✅ اختبار متقدم للحماية من حقن SQL")
        
        # اختبار أنماط حقن SQL متقدمة
        advanced_injection_patterns = [
            "'; DROP TABLE users; --",
            "' UNION SELECT * FROM users --",
            "' OR '1'='1' --",
            "'; INSERT INTO users VALUES (1, 'hacker', 'hack@evil.com'); --",
            "' OR 1=1; DROP TABLE users; --",
            "'; UPDATE users SET password='hacked' WHERE 1=1; --",
            "'; CREATE TABLE evil (id int); --",
            "'; EXEC xp_cmdshell('format c:'); --"
        ]
        
        for pattern in advanced_injection_patterns:
            # التحقق من وجود أحرف ضارة
            dangerous_chars = [';', "'", '"', '--', '/*', '*/', 'UNION', 'DROP', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'EXEC']
            has_dangerous_content = any(char in pattern.upper() for char in dangerous_chars)
            self.assertTrue(has_dangerous_content, f"يجب اكتشاف محتوى ضار في: {pattern}")
        
        print("   ✅ تم اختبار الحماية المتقدمة من حقن SQL")
    
    def test_02_xss_prevention_advanced(self):
        """اختبار متقدم للحماية من XSS"""
        print("✅ اختبار متقدم للحماية من XSS")
        
        # أنماط XSS متقدمة
        advanced_xss_patterns = [
            '<script>alert("XSS")</script>',
            '<img src="x" onerror="alert(\'XSS\')">',
            '<iframe src="javascript:alert(\'XSS\')"></iframe>',
            '<svg onload="alert(\'XSS\')"></svg>',
            '<body onload="alert(\'XSS\')">',
            '<input onfocus="alert(\'XSS\')" autofocus>',
            '<details open ontoggle="alert(\'XSS\')">',
            '<video><source onerror="alert(\'XSS\')">',
            '<audio onloadstart="alert(\'XSS\')">',
            '<object data="javascript:alert(\'XSS\')">'
        ]
        
        for pattern in advanced_xss_patterns:
            # استخدام html.escape للهروب
            escaped = html.escape(pattern)
            
            # التحقق من الهروب
            self.assertNotIn('<script>', escaped)
            self.assertNotIn('javascript:', escaped)
            self.assertIn('&lt;', escaped)  # < يجب أن تكون مهروبة
            self.assertIn('&gt;', escaped)  # > يجب أن تكون مهروبة
        
        print("   ✅ تم اختبار الحماية المتقدمة من XSS")
    
    def test_03_input_sanitization(self):
        """اختبار تنظيف المدخلات"""
        print("✅ اختبار تنظيف المدخلات")
        
        # اختبار تنظيف النصوص
        dirty_inputs = [
            "  Hello World  ",  # مسافات زائدة
            "Hello\nWorld",     # أسطر جديدة
            "Hello\tWorld",     # تبويبات
            "Hello\r\nWorld",   # أسطر جديدة مختلفة
            "Hello<!--Comment-->World",  # تعليقات HTML
            "Hello<script>alert('XSS')</script>World",  # HTML ضار
            "Hello' OR '1'='1' --",  # SQL ضار
            "Hello; DROP TABLE users; --"  # SQL ضار
        ]
        
        for dirty_input in dirty_inputs:
            # تنظيف بسيط
            cleaned = dirty_input.strip()  # إزالة المسافات الزائدة
            cleaned = re.sub(r'<[^>]+>', '', cleaned)  # إزالة HTML tags
            cleaned = re.sub(r'[;\'"]', '', cleaned)  # إزالة أحرف SQL ضارة
            
            # التحقق من التنظيف
            self.assertNotIn('<script>', cleaned)
            self.assertNotIn(';', cleaned)
            self.assertNotIn("'", cleaned)
        
        print("   ✅ تم اختبار تنظيف المدخلات")


def run_advanced_tests():
    """تشغيل الاختبارات المتقدمة"""
    print("\n🚀 بدء تشغيل الاختبارات المتقدمة")
    print("=" * 50)
    
    # إنشاء مجموعة الاختبارات
    test_suite = unittest.TestSuite()
    
    # إضافة فئات الاختبار
    test_classes = [
        TestAdvancedDatabaseFeatures,
        TestDataExportFeatures,
        TestPerformanceFeatures,
        TestSecurityAdvancedFeatures
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # تشغيل الاختبارات
    runner = unittest.TextTestRunner(verbosity=1)
    result = runner.run(test_suite)
    
    # طباعة الملخص
    print("\n" + "=" * 50)
    print("📊 ملخص نتائج الاختبارات المتقدمة")
    print("=" * 50)
    print(f"إجمالي الاختبارات: {result.testsRun}")
    print(f"نجحت: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"فشلت: {len(result.failures)}")
    print(f"أخطاء: {len(result.errors)}")
    
    success_rate = ((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100)
    print(f"معدل النجاح: {success_rate:.1f}%")
    
    if result.failures:
        print("\n💥 الفشل:")
        print("-" * 30)
        for test, traceback in result.failures:
            print(f"• {test}: {traceback.split('AssertionError:')[-1].strip()}")
    
    if result.errors:
        print("\n❌ الأخطاء:")
        print("-" * 30)
        for test, traceback in result.errors:
            print(f"• {test}: {traceback.split('Exception:')[-1].strip()}")
    
    if result.wasSuccessful():
        print("\n✅ جميع الاختبارات المتقدمة نجحت!")
        print("\n🎉 الموديول جاهز للاستخدام في البيئات المتقدمة!")
        return 0
    else:
        print("\n❌ بعض الاختبارات المتقدمة فشلت!")
        return 1


if __name__ == '__main__':
    sys.exit(run_advanced_tests()) 