#!/usr/bin/env python3
"""
اختبارات مبسطة للموديول - Simple Module Tests
==============================================

هذه الاختبارات تختبر الوظائف الأساسية بدون الحاجة لـ Odoo
"""

import unittest
import sys
import os
import tempfile
import sqlite3
import json
import re
import html
from unittest.mock import Mock, patch

print("🔍 بدء الاختبارات المبسطة للموديول")
print("=" * 50)

class TestDatabaseFunctions(unittest.TestCase):
    """اختبار الوظائف الأساسية لقاعدة البيانات"""
    
    def setUp(self):
        """إعداد قاعدة بيانات مؤقتة للاختبار"""
        # إنشاء قاعدة بيانات SQLite مؤقتة
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.temp_db.close()
        
        # إنشاء جداول اختبار
        self.conn = sqlite3.connect(self.temp_db.name)
        self.cursor = self.conn.cursor()
        
        # إنشاء جدول المستخدمين
        self.cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER,
                created_date TEXT
            )
        ''')
        
        # إنشاء جدول المنتجات
        self.cursor.execute('''
            CREATE TABLE products (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                price REAL,
                category TEXT,
                in_stock BOOLEAN
            )
        ''')
        
        # إدخال بيانات اختبار
        self.cursor.execute('''
            INSERT INTO users (name, email, age, created_date) VALUES 
            ('أحمد محمد', 'ahmed@example.com', 30, '2024-01-15'),
            ('فاطمة علي', 'fatima@example.com', 25, '2024-01-20'),
            ('محمد حسن', 'mohamed@example.com', 35, '2024-01-25')
        ''')
        
        self.cursor.execute('''
            INSERT INTO products (name, price, category, in_stock) VALUES 
            ('لابتوب', 2999.99, 'إلكترونيات', 1),
            ('هاتف ذكي', 1499.99, 'إلكترونيات', 1),
            ('كتاب برمجة', 89.99, 'كتب', 0)
        ''')
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """تنظيف الملفات المؤقتة"""
        if hasattr(self, 'temp_db'):
            os.unlink(self.temp_db.name)
    
    def test_01_database_connection(self):
        """اختبار الاتصال بقاعدة البيانات"""
        print("✅ اختبار الاتصال بقاعدة البيانات")
        
        # اختبار الاتصال
        conn = sqlite3.connect(self.temp_db.name)
        self.assertIsNotNone(conn)
        
        # اختبار الاستعلام
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        self.assertEqual(count, 3)
        
        conn.close()
        print("   ✅ تم الاتصال بنجاح")
    
    def test_02_get_tables(self):
        """اختبار الحصول على قائمة الجداول"""
        print("✅ اختبار الحصول على قائمة الجداول")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على قائمة الجداول
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        # التحقق من وجود الجداول المتوقعة
        self.assertIn('users', tables)
        self.assertIn('products', tables)
        self.assertEqual(len(tables), 2)
        
        conn.close()
        print(f"   ✅ تم العثور على {len(tables)} جداول")
    
    def test_03_get_table_data(self):
        """اختبار الحصول على بيانات الجدول"""
        print("✅ اختبار الحصول على بيانات الجدول")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على بيانات جدول المستخدمين
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()
        
        # التحقق من البيانات
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[0][1], 'أحمد محمد')  # الاسم الأول
        self.assertEqual(rows[0][2], 'ahmed@example.com')  # البريد الإلكتروني
        
        conn.close()
        print(f"   ✅ تم الحصول على {len(rows)} صف من جدول المستخدمين")
    
    def test_04_get_table_structure(self):
        """اختبار الحصول على هيكل الجدول"""
        print("✅ اختبار الحصول على هيكل الجدول")
        
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # الحصول على معلومات الأعمدة
        cursor.execute("PRAGMA table_info(users)")
        columns = cursor.fetchall()
        
        # التحقق من الأعمدة
        column_names = [col[1] for col in columns]
        expected_columns = ['id', 'name', 'email', 'age', 'created_date']
        
        for expected in expected_columns:
            self.assertIn(expected, column_names)
        
        conn.close()
        print(f"   ✅ تم العثور على {len(columns)} أعمدة في جدول المستخدمين")


class TestSecurityFunctions(unittest.TestCase):
    """اختبار وظائف الأمان"""
    
    def test_01_sql_injection_protection(self):
        """اختبار الحماية من حقن SQL"""
        print("✅ اختبار الحماية من حقن SQL")
        
        # اختبار أسماء جداول ضارة
        malicious_tables = [
            "users; DROP TABLE users; --",
            "products' OR 1=1 --",
            'table" UNION SELECT * FROM users --',
            "table; INSERT INTO users VALUES (1, 'hacker', 'hack@evil.com'); --"
        ]
        
        for malicious_table in malicious_tables:
            # التحقق من أن الاسم يحتوي على أحرف ضارة
            has_sql_injection = any(char in malicious_table for char in [';', "'", '"', '--', '/*', '*/'])
            self.assertTrue(has_sql_injection, f"يجب اكتشاف حقن SQL في: {malicious_table}")
        
        print("   ✅ تم اختبار الحماية من حقن SQL")
    
    def test_02_html_escaping(self):
        """اختبار الهروب من HTML"""
        print("✅ اختبار الهروب من HTML")
        
        # بيانات اختبار تحتوي على HTML ضار
        test_data = [
            '<script>alert("xss")</script>',
            '<img src="x" onerror="alert(\'XSS\')">',
            'User & Company < 100 > 50',
            'Normal text'
        ]
        
        for data in test_data:
            # استخدام دالة html.escape المدمجة
            escaped = html.escape(data)
            
            # التحقق من الهروب
            if '<script>' in data:
                self.assertIn('&lt;script&gt;', escaped)
            if '&' in data:
                self.assertIn('&amp;', escaped)
            if '<' in data:
                self.assertIn('&lt;', escaped)
            if '>' in data:
                self.assertIn('&gt;', escaped)
        
        print("   ✅ تم اختبار الهروب من HTML")
    
    def test_03_input_validation(self):
        """اختبار التحقق من صحة المدخلات"""
        print("✅ اختبار التحقق من صحة المدخلات")
        
        # اختبار معاملات اتصال صحيحة
        valid_params = {
            'host': 'localhost',
            'port': 5432,
            'database': 'testdb',
            'username': 'testuser',
            'password': 'testpass'
        }
        
        # التحقق من صحة المعاملات
        for key, value in valid_params.items():
            self.assertIsNotNone(value, f"القيمة {key} يجب ألا تكون فارغة")
            self.assertIsInstance(value, (str, int), f"القيمة {key} يجب أن تكون نص أو رقم")
        
        # اختبار معاملات اتصال غير صحيحة
        invalid_params = [
            {'host': '', 'port': 5432, 'database': 'test', 'username': 'user', 'password': 'pass'},
            {'host': 'localhost', 'port': -1, 'database': 'test', 'username': 'user', 'password': 'pass'},
            {'host': 'localhost', 'port': 5432, 'database': '', 'username': 'user', 'password': 'pass'},
        ]
        
        for params in invalid_params:
            has_invalid = any(
                value == '' or (key == 'port' and value < 0)
                for key, value in params.items()
            )
            self.assertTrue(has_invalid, f"يجب اكتشاف معاملات غير صحيحة: {params}")
        
        print("   ✅ تم اختبار التحقق من صحة المدخلات")


class TestHtmlGeneration(unittest.TestCase):
    """اختبار إنشاء HTML"""
    
    def test_01_basic_html_structure(self):
        """اختبار الهيكل الأساسي لـ HTML"""
        print("✅ اختبار الهيكل الأساسي لـ HTML")
        
        # إنشاء HTML أساسي
        html_content = """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>عرض بيانات قاعدة البيانات</title>
        </head>
        <body>
            <h1>بيانات قاعدة البيانات</h1>
            <div id="content">
                <p>محتوى الصفحة</p>
            </div>
        </body>
        </html>
        """
        
        # التحقق من العناصر الأساسية
        self.assertIn('<!DOCTYPE html>', html_content)
        self.assertIn('<html', html_content)
        self.assertIn('<head>', html_content)
        self.assertIn('<body>', html_content)
        self.assertIn('lang="ar"', html_content)
        self.assertIn('dir="rtl"', html_content)
        
        print("   ✅ تم إنشاء هيكل HTML صحيح")
    
    def test_02_table_html_generation(self):
        """اختبار إنشاء جداول HTML"""
        print("✅ اختبار إنشاء جداول HTML")
        
        # بيانات اختبار
        columns = ['الاسم', 'البريد الإلكتروني', 'العمر']
        rows = [
            ['أحمد محمد', 'ahmed@example.com', 30],
            ['فاطمة علي', 'fatima@example.com', 25],
            ['محمد حسن', 'mohamed@example.com', 35]
        ]
        
        # إنشاء جدول HTML
        table_html = '<table border="1">\n'
        
        # رأس الجدول
        table_html += '<thead>\n<tr>\n'
        for column in columns:
            table_html += f'<th>{column}</th>\n'
        table_html += '</tr>\n</thead>\n'
        
        # جسم الجدول
        table_html += '<tbody>\n'
        for row in rows:
            table_html += '<tr>\n'
            for cell in row:
                table_html += f'<td>{cell}</td>\n'
            table_html += '</tr>\n'
        table_html += '</tbody>\n'
        table_html += '</table>'
        
        # التحقق من الجدول
        self.assertIn('<table', table_html)
        self.assertIn('<thead>', table_html)
        self.assertIn('<tbody>', table_html)
        self.assertIn('أحمد محمد', table_html)
        self.assertIn('فاطمة علي', table_html)
        
        print(f"   ✅ تم إنشاء جدول بـ {len(rows)} صفوف و {len(columns)} أعمدة")
    
    def test_03_css_styling(self):
        """اختبار تنسيق CSS"""
        print("✅ اختبار تنسيق CSS")
        
        # CSS أساسي
        css_styles = """
        <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 12px;
            text-align: right;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        </style>
        """
        
        # التحقق من وجود خصائص CSS مهمة
        css_properties = [
            'font-family',
            'background',
            'border-radius',
            'box-shadow',
            'border-collapse',
            'text-align'
        ]
        
        for property in css_properties:
            self.assertIn(property, css_styles)
        
        print("   ✅ تم إنشاء تنسيق CSS صحيح")


class TestErrorHandling(unittest.TestCase):
    """اختبار معالجة الأخطاء"""
    
    def test_01_database_connection_errors(self):
        """اختبار أخطاء الاتصال بقاعدة البيانات"""
        print("✅ اختبار أخطاء الاتصال بقاعدة البيانات")
        
        # اختبار الاتصال بقاعدة بيانات غير موجودة
        with self.assertRaises(Exception):
            sqlite3.connect('/nonexistent/database.db')
        
        print("   ✅ تم اختبار أخطاء الاتصال")
    
    def test_02_invalid_sql_queries(self):
        """اختبار استعلامات SQL غير صحيحة"""
        print("✅ اختبار استعلامات SQL غير صحيحة")
        
        # إنشاء قاعدة بيانات مؤقتة
        temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        temp_db.close()
        
        try:
            conn = sqlite3.connect(temp_db.name)
            cursor = conn.cursor()
            
            # اختبار استعلام غير صحيح
            with self.assertRaises(Exception):
                cursor.execute("SELECT * FROM nonexistent_table")
            
            conn.close()
        
        finally:
            os.unlink(temp_db.name)
        
        print("   ✅ تم اختبار الاستعلامات غير الصحيحة")
    
    def test_03_empty_database_handling(self):
        """اختبار التعامل مع قاعدة بيانات فارغة"""
        print("✅ اختبار التعامل مع قاعدة بيانات فارغة")
        
        # إنشاء قاعدة بيانات فارغة
        temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        temp_db.close()
        
        try:
            conn = sqlite3.connect(temp_db.name)
            cursor = conn.cursor()
            
            # الحصول على قائمة الجداول (يجب أن تكون فارغة)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            
            # التحقق من أن القائمة فارغة
            self.assertEqual(len(tables), 0)
            
            conn.close()
        
        finally:
            os.unlink(temp_db.name)
        
        print("   ✅ تم اختبار قاعدة البيانات الفارغة")


def run_simple_tests():
    """تشغيل الاختبارات المبسطة"""
    print("\n🚀 بدء تشغيل الاختبارات المبسطة")
    print("=" * 50)
    
    # إنشاء مجموعة الاختبارات
    test_suite = unittest.TestSuite()
    
    # إضافة فئات الاختبار
    test_classes = [
        TestDatabaseFunctions,
        TestSecurityFunctions,
        TestHtmlGeneration,
        TestErrorHandling
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # تشغيل الاختبارات
    runner = unittest.TextTestRunner(verbosity=1)
    result = runner.run(test_suite)
    
    # طباعة الملخص
    print("\n" + "=" * 50)
    print("📊 ملخص نتائج الاختبارات المبسطة")
    print("=" * 50)
    print(f"إجمالي الاختبارات: {result.testsRun}")
    print(f"نجحت: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"فشلت: {len(result.failures)}")
    print(f"أخطاء: {len(result.errors)}")
    
    success_rate = ((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100)
    print(f"معدل النجاح: {success_rate:.1f}%")
    
    if result.failures:
        print("\n💥 الفشل:")
        print("-" * 30)
        for test, traceback in result.failures:
            print(f"• {test}: {traceback.split('AssertionError:')[-1].strip()}")
    
    if result.errors:
        print("\n❌ الأخطاء:")
        print("-" * 30)
        for test, traceback in result.errors:
            print(f"• {test}: {traceback.split('Exception:')[-1].strip()}")
    
    if result.wasSuccessful():
        print("\n✅ جميع الاختبارات نجحت!")
        print("\n🎉 الموديول جاهز للاستخدام!")
        return 0
    else:
        print("\n❌ بعض الاختبارات فشلت!")
        return 1


if __name__ == '__main__':
    sys.exit(run_simple_tests()) 