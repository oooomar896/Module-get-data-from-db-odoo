import unittest
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError
import psycopg2
import json

class TestDatabaseViewer(TransactionCase):
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })
        
        # Mock data for testing
        self.mock_tables = ['users', 'products', 'orders']
        self.mock_columns = [
            {'name': 'id', 'type': 'integer'},
            {'name': 'name', 'type': 'character varying'},
            {'name': 'email', 'type': 'character varying'}
        ]
        self.mock_data = [
            {'id': 1, 'name': 'John Doe', 'email': 'john@example.com'},
            {'id': 2, 'name': 'Jane Smith', 'email': 'jane@example.com'}
        ]

    def test_01_create_database_viewer(self):
        """Test creating a database viewer configuration"""
        self.assertEqual(self.database_viewer.name, 'Test Database')
        self.assertEqual(self.database_viewer.host, 'localhost')
        self.assertEqual(self.database_viewer.port, 5432)
        self.assertEqual(self.database_viewer.database, 'test_db')
        self.assertTrue(self.database_viewer.active)

    def test_02_validate_table_name(self):
        """Test table name validation"""
        # Valid table names
        valid_names = ['users', 'user_table', 'user-table', 'user123']
        for name in valid_names:
            result = self.database_viewer._validate_table_name(name)
            self.assertEqual(result, name)
        
        # Invalid table names
        invalid_names = ['', None, 'user;table', 'user\'table', 'user--table']
        for name in invalid_names:
            with self.assertRaises(UserError):
                self.database_viewer._validate_table_name(name)

    @patch('psycopg2.connect')
    def test_03_get_database_connection_success(self, mock_connect):
        """Test successful database connection"""
        mock_connection = MagicMock()
        mock_connect.return_value = mock_connection
        
        connection = self.database_viewer.get_database_connection()
        
        mock_connect.assert_called_once_with(
            host='localhost',
            port=5432,
            database='test_db',
            user='test_user',
            password='test_password'
        )
        self.assertEqual(connection, mock_connection)

    @patch('psycopg2.connect')
    def test_04_get_database_connection_failure(self, mock_connect):
        """Test database connection failure"""
        mock_connect.side_effect = psycopg2.OperationalError("Connection failed")
        
        with self.assertRaises(UserError) as context:
            self.database_viewer.get_database_connection()
        
        self.assertIn("Failed to connect to database", str(context.exception))

    @patch('psycopg2.connect')
    def test_05_get_table_list_success(self, mock_connect):
        """Test successful table list retrieval"""
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.fetchall.return_value = [('users',), ('products',), ('orders',)]
        mock_connect.return_value = mock_connection
        
        tables = self.database_viewer.get_table_list()
        
        self.assertEqual(tables, ['users', 'products', 'orders'])
        mock_cursor.execute.assert_called_once()
        mock_cursor.close.assert_called_once()
        mock_connection.close.assert_called_once()

    @patch('psycopg2.connect')
    def test_06_get_table_list_failure(self, mock_connect):
        """Test table list retrieval failure"""
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.execute.side_effect = psycopg2.Error("Database error")
        mock_connect.return_value = mock_connection
        
        with self.assertRaises(UserError) as context:
            self.database_viewer.get_table_list()
        
        self.assertIn("Error retrieving table list", str(context.exception))

    @patch('psycopg2.connect')
    def test_07_get_table_data_success(self, mock_connect):
        """Test successful table data retrieval"""
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        
        # Mock column data
        mock_cursor.fetchall.side_effect = [
            [('id', 'integer'), ('name', 'character varying'), ('email', 'character varying')],
            [(1, 'John Doe', 'john@example.com'), (2, 'Jane Smith', 'jane@example.com')]
        ]
        
        mock_connect.return_value = mock_connection
        
        result = self.database_viewer.get_table_data('users', limit=10, offset=0)
        
        self.assertEqual(len(result['columns']), 3)
        self.assertEqual(len(result['data']), 2)
        self.assertEqual(result['total_rows'], 2)
        self.assertEqual(result['columns'][0]['name'], 'id')
        self.assertEqual(result['data'][0]['name'], 'John Doe')

    @patch('psycopg2.connect')
    def test_08_get_table_data_invalid_table(self, mock_connect):
        """Test table data retrieval with invalid table name"""
        with self.assertRaises(UserError):
            self.database_viewer.get_table_data('invalid;table')

    @patch('psycopg2.connect')
    def test_09_get_table_count_success(self, mock_connect):
        """Test successful table count retrieval"""
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.fetchone.return_value = (100,)
        mock_connect.return_value = mock_connection
        
        count = self.database_viewer.get_table_count('users')
        
        self.assertEqual(count, 100)
        mock_cursor.execute.assert_called_once_with('SELECT COUNT(*) FROM "users"')

    def test_10_execute_custom_query_security(self):
        """Test custom query security restrictions"""
        dangerous_queries = [
            "DROP TABLE users",
            "DELETE FROM users",
            "UPDATE users SET name='test'",
            "INSERT INTO users VALUES (1, 'test')",
            "CREATE TABLE test (id int)",
            "ALTER TABLE users ADD COLUMN test int",
            "TRUNCATE TABLE users"
        ]
        
        for query in dangerous_queries:
            with self.assertRaises(UserError) as context:
                self.database_viewer.execute_custom_query(query)
            self.assertIn("forbidden keyword", str(context.exception))

    def test_11_execute_custom_query_invalid_input(self):
        """Test custom query with invalid input"""
        invalid_inputs = [None, "", 123, []]
        
        for invalid_input in invalid_inputs:
            with self.assertRaises(UserError):
                self.database_viewer.execute_custom_query(invalid_input)

    @patch('psycopg2.connect')
    def test_12_execute_custom_query_success(self, mock_connect):
        """Test successful custom query execution"""
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        
        # Mock cursor description and data
        mock_cursor.description = [('id',), ('name',)]
        mock_cursor.fetchall.return_value = [(1, 'John'), (2, 'Jane')]
        
        mock_connect.return_value = mock_connection
        
        result = self.database_viewer.execute_custom_query("SELECT id, name FROM users")
        
        self.assertEqual(len(result['columns']), 2)
        self.assertEqual(len(result['data']), 2)
        self.assertEqual(result['data'][0]['id'], 1)
        self.assertEqual(result['data'][0]['name'], 'John')

    def test_13_test_connection_success(self):
        """Test connection test method success"""
        with patch.object(self.database_viewer, 'get_database_connection') as mock_get_conn:
            mock_connection = MagicMock()
            mock_get_conn.return_value = mock_connection
            
            result = self.database_viewer.test_connection()
            
            self.assertEqual(result['type'], 'ir.actions.client')
            self.assertEqual(result['tag'], 'display_notification')
            self.assertEqual(result['params']['type'], 'success')
            mock_connection.close.assert_called_once()

    def test_14_test_connection_failure(self):
        """Test connection test method failure"""
        with patch.object(self.database_viewer, 'get_database_connection') as mock_get_conn:
            mock_get_conn.side_effect = Exception("Connection failed")
            
            with self.assertRaises(UserError) as context:
                self.database_viewer.test_connection()
            
            self.assertIn("Connection failed", str(context.exception))

    def test_15_get_tables_success(self):
        """Test get tables method success"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.return_value = ['users', 'products', 'orders']
            
            result = self.database_viewer.get_tables()
            
            self.assertEqual(result['type'], 'ir.actions.client')
            self.assertEqual(result['tag'], 'display_notification')
            self.assertEqual(result['params']['type'], 'info')
            self.assertIn("Found 3 tables", result['params']['message'])

    def test_16_get_tables_failure(self):
        """Test get tables method failure"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database error")
            
            with self.assertRaises(UserError) as context:
                self.database_viewer.get_tables()
            
            self.assertIn("Error getting tables", str(context.exception))

    def test_17_generate_html_data_display(self):
        """Test HTML data display generation"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
                mock_get_tables.return_value = ['users']
                mock_get_data.return_value = {
                    'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                    'data': [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}],
                    'total_rows': 2
                }
                
                html_content = self.database_viewer.generate_html_data_display()
                
                self.assertIn('Database Data Viewer', html_content)
                self.assertIn('test_db', html_content)
                self.assertIn('users', html_content)
                self.assertIn('John', html_content)
                self.assertIn('Jane', html_content)

    def test_18_generate_html_data_display_with_selected_tables(self):
        """Test HTML data display generation with selected tables"""
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            html_content = self.database_viewer.generate_html_data_display(
                selected_tables=['users', 'products']
            )
            
            self.assertIn('users', html_content)
            self.assertIn('products', html_content)

    def test_19_generate_html_data_display_error(self):
        """Test HTML data display generation with error"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database error")
            
            html_content = self.database_viewer.generate_html_data_display()
            
            self.assertIn('Error Loading Database Data', html_content)
            self.assertIn('Database error', html_content)

    def test_20_open_web_viewer(self):
        """Test open web viewer action"""
        result = self.database_viewer.open_web_viewer()
        
        self.assertEqual(result['type'], 'ir.actions.url')
        self.assertEqual(result['url'], '/database-viewer')
        self.assertEqual(result['target'], 'new')

    def test_21_show_data_in_odoo(self):
        """Test show data in Odoo action"""
        result = self.database_viewer.show_data_in_odoo()
        
        self.assertEqual(result['type'], 'ir.actions.act_window')
        self.assertEqual(result['res_model'], 'database.data.display')
        self.assertEqual(result['view_mode'], 'form')
        self.assertEqual(result['target'], 'new')
        self.assertEqual(result['context']['default_database_viewer_id'], self.database_viewer.id)


class TestDatabaseDataDisplay(TransactionCase):
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })
        
        # Create a test data display record
        self.data_display = self.env['database.data.display'].create({
            'database_viewer_id': self.database_viewer.id,
            'database_name': 'test_db',
            'selected_tables': 'users,products',
            'limit_per_table': 50
        })

    def test_01_create_data_display(self):
        """Test creating a data display record"""
        self.assertEqual(self.data_display.database_viewer_id, self.database_viewer)
        self.assertEqual(self.data_display.database_name, 'test_db')
        self.assertEqual(self.data_display.selected_tables, 'users,products')
        self.assertEqual(self.data_display.limit_per_table, 50)

    def test_02_onchange_database_viewer(self):
        """Test onchange database viewer"""
        self.data_display.database_viewer_id = self.database_viewer
        self.data_display._onchange_database_viewer()
        
        self.assertEqual(self.data_display.database_name, 'test_db')

    def test_03_generate_data_display_success(self):
        """Test successful data display generation"""
        with patch.object(self.database_viewer, 'generate_html_data_display') as mock_generate:
            mock_generate.return_value = '<div>Test HTML</div>'
            
            result = self.data_display.generate_data_display()
            
            self.assertEqual(result['type'], 'ir.actions.act_window')
            self.assertEqual(result['res_model'], 'database.data.display')
            self.assertEqual(result['res_id'], self.data_display.id)
            self.assertEqual(self.data_display.html_content, '<div>Test HTML</div>')

    def test_04_generate_data_display_no_viewer(self):
        """Test data display generation without database viewer"""
        self.data_display.database_viewer_id = False
        
        with self.assertRaises(UserError) as context:
            self.data_display.generate_data_display()
        
        self.assertIn("Please select a database viewer configuration", str(context.exception))

    def test_05_generate_data_display_with_selected_tables(self):
        """Test data display generation with selected tables"""
        with patch.object(self.database_viewer, 'generate_html_data_display') as mock_generate:
            mock_generate.return_value = '<div>Test HTML</div>'
            
            self.data_display.selected_tables = 'users,products,orders'
            self.data_display.generate_data_display()
            
            # Check that generate_html_data_display was called with selected tables
            mock_generate.assert_called_once()
            call_args = mock_generate.call_args
            self.assertEqual(call_args[1]['selected_tables'], ['users', 'products', 'orders'])
            self.assertEqual(call_args[1]['limit_per_table'], 50)

    def test_06_generate_data_display_empty_tables(self):
        """Test data display generation with empty tables selection"""
        with patch.object(self.database_viewer, 'generate_html_data_display') as mock_generate:
            mock_generate.return_value = '<div>Test HTML</div>'
            
            self.data_display.selected_tables = ''
            self.data_display.generate_data_display()
            
            # Check that generate_html_data_display was called with None for selected_tables
            call_args = mock_generate.call_args
            self.assertIsNone(call_args[1]['selected_tables']) 