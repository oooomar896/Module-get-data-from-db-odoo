import unittest
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase, HttpCase
from odoo.exceptions import UserError
import json

class TestDatabaseViewerController(HttpCase):
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })

    def test_01_database_viewer_page_no_config(self):
        """Test database viewer page when no configuration exists"""
        # Deactivate all viewers
        self.database_viewer.active = False
        self.database_viewer.save()
        
        response = self.url_open('/database-viewer')
        self.assertEqual(response.status_code, 200)
        
        content = response.text
        self.assertIn('No Active Database Configuration Found', content)
        self.assertIn('Go to Configuration', content)

    @patch('data_db.controllers.main.DatabaseViewerController.get_table_list')
    def test_02_database_viewer_page_with_config(self, mock_get_tables):
        """Test database viewer page with active configuration"""
        mock_get_tables.return_value = ['users', 'products']
        
        response = self.url_open('/database-viewer')
        self.assertEqual(response.status_code, 200)
        
        content = response.text
        self.assertIn('Database Data Viewer', content)
        self.assertIn('test_db', content)
        self.assertIn('users', content)
        self.assertIn('products', content)
        self.assertIn('Interactive Database Explorer', content)

    def test_03_database_viewer_page_error(self):
        """Test database viewer page with error"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database error")
            
            response = self.url_open('/database-viewer')
            self.assertEqual(response.status_code, 200)
            
            content = response.text
            self.assertIn('Error Loading Database Viewer', content)
            self.assertIn('Database error', content)

    def test_04_api_table_data_success(self):
        """Test successful API table data endpoint"""
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                'data': [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}],
                'total_rows': 2
            }
            
            response = self.url_open('/database-viewer/api/table-data/users')
            self.assertEqual(response.status_code, 200)
            
            data = json.loads(response.text)
            self.assertEqual(len(data['columns']), 2)
            self.assertEqual(len(data['data']), 2)
            self.assertEqual(data['data'][0]['name'], 'John')

    def test_05_api_table_data_invalid_table(self):
        """Test API table data endpoint with invalid table name"""
        response = self.url_open('/database-viewer/api/table-data/invalid;table')
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.text)
        self.assertIn('Invalid table name', data['error'])

    def test_06_api_table_data_no_config(self):
        """Test API table data endpoint when no configuration exists"""
        self.database_viewer.active = False
        self.database_viewer.save()
        
        response = self.url_open('/database-viewer/api/table-data/users')
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.text)
        self.assertIn('No active database configuration', data['error'])

    def test_07_api_table_data_error(self):
        """Test API table data endpoint with error"""
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.side_effect = Exception("Database error")
            
            response = self.url_open('/database-viewer/api/table-data/users')
            self.assertEqual(response.status_code, 500)
            
            data = json.loads(response.text)
            self.assertIn('Database error', data['error'])

    def test_08_api_stats_success(self):
        """Test successful API stats endpoint"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            with patch.object(self.database_viewer, 'get_table_count') as mock_get_count:
                mock_get_tables.return_value = ['users', 'products']
                mock_get_count.return_value = 100
                
                response = self.url_open('/database-viewer/api/stats')
                self.assertEqual(response.status_code, 200)
                
                data = json.loads(response.text)
                self.assertEqual(data['total_tables'], 2)
                self.assertEqual(data['total_rows'], 200)  # 100 per table
                self.assertEqual(data['database_name'], 'test_db')

    def test_09_api_stats_no_config(self):
        """Test API stats endpoint when no configuration exists"""
        self.database_viewer.active = False
        self.database_viewer.save()
        
        response = self.url_open('/database-viewer/api/stats')
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.text)
        self.assertIn('No active database configuration', data['error'])

    def test_10_api_stats_error(self):
        """Test API stats endpoint with error"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database error")
            
            response = self.url_open('/database-viewer/api/stats')
            self.assertEqual(response.status_code, 500)
            
            data = json.loads(response.text)
            self.assertIn('Database error', data['error'])

    def test_11_api_table_data_with_parameters(self):
        """Test API table data endpoint with limit and offset parameters"""
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            response = self.url_open('/database-viewer/api/table-data/users?limit=10&offset=5')
            self.assertEqual(response.status_code, 200)
            
            # Check that get_table_data was called with correct parameters
            mock_get_data.assert_called_once_with('users', limit=10, offset=5)

    def test_12_api_table_data_parameter_validation(self):
        """Test API table data endpoint parameter validation"""
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            # Test with invalid limit (should be clamped to 1000)
            response = self.url_open('/database-viewer/api/table-data/users?limit=9999')
            self.assertEqual(response.status_code, 200)
            
            # Test with negative offset (should be clamped to 0)
            response = self.url_open('/database-viewer/api/table-data/users?offset=-10')
            self.assertEqual(response.status_code, 200)

    def test_13_html_content_structure(self):
        """Test HTML content structure in web interface"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.return_value = ['users']
            
            response = self.url_open('/database-viewer')
            self.assertEqual(response.status_code, 200)
            
            content = response.text
            
            # Check for required HTML elements
            self.assertIn('<!DOCTYPE html>', content)
            self.assertIn('<html>', content)
            self.assertIn('<head>', content)
            self.assertIn('<body>', content)
            self.assertIn('</html>', content)
            
            # Check for required CSS classes
            self.assertIn('container', content)
            self.assertIn('header', content)
            self.assertIn('connection-info', content)
            self.assertIn('tables-section', content)
            self.assertIn('table-card', content)
            
            # Check for JavaScript functions
            self.assertIn('toggleTable', content)
            self.assertIn('loadTableData', content)
            self.assertIn('displayTableData', content)

    def test_14_javascript_functionality(self):
        """Test JavaScript functionality in web interface"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.return_value = ['users']
            
            response = self.url_open('/database-viewer')
            content = response.text
            
            # Check for JavaScript functions
            self.assertIn('function toggleTable', content)
            self.assertIn('function loadTableData', content)
            self.assertIn('function displayTableData', content)
            self.assertIn('function escapeHtml', content)
            
            # Check for API endpoints in JavaScript
            self.assertIn('/database-viewer/api/table-data/', content)
            self.assertIn('/database-viewer/api/stats', content)

    def test_15_error_handling_in_html(self):
        """Test error handling in HTML content"""
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Test error")
            
            response = self.url_open('/database-viewer')
            content = response.text
            
            self.assertIn('Error Loading Database Viewer', content)
            self.assertIn('Test error', content)
            self.assertIn('error-container', content)


class TestControllerSecurity(TransactionCase):
    
    def setUp(self):
        super().setUp()
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })

    def test_01_sql_injection_protection(self):
        """Test SQL injection protection in API endpoints"""
        malicious_tables = [
            'users; DROP TABLE users; --',
            'users\' OR 1=1; --',
            'users UNION SELECT * FROM passwords',
            'users; INSERT INTO users VALUES (1, \'hacker\'); --'
        ]
        
        for malicious_table in malicious_tables:
            # This should be caught by the table name validation
            with self.assertRaises(UserError):
                self.database_viewer._validate_table_name(malicious_table)

    def test_02_xss_protection(self):
        """Test XSS protection in HTML generation"""
        malicious_data = {
            'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
            'data': [
                {'id': 1, 'name': '<script>alert("XSS")</script>'},
                {'id': 2, 'name': '"><img src=x onerror=alert("XSS")>'}
            ],
            'total_rows': 2
        }
        
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
                mock_get_tables.return_value = ['users']
                mock_get_data.return_value = malicious_data
                
                html_content = self.database_viewer.generate_html_data_display()
                
                # Check that script tags are escaped
                self.assertIn('&lt;script&gt;alert("XSS")&lt;/script&gt;', html_content)
                self.assertIn('&quot;&gt;&lt;img src=x onerror=alert("XSS")&gt;', html_content)
                
                # Check that no actual script tags exist
                self.assertNotIn('<script>', html_content)
                self.assertNotIn('onerror=', html_content)

    def test_03_authentication_required(self):
        """Test that API endpoints require authentication"""
        # This test would require a separate test case that doesn't inherit from HttpCase
        # to test unauthenticated access, but the current setup always authenticates
        pass

    def test_04_input_validation(self):
        """Test input validation in API endpoints"""
        # Test invalid table names
        invalid_tables = ['', None, 'table;', 'table--', 'table/*', 'table*/']
        
        for invalid_table in invalid_tables:
            if invalid_table is not None:
                with self.assertRaises(UserError):
                    self.database_viewer._validate_table_name(invalid_table)

    def test_05_parameter_limits(self):
        """Test parameter limits in API endpoints"""
        # Test that limit is properly bounded
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {'columns': [], 'data': [], 'total_rows': 0}
            
            # Test with very large limit (should be clamped)
            result = self.database_viewer.get_table_data('users', limit=999999, offset=0)
            # The limit should be clamped to 1000 in the method
            mock_get_data.assert_called_once()
            
            # Test with negative offset (should be clamped)
            result = self.database_viewer.get_table_data('users', limit=10, offset=-999)
            # The offset should be clamped to 0 