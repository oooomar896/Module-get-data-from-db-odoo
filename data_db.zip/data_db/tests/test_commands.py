import unittest
import os
import tempfile
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError

class TestBuildInterfaceCommand(TransactionCase):
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })

    def test_01_build_interface_no_config(self):
        """Test build interface when no configuration exists"""
        # Deactivate all viewers
        self.database_viewer.active = False
        self.database_viewer.save()
        
        from data_db.commands.build_interface import build_database_html_interface
        
        result = build_database_html_interface(self.env)
        self.assertFalse(result)

    @patch('data_db.commands.build_interface.generate_html_content')
    @patch('data_db.models.database_viewer.DatabaseViewer.get_table_list')
    def test_02_build_interface_success(self, mock_get_tables, mock_generate_html):
        """Test successful build interface"""
        mock_get_tables.return_value = ['users', 'products']
        mock_generate_html.return_value = '<html>Test Content</html>'
        
        from data_db.commands.build_interface import build_database_html_interface
        
        with patch('builtins.open', create=True) as mock_open:
            mock_file = MagicMock()
            mock_open.return_value.__enter__.return_value = mock_file
            
            result = build_database_html_interface(self.env)
            
            self.assertTrue(result)
            mock_open.assert_called_once()
            mock_file.write.assert_called_once_with('<html>Test Content</html>')

    @patch('data_db.models.database_viewer.DatabaseViewer.get_table_list')
    def test_03_build_interface_table_list_error(self, mock_get_tables):
        """Test build interface with table list error"""
        mock_get_tables.side_effect = Exception("Database error")
        
        from data_db.commands.build_interface import build_database_html_interface
        
        result = build_database_html_interface(self.env)
        self.assertFalse(result)

    @patch('data_db.commands.build_interface.generate_html_content')
    @patch('data_db.models.database_viewer.DatabaseViewer.get_table_list')
    def test_04_build_interface_file_write_error(self, mock_get_tables, mock_generate_html):
        """Test build interface with file write error"""
        mock_get_tables.return_value = ['users']
        mock_generate_html.return_value = '<html>Test Content</html>'
        
        from data_db.commands.build_interface import build_database_html_interface
        
        with patch('builtins.open', create=True) as mock_open:
            mock_open.side_effect = Exception("File write error")
            
            result = build_database_html_interface(self.env)
            self.assertFalse(result)

    def test_05_generate_html_content_structure(self):
        """Test HTML content generation structure"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                'data': [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}],
                'total_rows': 2
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check for required HTML elements
            self.assertIn('<!DOCTYPE html>', html_content)
            self.assertIn('<html>', html_content)
            self.assertIn('<head>', html_content)
            self.assertIn('<body>', html_content)
            self.assertIn('</html>', html_content)
            
            # Check for database information
            self.assertIn('test_db', html_content)
            self.assertIn('localhost', html_content)
            self.assertIn('test_user', html_content)
            
            # Check for table data
            self.assertIn('users', html_content)
            self.assertIn('John', html_content)
            self.assertIn('Jane', html_content)

    def test_06_generate_html_content_with_multiple_tables(self):
        """Test HTML content generation with multiple tables"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            html_content = generate_html_content(self.database_viewer, ['users', 'products', 'orders'])
            
            # Check that all tables are included
            self.assertIn('users', html_content)
            self.assertIn('products', html_content)
            self.assertIn('orders', html_content)

    def test_07_generate_html_content_with_empty_data(self):
        """Test HTML content generation with empty table data"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [],
                'data': [],
                'total_rows': 0
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            self.assertIn('users', html_content)
            self.assertIn('No data found in this table', html_content)

    def test_08_generate_html_content_with_table_error(self):
        """Test HTML content generation with table processing error"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.side_effect = Exception("Table error")
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            self.assertIn('users', html_content)
            self.assertIn('Error loading data', html_content)
            self.assertIn('Table error', html_content)

    def test_09_generate_html_content_styling(self):
        """Test HTML content generation includes proper styling"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check for CSS styling
            self.assertIn('font-family', html_content)
            self.assertIn('background: linear-gradient', html_content)
            self.assertIn('border-radius', html_content)
            self.assertIn('box-shadow', html_content)
            
            # Check for responsive design
            self.assertIn('@media (max-width: 768px)', html_content)

    def test_10_generate_html_content_javascript(self):
        """Test HTML content generation includes JavaScript functionality"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check for JavaScript
            self.assertIn('<script>', html_content)
            self.assertIn('addEventListener', html_content)
            self.assertIn('style.display', html_content)

    def test_11_main_function_success(self):
        """Test main function success"""
        from data_db.commands.build_interface import main
        
        with patch('data_db.commands.build_interface.build_database_html_interface') as mock_build:
            mock_build.return_value = True
            
            with patch('odoo.modules.registry.Registry') as mock_registry:
                mock_env = MagicMock()
                mock_cr = MagicMock()
                mock_registry.return_value.__enter__.return_value = mock_cr
                mock_cr.__enter__.return_value = mock_cr
                mock_cr.__exit__.return_value = None
                mock_cr.env = mock_env
                
                result = main()
                self.assertTrue(result)

    def test_12_main_function_failure(self):
        """Test main function failure"""
        from data_db.commands.build_interface import main
        
        with patch('data_db.commands.build_interface.build_database_html_interface') as mock_build:
            mock_build.return_value = False
            
            with patch('odoo.modules.registry.Registry') as mock_registry:
                mock_env = MagicMock()
                mock_cr = MagicMock()
                mock_registry.return_value.__enter__.return_value = mock_cr
                mock_cr.__enter__.return_value = mock_cr
                mock_cr.__exit__.return_value = None
                mock_cr.env = mock_env
                
                result = main()
                self.assertFalse(result)

    def test_13_main_function_exception(self):
        """Test main function with exception"""
        from data_db.commands.build_interface import main
        
        with patch('odoo.modules.registry.Registry') as mock_registry:
            mock_registry.side_effect = Exception("Registry error")
            
            result = main()
            self.assertFalse(result)

    def test_14_html_content_data_truncation(self):
        """Test HTML content generation with data truncation"""
        from data_db.commands.build_interface import generate_html_content
        
        # Create data with long values
        long_value = 'A' * 200  # 200 characters
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'description', 'type': 'text'}],
                'data': [{'id': 1, 'description': long_value}],
                'total_rows': 1
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check that long values are truncated
            self.assertIn('A' * 100 + '...', html_content)
            self.assertNotIn(long_value, html_content)

    def test_15_html_content_null_values(self):
        """Test HTML content generation with null values"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                'data': [{'id': 1, 'name': None}, {'id': 2, 'name': 'John'}],
                'total_rows': 2
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check that null values are displayed properly
            self.assertIn('<em>null</em>', html_content)
            self.assertIn('John', html_content)

    def test_16_html_content_statistics(self):
        """Test HTML content generation includes statistics"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}, {'id': 2}, {'id': 3}],
                'total_rows': 3
            }
            
            html_content = generate_html_content(self.database_viewer, ['users', 'products'])
            
            # Check for statistics
            self.assertIn('Total Tables', html_content)
            self.assertIn('Total Rows', html_content)
            self.assertIn('2', html_content)  # Number of tables
            self.assertIn('6', html_content)  # Total rows (3 per table)

    def test_17_html_content_connection_info(self):
        """Test HTML content generation includes connection information"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}],
                'total_rows': 1
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check for connection information
            self.assertIn('Database Connection', html_content)
            self.assertIn('test_db', html_content)
            self.assertIn('localhost:5432', html_content)
            self.assertIn('test_user', html_content)
            self.assertIn('postgresql://', html_content)

    def test_18_html_content_error_handling(self):
        """Test HTML content generation error handling"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.side_effect = Exception("Database connection failed")
            
            html_content = generate_html_content(self.database_viewer, ['users'])
            
            # Check for error handling
            self.assertIn('Error loading data', html_content)
            self.assertIn('Database connection failed', html_content)
            self.assertIn('users', html_content)  # Table name should still be shown

    def test_19_html_content_limit_display(self):
        """Test HTML content generation shows limit information"""
        from data_db.commands.build_interface import generate_html_content
        
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': 1}, {'id': 2}],
                'total_rows': 2
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'], limit_per_table=50)
            
            # Check for limit information
            self.assertIn('Showing 2 of 2 rows', html_content)
            
            # Test with more data than limit
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}],
                'data': [{'id': i} for i in range(50)],
                'total_rows': 50
            }
            
            html_content = generate_html_content(self.database_viewer, ['users'], limit_per_table=20)
            self.assertIn('Showing 20 of 50 rows', html_content) 