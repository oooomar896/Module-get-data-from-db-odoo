import unittest
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase, HttpCase
from odoo.exceptions import UserError
import json

class TestDatabaseViewerIntegration(TransactionCase):
    """
    Integration tests for the complete Database Viewer workflow
    """
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Integration Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'integration_test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })

    def test_01_complete_workflow_success(self):
        """Test complete workflow from configuration to data display"""
        
        # Step 1: Test connection
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_connect.return_value = mock_connection
            
            result = self.database_viewer.test_connection()
            self.assertEqual(result['type'], 'ir.actions.client')
            self.assertEqual(result['tag'], 'display_notification')
            self.assertEqual(result['params']['type'], 'success')
        
        # Step 2: Get table list
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.return_value = [('users',), ('products',)]
            mock_connect.return_value = mock_connection
            
            tables = self.database_viewer.get_table_list()
            self.assertEqual(tables, ['users', 'products'])
        
        # Step 3: Get table data
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.side_effect = [
                [('id', 'integer'), ('name', 'varchar')],
                [(1, 'John'), (2, 'Jane')]
            ]
            mock_connect.return_value = mock_connection
            
            data = self.database_viewer.get_table_data('users')
            self.assertEqual(len(data['columns']), 2)
            self.assertEqual(len(data['data']), 2)
            self.assertEqual(data['data'][0]['name'], 'John')
        
        # Step 4: Generate HTML display
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
                mock_get_tables.return_value = ['users']
                mock_get_data.return_value = {
                    'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                    'data': [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}],
                    'total_rows': 2
                }
                
                html_content = self.database_viewer.generate_html_data_display()
                self.assertIn('Database Data Viewer', html_content)
                self.assertIn('users', html_content)
                self.assertIn('John', html_content)
                self.assertIn('Jane', html_content)

    def test_02_odoo_html_display_workflow(self):
        """Test Odoo HTML display workflow"""
        
        # Create data display record
        data_display = self.env['database.data.display'].create({
            'database_viewer_id': self.database_viewer.id,
            'database_name': 'integration_test_db',
            'selected_tables': 'users,products',
            'limit_per_table': 50
        })
        
        # Test onchange
        data_display._onchange_database_viewer()
        self.assertEqual(data_display.database_name, 'integration_test_db')
        
        # Test data generation
        with patch.object(self.database_viewer, 'generate_html_data_display') as mock_generate:
            mock_generate.return_value = '<div>Test HTML Content</div>'
            
            result = data_display.generate_data_display()
            
            self.assertEqual(result['type'], 'ir.actions.act_window')
            self.assertEqual(result['res_model'], 'database.data.display')
            self.assertEqual(result['res_id'], data_display.id)
            self.assertEqual(data_display.html_content, '<div>Test HTML Content</div>')

    def test_03_web_interface_workflow(self):
        """Test web interface workflow"""
        
        # Test open web viewer action
        result = self.database_viewer.open_web_viewer()
        self.assertEqual(result['type'], 'ir.actions.url')
        self.assertEqual(result['url'], '/database-viewer')
        self.assertEqual(result['target'], 'new')
        
        # Test show data in Odoo action
        result = self.database_viewer.show_data_in_odoo()
        self.assertEqual(result['type'], 'ir.actions.act_window')
        self.assertEqual(result['res_model'], 'database.data.display')
        self.assertEqual(result['view_mode'], 'form')
        self.assertEqual(result['target'], 'new')

    def test_04_error_recovery_workflow(self):
        """Test error recovery workflow"""
        
        # Test connection failure recovery
        with patch('psycopg2.connect') as mock_connect:
            mock_connect.side_effect = Exception("Connection failed")
            
            with self.assertRaises(UserError) as context:
                self.database_viewer.test_connection()
            self.assertIn("Connection failed", str(context.exception))
        
        # Test table list failure recovery
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.execute.side_effect = Exception("Database error")
            mock_connect.return_value = mock_connection
            
            with self.assertRaises(UserError) as context:
                self.database_viewer.get_table_list()
            self.assertIn("Error retrieving table list", str(context.exception))
        
        # Test HTML generation with errors
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database error")
            
            html_content = self.database_viewer.generate_html_data_display()
            self.assertIn('Error Loading Database Data', html_content)
            self.assertIn('Database error', html_content)

    def test_05_security_workflow(self):
        """Test security workflow"""
        
        # Test SQL injection protection
        malicious_queries = [
            "DROP TABLE users",
            "DELETE FROM users",
            "UPDATE users SET name='hacker'",
            "INSERT INTO users VALUES (1, 'hacker')",
            "CREATE TABLE hack (id int)",
            "ALTER TABLE users ADD COLUMN hack int",
            "TRUNCATE TABLE users"
        ]
        
        for query in malicious_queries:
            with self.assertRaises(UserError) as context:
                self.database_viewer.execute_custom_query(query)
            self.assertIn("forbidden keyword", str(context.exception))
        
        # Test valid queries
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.description = [('id',), ('name',)]
            mock_cursor.fetchall.return_value = [(1, 'John'), (2, 'Jane')]
            mock_connect.return_value = mock_connection
            
            result = self.database_viewer.execute_custom_query("SELECT id, name FROM users")
            self.assertEqual(len(result['columns']), 2)
            self.assertEqual(len(result['data']), 2)

    def test_06_data_validation_workflow(self):
        """Test data validation workflow"""
        
        # Test table name validation
        invalid_tables = ['', None, 'table;', 'table--', 'table/*', 'table*/']
        for invalid_table in invalid_tables:
            if invalid_table is not None:
                with self.assertRaises(UserError):
                    self.database_viewer._validate_table_name(invalid_table)
        
        # Test valid table names
        valid_tables = ['users', 'user_table', 'user-table', 'user123']
        for valid_table in valid_tables:
            result = self.database_viewer._validate_table_name(valid_table)
            self.assertEqual(result, valid_table)
        
        # Test parameter limits
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.side_effect = [
                [('id', 'integer')],
                [(1,), (2,)]
            ]
            mock_connect.return_value = mock_connection
            
            # Test with large limit (should be clamped)
            data = self.database_viewer.get_table_data('users', limit=9999, offset=0)
            # The limit should be clamped to 1000 in the method
            
            # Test with negative offset (should be clamped)
            data = self.database_viewer.get_table_data('users', limit=10, offset=-999)
            # The offset should be clamped to 0

    def test_07_multiple_configurations_workflow(self):
        """Test workflow with multiple database configurations"""
        
        # Create second configuration
        database_viewer2 = self.env['database.viewer'].create({
            'name': 'Second Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'second_test_db',
            'username': 'test_user2',
            'password': 'test_password2',
            'active': True
        })
        
        # Test that both configurations exist
        all_configs = self.env['database.viewer'].search([])
        self.assertEqual(len(all_configs), 2)
        
        # Test that only active configurations are returned
        active_configs = self.env['database.viewer'].search([('active', '=', True)])
        self.assertEqual(len(active_configs), 2)
        
        # Deactivate one configuration
        database_viewer2.active = False
        active_configs = self.env['database.viewer'].search([('active', '=', True)])
        self.assertEqual(len(active_configs), 1)
        self.assertEqual(active_configs[0], self.database_viewer)

    def test_08_large_dataset_workflow(self):
        """Test workflow with large datasets"""
        
        # Create large dataset
        large_data = []
        for i in range(1000):
            large_data.append((i, f'User {i}', f'user{i}@example.com'))
        
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.side_effect = [
                [('id', 'integer'), ('name', 'varchar'), ('email', 'varchar')],
                large_data[:100]  # Only return first 100 rows due to limit
            ]
            mock_connect.return_value = mock_connection
            
            data = self.database_viewer.get_table_data('users', limit=100, offset=0)
            self.assertEqual(len(data['columns']), 3)
            self.assertEqual(len(data['data']), 100)
            self.assertEqual(data['total_rows'], 1000)

    def test_09_concurrent_access_workflow(self):
        """Test workflow with concurrent access simulation"""
        
        # Simulate multiple concurrent requests
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.return_value = [('users',), ('products',)]
            mock_connect.return_value = mock_connection
            
            # Simulate multiple table list requests
            tables1 = self.database_viewer.get_table_list()
            tables2 = self.database_viewer.get_table_list()
            tables3 = self.database_viewer.get_table_list()
            
            self.assertEqual(tables1, ['users', 'products'])
            self.assertEqual(tables2, ['users', 'products'])
            self.assertEqual(tables3, ['users', 'products'])
            
            # Verify connections are properly closed
            self.assertEqual(mock_connection.close.call_count, 3)

    def test_10_data_types_workflow(self):
        """Test workflow with different data types"""
        
        # Test with various data types
        test_data = [
            (1, 'John Doe', 'john@example.com', 25.5, True, None),
            (2, 'Jane Smith', 'jane@example.com', 30.0, False, '2023-01-01'),
            (3, 'Bob Johnson', 'bob@example.com', 0.0, True, '2023-12-31')
        ]
        
        with patch('psycopg2.connect') as mock_connect:
            mock_connection = MagicMock()
            mock_cursor = MagicMock()
            mock_connection.cursor.return_value = mock_cursor
            mock_cursor.fetchall.side_effect = [
                [('id', 'integer'), ('name', 'varchar'), ('email', 'varchar'), 
                 ('age', 'numeric'), ('active', 'boolean'), ('created_date', 'date')],
                test_data
            ]
            mock_connect.return_value = mock_connection
            
            data = self.database_viewer.get_table_data('users')
            self.assertEqual(len(data['columns']), 6)
            self.assertEqual(len(data['data']), 3)
            
            # Check data types are handled correctly
            self.assertEqual(data['data'][0]['id'], 1)
            self.assertEqual(data['data'][0]['name'], 'John Doe')
            self.assertEqual(data['data'][0]['age'], 25.5)
            self.assertEqual(data['data'][0]['active'], True)
            self.assertIsNone(data['data'][0]['created_date'])


class TestDatabaseViewerWebIntegration(HttpCase):
    """
    Integration tests for web interface
    """
    
    def setUp(self):
        super().setUp()
        # Create a test database viewer configuration
        self.database_viewer = self.env['database.viewer'].create({
            'name': 'Web Integration Test Database',
            'host': 'localhost',
            'port': 5432,
            'database': 'web_integration_test_db',
            'username': 'test_user',
            'password': 'test_password',
            'active': True
        })

    def test_01_web_interface_complete_workflow(self):
        """Test complete web interface workflow"""
        
        # Test main page
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.return_value = ['users', 'products']
            
            response = self.url_open('/database-viewer')
            self.assertEqual(response.status_code, 200)
            
            content = response.text
            self.assertIn('Database Data Viewer', content)
            self.assertIn('users', content)
            self.assertIn('products', content)
        
        # Test API endpoints
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.return_value = {
                'columns': [{'name': 'id', 'type': 'integer'}, {'name': 'name', 'type': 'varchar'}],
                'data': [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}],
                'total_rows': 2
            }
            
            response = self.url_open('/database-viewer/api/table-data/users')
            self.assertEqual(response.status_code, 200)
            
            data = json.loads(response.text)
            self.assertEqual(len(data['columns']), 2)
            self.assertEqual(len(data['data']), 2)
        
        # Test stats endpoint
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            with patch.object(self.database_viewer, 'get_table_count') as mock_get_count:
                mock_get_tables.return_value = ['users', 'products']
                mock_get_count.return_value = 100
                
                response = self.url_open('/database-viewer/api/stats')
                self.assertEqual(response.status_code, 200)
                
                data = json.loads(response.text)
                self.assertEqual(data['total_tables'], 2)
                self.assertEqual(data['total_rows'], 200)

    def test_02_web_interface_error_handling(self):
        """Test web interface error handling"""
        
        # Test page with database error
        with patch.object(self.database_viewer, 'get_table_list') as mock_get_tables:
            mock_get_tables.side_effect = Exception("Database connection failed")
            
            response = self.url_open('/database-viewer')
            self.assertEqual(response.status_code, 200)
            
            content = response.text
            self.assertIn('Error Loading Database Viewer', content)
            self.assertIn('Database connection failed', content)
        
        # Test API with invalid table
        response = self.url_open('/database-viewer/api/table-data/invalid;table')
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.text)
        self.assertIn('Invalid table name', data['error'])
        
        # Test API with database error
        with patch.object(self.database_viewer, 'get_table_data') as mock_get_data:
            mock_get_data.side_effect = Exception("Database error")
            
            response = self.url_open('/database-viewer/api/table-data/users')
            self.assertEqual(response.status_code, 500)
            
            data = json.loads(response.text)
            self.assertIn('Database error', data['error'])

    def test_03_web_interface_no_configuration(self):
        """Test web interface when no configuration exists"""
        
        # Deactivate all configurations
        self.database_viewer.active = False
        self.database_viewer.save()
        
        # Test main page
        response = self.url_open('/database-viewer')
        self.assertEqual(response.status_code, 200)
        
        content = response.text
        self.assertIn('No Active Database Configuration Found', content)
        self.assertIn('Go to Configuration', content)
        
        # Test API endpoints
        response = self.url_open('/database-viewer/api/table-data/users')
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.text)
        self.assertIn('No active database configuration', data['error'])
        
        response = self.url_open('/database-viewer/api/stats')
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.text)
        self.assertIn('No active database configuration', data['error']) 