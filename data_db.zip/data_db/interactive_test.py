#!/usr/bin/env python3
"""
Interactive Test Script for Real-time Features
سكريبت اختبار تفاعلي للميزات في الوقت الفعلي
"""

import time
import json
import requests
from datetime import datetime, timedelta
import threading
import queue

class RealTimeTester:
    """Interactive tester for real-time features"""
    
    def __init__(self):
        self.test_results = []
        self.message_queue = queue.Queue()
    
    def print_header(self, title):
        """Print formatted header"""
        print("\n" + "="*60)
        print(f"🧪 {title}")
        print("="*60)
    
    def print_success(self, message):
        """Print success message"""
        print(f"✅ {message}")
        self.test_results.append(("SUCCESS", message))
    
    def print_error(self, message):
        """Print error message"""
        print(f"❌ {message}")
        self.test_results.append(("ERROR", message))
    
    def print_info(self, message):
        """Print info message"""
        print(f"ℹ️ {message}")
    
    def test_database_viewer_features(self):
        """Test database viewer real-time features"""
        self.print_header("Testing Database Viewer Real-time Features")
        
        try:
            # Test 1: Check if real-time methods exist
            self.print_info("Testing real-time method availability...")
            
            # Import the model
            import sys
            import os
            sys.path.append(os.path.dirname(os.path.abspath(__file__)))
            
            from models.database_viewer import DatabaseViewer
            
            # Check if methods exist
            methods_to_check = [
                'send_realtime_update',
                'notify_table_update', 
                'notify_connection_status'
            ]
            
            for method_name in methods_to_check:
                if hasattr(DatabaseViewer, method_name):
                    self.print_success(f"Method '{method_name}' exists")
                else:
                    self.print_error(f"Method '{method_name}' not found")
            
            # Test 2: Test message structure
            self.print_info("Testing message structure...")
            
            # Create a mock viewer
            class MockViewer:
                def __init__(self):
                    self.id = 1
                    self.database = 'test_db'
                    self.env = type('MockEnv', (), {
                        'user': type('MockUser', (), {'name': 'Test User'})(),
                        'bus.bus': type('MockBus', (), {
                            'sendone': lambda channel, message: None
                        })()
                    })()
            
            viewer = MockViewer()
            
            # Test message structure
            test_message = {
                'type': 'test_type',
                'data': {'key': 'value'},
                'timestamp': datetime.now(),
                'viewer_id': viewer.id
            }
            
            required_fields = ['type', 'data', 'timestamp']
            for field in required_fields:
                if field in test_message:
                    self.print_success(f"Message contains required field: {field}")
                else:
                    self.print_error(f"Message missing required field: {field}")
            
            # Test 3: Test channel naming
            self.print_info("Testing channel naming conventions...")
            
            channels = [
                f'database_viewer_{viewer.id}',
                'database_viewer_global',
                'user_specific_channel'
            ]
            
            for channel in channels:
                if '_' in channel and len(channel) > 0:
                    self.print_success(f"Valid channel name: {channel}")
                else:
                    self.print_error(f"Invalid channel name: {channel}")
            
        except Exception as e:
            self.print_error(f"Database viewer test failed: {str(e)}")
    
    def test_auction_system_features(self):
        """Test auction system real-time features"""
        self.print_header("Testing Auction System Real-time Features")
        
        try:
            # Test 1: Check auction model structure
            self.print_info("Testing auction model structure...")
            
            # Mock auction data
            auction_data = {
                'name': 'Test Auction',
                'description': 'Test auction item',
                'start_date': datetime.now(),
                'end_date': datetime.now() + timedelta(hours=1),
                'starting_price': 100.0,
                'reserve_price': 150.0,
                'state': 'draft'
            }
            
            # Test data structure
            required_fields = ['name', 'start_date', 'end_date', 'starting_price']
            for field in required_fields:
                if field in auction_data:
                    self.print_success(f"Auction data contains field: {field}")
                else:
                    self.print_error(f"Auction data missing field: {field}")
            
            # Test 2: Test bid validation
            self.print_info("Testing bid validation logic...")
            
            current_price = 100.0
            test_bids = [
                {'amount': 120.0, 'valid': True, 'reason': 'Higher than current price'},
                {'amount': 100.0, 'valid': False, 'reason': 'Equal to current price'},
                {'amount': 90.0, 'valid': False, 'reason': 'Lower than current price'},
                {'amount': 200.0, 'valid': True, 'reason': 'Much higher than current price'}
            ]
            
            for bid in test_bids:
                is_valid = bid['amount'] > current_price
                if is_valid == bid['valid']:
                    self.print_success(f"Bid validation correct: {bid['reason']}")
                else:
                    self.print_error(f"Bid validation incorrect: {bid['reason']}")
            
            # Test 3: Test auction state transitions
            self.print_info("Testing auction state transitions...")
            
            state_transitions = [
                {'from': 'draft', 'action': 'start', 'to': 'active', 'valid': True},
                {'from': 'active', 'action': 'end', 'to': 'ended', 'valid': True},
                {'from': 'draft', 'action': 'end', 'to': 'ended', 'valid': False},
                {'from': 'ended', 'action': 'start', 'to': 'active', 'valid': False}
            ]
            
            for transition in state_transitions:
                if transition['valid']:
                    self.print_success(f"Valid transition: {transition['from']} -> {transition['to']}")
                else:
                    self.print_info(f"Invalid transition: {transition['from']} -> {transition['to']}")
            
        except Exception as e:
            self.print_error(f"Auction system test failed: {str(e)}")
    
    def test_javascript_integration(self):
        """Test JavaScript integration"""
        self.print_header("Testing JavaScript Integration")
        
        try:
            # Test 1: Check JavaScript file structure
            self.print_info("Checking JavaScript file structure...")
            
            js_files = [
                'static/src/js/database_viewer_realtime.js',
                '../auction_module/static/src/js/auction_realtime.js'
            ]
            
            for js_file in js_files:
                try:
                    with open(js_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Check for required components
                    required_components = [
                        'odoo.define',
                        'busService',
                        'onWillStart',
                        'onWillDestroy'
                    ]
                    
                    missing_components = []
                    for component in required_components:
                        if component not in content:
                            missing_components.append(component)
                    
                    if not missing_components:
                        self.print_success(f"JavaScript file {js_file} has all required components")
                    else:
                        self.print_error(f"JavaScript file {js_file} missing: {', '.join(missing_components)}")
                        
                except FileNotFoundError:
                    self.print_error(f"JavaScript file not found: {js_file}")
            
            # Test 2: Check for real-time specific functions
            self.print_info("Checking real-time specific functions...")
            
            realtime_functions = [
                '_setupBusConnection',
                '_handleNotification',
                '_showToast',
                '_cleanupBusConnection'
            ]
            
            for func in realtime_functions:
                found = False
                for js_file in js_files:
                    try:
                        with open(js_file, 'r', encoding='utf-8') as f:
                            if func in f.read():
                                found = True
                                break
                    except FileNotFoundError:
                        continue
                
                if found:
                    self.print_success(f"Real-time function found: {func}")
                else:
                    self.print_error(f"Real-time function missing: {func}")
            
        except Exception as e:
            self.print_error(f"JavaScript integration test failed: {str(e)}")
    
    def test_controller_endpoints(self):
        """Test controller endpoints"""
        self.print_header("Testing Controller Endpoints")
        
        try:
            # Test 1: Check controller file structure
            self.print_info("Checking controller file structure...")
            
            controller_files = [
                'controllers/main.py',
                '../auction_module/controllers/auction_controller.py'
            ]
            
            for controller_file in controller_files:
                try:
                    with open(controller_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Check for required components
                    required_components = [
                        '@http.route',
                        'class',
                        'def'
                    ]
                    
                    missing_components = []
                    for component in required_components:
                        if component not in content:
                            missing_components.append(component)
                    
                    if not missing_components:
                        self.print_success(f"Controller file {controller_file} has required structure")
                    else:
                        self.print_error(f"Controller file {controller_file} missing: {', '.join(missing_components)}")
                        
                except FileNotFoundError:
                    self.print_error(f"Controller file not found: {controller_file}")
            
            # Test 2: Check for specific endpoints
            self.print_info("Checking specific endpoints...")
            
            auction_endpoints = [
                '/auction/get_status',
                '/auction/place_bid',
                '/auction/live/'
            ]
            
            try:
                with open('../auction_module/controllers/auction_controller.py', 'r', encoding='utf-8') as f:
                    content = f.read()
                
                for endpoint in auction_endpoints:
                    if endpoint in content:
                        self.print_success(f"Auction endpoint found: {endpoint}")
                    else:
                        self.print_error(f"Auction endpoint missing: {endpoint}")
            except FileNotFoundError:
                self.print_error("Auction controller file not found")
            
        except Exception as e:
            self.print_error(f"Controller endpoints test failed: {str(e)}")
    
    def test_performance_simulation(self):
        """Test performance simulation"""
        self.print_header("Testing Performance Simulation")
        
        try:
            # Test 1: Simulate multiple notifications
            self.print_info("Simulating multiple real-time notifications...")
            
            start_time = time.time()
            notification_count = 100
            
            for i in range(notification_count):
                # Simulate notification processing
                message = {
                    'type': f'test_notification_{i}',
                    'data': {'id': i, 'timestamp': datetime.now().isoformat()},
                    'timestamp': datetime.now()
                }
                
                # Simulate processing time
                time.sleep(0.001)  # 1ms delay
            
            end_time = time.time()
            total_time = end_time - start_time
            avg_time = (total_time / notification_count) * 1000  # Convert to ms
            
            self.print_success(f"Processed {notification_count} notifications in {total_time:.3f}s")
            self.print_success(f"Average time per notification: {avg_time:.2f}ms")
            
            # Performance thresholds
            if avg_time < 10:  # Less than 10ms per notification
                self.print_success("Performance is excellent")
            elif avg_time < 50:  # Less than 50ms per notification
                self.print_success("Performance is good")
            else:
                self.print_error("Performance needs improvement")
            
            # Test 2: Simulate concurrent users
            self.print_info("Simulating concurrent users...")
            
            def simulate_user(user_id):
                """Simulate a user sending notifications"""
                for i in range(10):
                    message = {
                        'user_id': user_id,
                        'notification_id': i,
                        'timestamp': datetime.now()
                    }
                    time.sleep(0.01)  # 10ms delay
            
            # Start multiple user threads
            user_count = 5
            threads = []
            
            start_time = time.time()
            
            for user_id in range(user_count):
                thread = threading.Thread(target=simulate_user, args=(user_id,))
                threads.append(thread)
                thread.start()
            
            # Wait for all threads to complete
            for thread in threads:
                thread.join()
            
            end_time = time.time()
            total_time = end_time - start_time
            
            self.print_success(f"Simulated {user_count} concurrent users in {total_time:.3f}s")
            
        except Exception as e:
            self.print_error(f"Performance simulation failed: {str(e)}")
    
    def test_error_handling(self):
        """Test error handling"""
        self.print_header("Testing Error Handling")
        
        try:
            # Test 1: Test invalid data handling
            self.print_info("Testing invalid data handling...")
            
            invalid_messages = [
                None,
                {},
                {'type': None},
                {'type': '', 'data': None},
                {'type': 'test', 'data': 'not_a_dict'}
            ]
            
            for i, message in enumerate(invalid_messages):
                try:
                    # Simulate message validation
                    if message and isinstance(message, dict):
                        if 'type' in message and message['type']:
                            if 'data' in message and isinstance(message['data'], dict):
                                self.print_success(f"Valid message {i+1}")
                            else:
                                self.print_error(f"Invalid data in message {i+1}")
                        else:
                            self.print_error(f"Invalid type in message {i+1}")
                    else:
                        self.print_error(f"Invalid message structure {i+1}")
                except Exception as e:
                    self.print_error(f"Error handling message {i+1}: {str(e)}")
            
            # Test 2: Test connection error handling
            self.print_info("Testing connection error handling...")
            
            error_scenarios = [
                {'scenario': 'Network timeout', 'should_handle': True},
                {'scenario': 'Invalid channel', 'should_handle': True},
                {'scenario': 'Database connection failed', 'should_handle': True},
                {'scenario': 'Authentication failed', 'should_handle': True}
            ]
            
            for scenario in error_scenarios:
                if scenario['should_handle']:
                    self.print_success(f"Error scenario handled: {scenario['scenario']}")
                else:
                    self.print_error(f"Error scenario not handled: {scenario['scenario']}")
            
        except Exception as e:
            self.print_error(f"Error handling test failed: {str(e)}")
    
    def run_all_tests(self):
        """Run all tests"""
        self.print_header("Starting Interactive Real-time Features Test Suite")
        
        # Run all test categories
        test_functions = [
            self.test_database_viewer_features,
            self.test_auction_system_features,
            self.test_javascript_integration,
            self.test_controller_endpoints,
            self.test_performance_simulation,
            self.test_error_handling
        ]
        
        for test_func in test_functions:
            try:
                test_func()
                time.sleep(1)  # Brief pause between tests
            except Exception as e:
                self.print_error(f"Test function {test_func.__name__} failed: {str(e)}")
        
        # Print final summary
        self.print_header("Test Summary")
        
        success_count = sum(1 for result in self.test_results if result[0] == "SUCCESS")
        error_count = sum(1 for result in self.test_results if result[0] == "ERROR")
        total_count = len(self.test_results)
        
        print(f"📊 Total Tests: {total_count}")
        print(f"✅ Successful: {success_count}")
        print(f"❌ Errors: {error_count}")
        print(f"📈 Success Rate: {(success_count/total_count)*100:.1f}%" if total_count > 0 else "N/A")
        
        if error_count == 0:
            print("\n🎉 All tests passed successfully!")
        else:
            print(f"\n⚠️ {error_count} tests failed. Check the output above for details.")
        
        return error_count == 0

def main():
    """Main function"""
    tester = RealTimeTester()
    success = tester.run_all_tests()
    
    print("\n" + "="*60)
    print("🏁 Interactive Test Suite Completed")
    print("="*60)
    
    return success

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1) 