{
    'name': 'Database Data Viewer',
    'version': '1.0.0',
    'category': 'Tools',
    'summary': 'Display database data through interactive web interface',
    'description': """
        This module provides both a web interface and command-line tool to view data from PostgreSQL databases.
        
        Features:
        - Interactive web interface accessible from Odoo
        - Real-time database connection and data display
        - Dynamic table browsing with click-to-expand
        - Command-line interface to generate static HTML
        - Custom SQL query execution
        - Export capabilities
        - Responsive design for all devices
    """,
    'author': 'عمر العديني',
    'website': 'https://github.com/oooomar896',
    'depends': ['base', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/database_viewer_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
} 