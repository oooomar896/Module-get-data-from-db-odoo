# Contributing to Database Data Viewer

Thank you for your interest in contributing to the Database Data Viewer module! This document provides guidelines and information for contributors.

## Table of Contents

- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Code Standards](#code-standards)
- [Testing Guidelines](#testing-guidelines)
- [Pull Request Process](#pull-request-process)
- [Bug Reports](#bug-reports)
- [Feature Requests](#feature-requests)
- [Documentation](#documentation)
- [Release Process](#release-process)

## Getting Started

### Prerequisites

Before contributing, ensure you have:

- **Python 3.8+** installed
- **Odoo 16.0+** installed and configured
- **PostgreSQL** database server
- **Git** for version control
- **IDE** with Python support (VS Code, PyCharm, etc.)

### Development Environment

1. **Fork the Repository**
   ```bash
   # Fork the repository on GitHub
   # Clone your fork
   git clone https://github.com/your-username/data_db.git
   cd data_db
   ```

2. **Set Up Virtual Environment**
   ```bash
   # Create virtual environment
   python -m venv venv
   
   # Activate virtual environment
   # Windows
   venv\Scripts\activate
   
   # Linux/Mac
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   pip install -e .
   ```

## Development Setup

### Local Development

1. **Configure Odoo**
   ```bash
   # Copy Odoo configuration
   cp /path/to/odoo/odoo.conf ./odoo.conf
   
   # Edit configuration
   nano odoo.conf
   ```

2. **Set Up Development Database**
   ```bash
   # Create development database
   createdb data_db_dev
   
   # Install module in development mode
   python /path/to/odoo/odoo-bin -d data_db_dev -i data_db --dev=all
   ```

3. **Run Development Server**
   ```bash
   # Start Odoo with development options
   python /path/to/odoo/odoo-bin -d data_db_dev --dev=all --reload
   ```

### Testing Setup

1. **Install Test Dependencies**
   ```bash
   pip install pytest pytest-cov pytest-mock
   pip install coverage
   ```

2. **Configure Test Database**
   ```bash
   # Create test database
   createdb data_db_test
   
   # Run tests
   python run_tests.py
   ```

## Code Standards

### Python Code Style

Follow **PEP 8** style guide:

```python
# Good
def get_table_data(self, table_name, limit=100, offset=0):
    """Get data from specified table.
    
    Args:
        table_name (str): Name of the table
        limit (int): Maximum number of rows to return
        offset (int): Number of rows to skip
        
    Returns:
        dict: Table data with columns and rows
        
    Raises:
        UserError: If table name is invalid
    """
    if not table_name:
        raise UserError("Table name is required")
    
    # Validate parameters
    limit = max(1, min(limit, 1000))
    offset = max(0, offset)
    
    return self._execute_query(table_name, limit, offset)

# Bad
def getTableData(self,tableName,limit=100,offset=0):
    if not tableName:raise UserError("Table name is required")
    limit=max(1,min(limit,1000))
    offset=max(0,offset)
    return self._execute_query(tableName,limit,offset)
```

### Naming Conventions

- **Classes**: PascalCase (e.g., `DatabaseViewer`)
- **Functions/Methods**: snake_case (e.g., `get_table_data`)
- **Variables**: snake_case (e.g., `table_name`)
- **Constants**: UPPER_SNAKE_CASE (e.g., `MAX_ROWS`)
- **Files**: snake_case (e.g., `database_viewer.py`)

### Documentation Standards

1. **Docstrings**: Use Google style docstrings
   ```python
   def process_data(self, data):
       """Process the given data.
       
       Args:
           data (list): List of data records to process
           
       Returns:
           dict: Processed data with statistics
           
       Raises:
           ValueError: If data is empty
           TypeError: If data is not a list
       """
   ```

2. **Comments**: Explain why, not what
   ```python
   # Good: Explains the reason
   # Use connection pooling to improve performance
   connection = self.get_connection_from_pool()
   
   # Bad: Explains the obvious
   # Get connection from pool
   connection = self.get_connection_from_pool()
   ```

3. **Type Hints**: Use type hints for function parameters and return values
   ```python
   from typing import List, Dict, Optional
   
   def get_table_data(self, table_name: str, limit: int = 100) -> Dict[str, any]:
       """Get data from table."""
       pass
   ```

### Security Standards

1. **Input Validation**: Always validate user input
   ```python
   def validate_input(self, user_input: str) -> str:
       """Validate and sanitize user input."""
       if not user_input or not isinstance(user_input, str):
           raise UserError("Invalid input")
       
       # Sanitize input
       sanitized = html.escape(user_input.strip())
       return sanitized
   ```

2. **SQL Injection Protection**: Use parameterized queries
   ```python
   # Good: Parameterized query
   cursor.execute('SELECT * FROM "{}" WHERE id = %s'.format(table_name), (record_id,))
   
   # Bad: String concatenation
   cursor.execute(f'SELECT * FROM {table_name} WHERE id = {record_id}')
   ```

3. **Error Handling**: Don't expose sensitive information
   ```python
   # Good: Safe error message
   except psycopg2.Error as e:
       logger.error(f"Database error: {e}")
       raise UserError("Database operation failed")
   
   # Bad: Exposes internal details
   except psycopg2.Error as e:
       raise UserError(f"Database error: {e}")
   ```

## Testing Guidelines

### Test Structure

1. **Test File Organization**
   ```
   tests/
   ├── test_database_viewer.py      # Model tests
   ├── test_controllers.py          # Controller tests
   ├── test_commands.py             # Command line tests
   └── test_integration.py          # Integration tests
   ```

2. **Test Class Structure**
   ```python
   class TestDatabaseViewer(TransactionCase):
       """Test cases for Database Viewer model."""
       
       def setUp(self):
           """Set up test data."""
           super().setUp()
           self.database_viewer = self.env['database.viewer'].create({
               'name': 'Test Database',
               'host': 'localhost',
               'port': 5432,
               'database': 'test_db',
               'username': 'test_user',
               'password': 'test_password',
               'active': True
           })
       
       def test_01_create_database_viewer(self):
           """Test creating a database viewer configuration."""
           self.assertEqual(self.database_viewer.name, 'Test Database')
           self.assertEqual(self.database_viewer.host, 'localhost')
   ```

### Test Naming

- **Test Methods**: `test_01_description`, `test_02_description`
- **Test Classes**: `TestClassName`
- **Test Files**: `test_module_name.py`

### Test Coverage

Aim for **90%+ test coverage**:

```bash
# Run tests with coverage
coverage run -m pytest tests/
coverage report
coverage html  # Generate HTML report
```

### Test Types

1. **Unit Tests**: Test individual functions/methods
   ```python
   def test_validate_table_name(self):
       """Test table name validation."""
       # Valid names
       self.assertEqual(self.viewer._validate_table_name('users'), 'users')
       
       # Invalid names
       with self.assertRaises(UserError):
           self.viewer._validate_table_name('users; DROP TABLE users; --')
   ```

2. **Integration Tests**: Test complete workflows
   ```python
   def test_complete_workflow(self):
       """Test complete database viewer workflow."""
       # Test connection
       result = self.viewer.test_connection()
       self.assertEqual(result['type'], 'ir.actions.client')
       
       # Test data retrieval
       data = self.viewer.get_table_data('users')
       self.assertIn('columns', data)
       self.assertIn('data', data)
   ```

3. **Security Tests**: Test security measures
   ```python
   def test_sql_injection_protection(self):
       """Test SQL injection protection."""
       malicious_inputs = [
           "'; DROP TABLE users; --",
           "' OR 1=1; --",
           "'; INSERT INTO users VALUES (1, 'hacker'); --"
       ]
       
       for malicious_input in malicious_inputs:
           with self.assertRaises(UserError):
               self.viewer._validate_table_name(malicious_input)
   ```

### Mock Testing

Use mocks for external dependencies:

```python
from unittest.mock import patch, MagicMock

@patch('psycopg2.connect')
def test_database_connection(self, mock_connect):
    """Test database connection with mock."""
    mock_connection = MagicMock()
    mock_connect.return_value = mock_connection
    
    connection = self.viewer.get_database_connection()
    
    mock_connect.assert_called_once_with(
        host='localhost',
        port=5432,
        database='test_db',
        user='test_user',
        password='test_password'
    )
    self.assertEqual(connection, mock_connection)
```

## Pull Request Process

### Before Submitting

1. **Run Tests**
   ```bash
   # Run all tests
   python run_tests.py
   
   # Run specific test categories
   python run_tests.py security
   ```

2. **Check Code Style**
   ```bash
   # Install flake8
   pip install flake8
   
   # Check code style
   flake8 .
   ```

3. **Update Documentation**
   - Update README.md if needed
   - Add docstrings for new functions
   - Update CHANGELOG.md

### Pull Request Guidelines

1. **Title**: Clear and descriptive
   ```
   Add data export functionality
   Fix SQL injection vulnerability in table validation
   Improve performance for large datasets
   ```

2. **Description**: Detailed explanation
   ```markdown
   ## Description
   Added CSV export functionality for table data.
   
   ## Changes
   - Added export_to_csv method to DatabaseViewer model
   - Added export button to web interface
   - Added tests for export functionality
   
   ## Testing
   - [x] Unit tests pass
   - [x] Integration tests pass
   - [x] Security tests pass
   - [x] Manual testing completed
   
   ## Checklist
   - [x] Code follows style guidelines
   - [x] Documentation updated
   - [x] Tests added for new functionality
   - [x] No breaking changes
   ```

3. **Code Review**: Address feedback
   - Respond to review comments
   - Make requested changes
   - Update tests if needed

## Bug Reports

### Bug Report Template

```markdown
## Bug Description
Brief description of the bug.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Environment
- Odoo Version: 16.0
- Module Version: 1.0.0
- Database: PostgreSQL 13
- Browser: Chrome 90
- OS: Ubuntu 20.04

## Error Messages
```
Error: Connection failed
Traceback (most recent call last):
  File "...", line 123, in ...
    connection = psycopg2.connect(...)
```

## Additional Information
Any other context about the problem.
```

### Bug Report Guidelines

1. **Be Specific**: Provide exact steps to reproduce
2. **Include Environment**: OS, Odoo version, database version
3. **Attach Logs**: Include relevant error logs
4. **Test First**: Verify the bug exists in latest version

## Feature Requests

### Feature Request Template

```markdown
## Feature Description
Brief description of the requested feature.

## Use Case
Why this feature is needed and how it would be used.

## Proposed Solution
How you think this feature should be implemented.

## Alternatives Considered
Other approaches that were considered.

## Additional Information
Any other relevant information.
```

### Feature Request Guidelines

1. **Be Clear**: Explain the feature clearly
2. **Provide Context**: Why is this feature needed?
3. **Consider Implementation**: Think about how it could be implemented
4. **Check Existing**: Make sure the feature doesn't already exist

## Documentation

### Documentation Standards

1. **README.md**: Main documentation
   - Installation instructions
   - Usage examples
   - Configuration guide
   - Troubleshooting

2. **Code Documentation**: Inline documentation
   - Function docstrings
   - Class docstrings
   - Module docstrings

3. **API Documentation**: API reference
   - Endpoint descriptions
   - Parameter documentation
   - Response examples

### Documentation Guidelines

1. **Be Clear**: Use simple, clear language
2. **Include Examples**: Provide practical examples
3. **Keep Updated**: Update documentation with code changes
4. **Use Markdown**: Use proper markdown formatting

## Release Process

### Version Numbering

Follow [Semantic Versioning](https://semver.org/):

- **Major Version (X.0.0)**: Breaking changes
- **Minor Version (X.Y.0)**: New features, backward compatible
- **Patch Version (X.Y.Z)**: Bug fixes

### Release Checklist

- [ ] **Code Quality**
  - [ ] All tests pass
  - [ ] Code style checked
  - [ ] Security review completed
  - [ ] Performance tested

- [ ] **Documentation**
  - [ ] README.md updated
  - [ ] CHANGELOG.md updated
  - [ ] API documentation updated
  - [ ] Installation guide verified

- [ ] **Testing**
  - [ ] Unit tests pass
  - [ ] Integration tests pass
  - [ ] Security tests pass
  - [ ] Manual testing completed

- [ ] **Release**
  - [ ] Version number updated
  - [ ] Git tag created
  - [ ] Release notes written
  - [ ] Distribution package created

### Release Steps

1. **Update Version**
   ```python
   # In __manifest__.py
   'version': '1.1.0',
   ```

2. **Update Changelog**
   ```markdown
   ## [1.1.0] - 2024-01-20
   
   ### Added
   - New feature X
   - New feature Y
   
   ### Changed
   - Improved performance
   
   ### Fixed
   - Bug fix A
   - Bug fix B
   ```

3. **Create Release**
   ```bash
   # Create and push tag
   git tag v1.1.0
   git push origin v1.1.0
   
   # Create release on GitHub
   # Upload distribution package
   ```

## Getting Help

### Communication Channels

- **GitHub Issues**: For bug reports and feature requests
- **GitHub Discussions**: For questions and discussions
- **Email**: For security issues (use private email)

### Resources

- [Odoo Documentation](https://www.odoo.com/documentation/)
- [Python Documentation](https://docs.python.org/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

## Code of Conduct

### Our Standards

- Be respectful and inclusive
- Use welcoming and inclusive language
- Be collaborative and constructive
- Focus on what is best for the community

### Enforcement

- Unacceptable behavior will not be tolerated
- Violations will be addressed appropriately
- Maintainers have the right to remove contributions

## License

By contributing to this project, you agree that your contributions will be licensed under the same license as the project.

## Acknowledgments

Thank you for contributing to the Database Data Viewer module! Your contributions help make this tool better for everyone. 