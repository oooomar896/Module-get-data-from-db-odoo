import json
from odoo import http
from odoo.http import request, Response
import logging
import re

_logger = logging.getLogger(__name__)

class DatabaseViewerController(http.Controller):
    
    @http.route('/database-viewer', type='http', auth='user')
    def database_viewer_page(self, **kwargs):
        """Main page for database viewer"""
        try:
            # Check if database.viewer model exists
            if 'database.viewer' not in request.env:
                return """
                <html>
                <head>
                    <title>Database Viewer - Module Not Installed</title>
                    <meta charset="utf-8">
                    <style>
                        body { 
                            font-family: Arial, sans-serif; 
                            margin: 40px; 
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                        }
                        .error-container {
                            background: white;
                            padding: 40px;
                            border-radius: 10px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                            text-align: center;
                            max-width: 500px;
                        }
                        .error { 
                            color: #dc3545; 
                            background: #f8d7da; 
                            padding: 20px; 
                            border-radius: 5px; 
                            margin: 20px 0;
                        }
                        .btn {
                            display: inline-block;
                            background: #3498db;
                            color: white;
                            padding: 12px 24px;
                            text-decoration: none;
                            border-radius: 5px;
                            margin-top: 20px;
                        }
                        .btn:hover {
                            background: #2980b9;
                        }
                    </style>
                </head>
                <body>
                    <div class="error-container">
                        <h1>🔍 Database Viewer</h1>
                        <div class="error">
                            <h2>Module Not Properly Installed</h2>
                            <p>The database viewer module is not properly installed or configured.</p>
                        </div>
                        <a href="/web" class="btn">Go to Odoo</a>
                    </div>
                </body>
                </html>
                """
            
            # Get active database viewer configuration
            DatabaseViewer = request.env['database.viewer']
            viewers = DatabaseViewer.search([('active', '=', True)])
            
            if not viewers:
                return """
                <html>
                <head>
                    <title>Database Viewer - No Configuration</title>
                    <meta charset="utf-8">
                    <style>
                        body { 
                            font-family: Arial, sans-serif; 
                            margin: 40px; 
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                        }
                        .error-container {
                            background: white;
                            padding: 40px;
                            border-radius: 10px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                            text-align: center;
                            max-width: 500px;
                        }
                        .error { 
                            color: #dc3545; 
                            background: #f8d7da; 
                            padding: 20px; 
                            border-radius: 5px; 
                            margin: 20px 0;
                        }
                        .btn {
                            display: inline-block;
                            background: #3498db;
                            color: white;
                            padding: 12px 24px;
                            text-decoration: none;
                            border-radius: 5px;
                            margin-top: 20px;
                        }
                        .btn:hover {
                            background: #2980b9;
                        }
                    </style>
                </head>
                <body>
                    <div class="error-container">
                        <h1>🔍 Database Viewer</h1>
                        <div class="error">
                            <h2>No Active Database Configuration Found</h2>
                            <p>Please configure a database connection in Tools → Database Viewer first.</p>
                        </div>
                        <a href="/web#menu_id=base.menu_custom&action=action_database_viewer" class="btn">Go to Configuration</a>
                    </div>
                </body>
                </html>
                """
            
            viewer = viewers[0]
            
            # Get table list
            try:
                tables = viewer.get_table_list()
            except Exception as e:
                _logger.error(f"Error getting table list: {str(e)}")
                tables = []
            
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Database Viewer - {viewer.database}</title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body {{
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        min-height: 100vh;
                    }}
                    .container {{
                        max-width: 1200px;
                        margin: 0 auto;
                        background: white;
                        border-radius: 10px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        overflow: hidden;
                    }}
                    .header {{
                        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
                        color: white;
                        padding: 30px;
                        text-align: center;
                    }}
                    .header h1 {{
                        margin: 0;
                        font-size: 2.5em;
                        font-weight: 300;
                    }}
                    .connection-info {{
                        background: #ecf0f1;
                        padding: 20px;
                        margin: 20px;
                        border-radius: 8px;
                        border-left: 4px solid #3498db;
                    }}
                    .connection-info h3 {{
                        margin-top: 0;
                        color: #2c3e50;
                    }}
                    .db-link {{
                        color: #3498db;
                        text-decoration: none;
                        font-weight: bold;
                    }}
                    .db-link:hover {{
                        text-decoration: underline;
                    }}
                    .tables-section {{
                        padding: 20px;
                    }}
                    .table-card {{
                        background: #f8f9fa;
                        border: 1px solid #dee2e6;
                        border-radius: 8px;
                        margin-bottom: 20px;
                        overflow: hidden;
                        transition: transform 0.2s, box-shadow 0.2s;
                    }}
                    .table-card:hover {{
                        transform: translateY(-2px);
                        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                    }}
                    .table-header {{
                        background: #6c757d;
                        color: white;
                        padding: 15px 20px;
                        cursor: pointer;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }}
                    .table-header:hover {{
                        background: #5a6268;
                    }}
                    .table-content {{
                        padding: 20px;
                        display: none;
                    }}
                    .table-content.active {{
                        display: block;
                    }}
                    .data-table {{
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 15px;
                        font-size: 14px;
                    }}
                    .data-table th, .data-table td {{
                        border: 1px solid #dee2e6;
                        padding: 8px 12px;
                        text-align: left;
                        word-wrap: break-word;
                        max-width: 200px;
                    }}
                    .data-table th {{
                        background: #495057;
                        color: white;
                        font-weight: 600;
                    }}
                    .data-table tr:nth-child(even) {{
                        background: #f8f9fa;
                    }}
                    .data-table tr:hover {{
                        background: #e9ecef;
                    }}
                    .loading {{
                        text-align: center;
                        padding: 20px;
                        color: #6c757d;
                    }}
                    .error {{
                        color: #dc3545;
                        background: #f8d7da;
                        padding: 15px;
                        border-radius: 5px;
                        margin: 10px 0;
                    }}
                    .stats {{
                        display: flex;
                        gap: 20px;
                        margin-bottom: 20px;
                        flex-wrap: wrap;
                    }}
                    .stat-card {{
                        background: white;
                        padding: 15px;
                        border-radius: 8px;
                        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                        flex: 1;
                        text-align: center;
                        min-width: 150px;
                    }}
                    .stat-number {{
                        font-size: 2em;
                        font-weight: bold;
                        color: #3498db;
                    }}
                    .stat-label {{
                        color: #6c757d;
                        margin-top: 5px;
                    }}
                    .toggle-icon {{
                        transition: transform 0.3s;
                    }}
                    .toggle-icon.rotated {{
                        transform: rotate(180deg);
                    }}
                    @media (max-width: 768px) {{
                        .stats {{
                            flex-direction: column;
                        }}
                        .data-table {{
                            font-size: 12px;
                        }}
                        .data-table th, .data-table td {{
                            padding: 6px 8px;
                        }}
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🔍 Database Data Viewer</h1>
                        <p>Interactive Database Explorer</p>
                    </div>
                    
                    <div class="connection-info">
                        <h3>📊 Database Connection</h3>
                        <p><strong>Database:</strong> {viewer.database}</p>
                        <p><strong>Host:</strong> {viewer.host}:{viewer.port}</p>
                        <p><strong>User:</strong> {viewer.username}</p>
                        <p><strong>Connection String:</strong> 
                            <a href="postgresql://{viewer.username}:{viewer.password}@{viewer.host}:{viewer.port}/{viewer.database}" 
                               class="db-link" target="_blank">
                                postgresql://{viewer.username}@{viewer.host}/{viewer.database}
                            </a>
                        </p>
                    </div>
                    
                    <div class="tables-section">
                        <div class="stats">
                            <div class="stat-card">
                                <div class="stat-number">{len(tables)}</div>
                                <div class="stat-label">Total Tables</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number" id="total-rows">-</div>
                                <div class="stat-label">Total Rows</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number" id="loaded-tables">0</div>
                                <div class="stat-label">Loaded Tables</div>
                            </div>
                        </div>
                        
                        <h2>📋 Database Tables</h2>
                        <p>Click on any table to view its data:</p>
            """
            
            if tables:
                for table in tables:
                    html_content += f"""
                        <div class="table-card">
                            <div class="table-header" onclick="toggleTable('{table}')">
                                <span>📄 {table}</span>
                                <span class="toggle-icon" id="icon-{table}">▼</span>
                            </div>
                            <div class="table-content" id="content-{table}">
                                <div class="loading">Loading data...</div>
                            </div>
                        </div>
                    """
            else:
                html_content += """
                        <div class="error">
                            <h3>No Tables Found</h3>
                            <p>No tables were found in the database or there was an error connecting to the database.</p>
                        </div>
                """
            
            html_content += """
                    </div>
                </div>
                
                <script>
                    let loadedTables = 0;
                    
                    function toggleTable(tableName) {
                        const content = document.getElementById('content-' + tableName);
                        const icon = document.getElementById('icon-' + tableName);
                        
                        if (content.classList.contains('active')) {
                            content.classList.remove('active');
                            icon.classList.remove('rotated');
                        } else {
                            content.classList.add('active');
                            icon.classList.add('rotated');
                            
                            // Load data if not already loaded
                            if (content.querySelector('.loading')) {
                                loadTableData(tableName);
                            }
                        }
                    }
                    
                    function loadTableData(tableName) {
                        const content = document.getElementById('content-' + tableName);
                        
                        fetch('/database-viewer/api/table-data/' + encodeURIComponent(tableName))
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                if (data.error) {
                                    content.innerHTML = '<div class="error">Error: ' + data.error + '</div>';
                                } else {
                                    displayTableData(content, data);
                                    loadedTables++;
                                    document.getElementById('loaded-tables').textContent = loadedTables;
                                }
                            })
                            .catch(error => {
                                content.innerHTML = '<div class="error">Error loading data: ' + error.message + '</div>';
                            });
                    }
                    
                    function displayTableData(container, data) {
                        if (!data.columns || !data.data) {
                            container.innerHTML = '<div class="error">No data available</div>';
                            return;
                        }
                        
                        let html = '<table class="data-table"><thead><tr>';
                        
                        // Headers
                        data.columns.forEach(col => {
                            html += '<th>' + escapeHtml(col.name) + '</th>';
                        });
                        html += '</tr></thead><tbody>';
                        
                        // Data rows
                        data.data.forEach(row => {
                            html += '<tr>';
                            data.columns.forEach(col => {
                                const value = row[col.name] || '';
                                html += '<td>' + (value === null ? '<em>null</em>' : escapeHtml(String(value))) + '</td>';
                            });
                            html += '</tr>';
                        });
                        
                        html += '</tbody></table>';
                        
                        if (data.data.length === 0) {
                            html = '<p><em>No data found in this table.</em></p>';
                        } else {
                            html += '<p><em>Showing ' + data.data.length + ' rows</em></p>';
                        }
                        
                        container.innerHTML = html;
                    }
                    
                    function escapeHtml(text) {
                        const map = {
                            '&': '&amp;',
                            '<': '&lt;',
                            '>': '&gt;',
                            '"': '&quot;',
                            "'": '&#039;'
                        };
                        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
                    }
                    
                    // Load total rows count
                    fetch('/database-viewer/api/stats')
                        .then(response => response.json())
                        .then(data => {
                            if (data.total_rows !== undefined) {
                                document.getElementById('total-rows').textContent = data.total_rows.toLocaleString();
                            }
                        })
                        .catch(error => {
                            console.log('Could not load stats:', error);
                        });
                </script>
            </body>
            </html>
            """
            
            return html_content
            
        except Exception as e:
            _logger.error(f"Error in database viewer page: {str(e)}")
            return f"""
            <html>
            <head>
                <title>Database Viewer - Error</title>
                <meta charset="utf-8">
                <style>
                    body {{ 
                        font-family: Arial, sans-serif; 
                        margin: 40px; 
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }}
                    .error-container {{
                        background: white;
                        padding: 40px;
                        border-radius: 10px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        text-align: center;
                        max-width: 500px;
                    }}
                    .error {{ 
                        color: #dc3545; 
                        background: #f8d7da; 
                        padding: 20px; 
                        border-radius: 5px; 
                        margin: 20px 0;
                    }}
                </style>
            </head>
            <body>
                <div class="error-container">
                    <h1>Database Viewer</h1>
                    <div class="error">
                        <h2>Error Loading Database Viewer</h2>
                        <p>{str(e)}</p>
                    </div>
                </div>
            </body>
            </html>
            """

    @http.route('/database-viewer/api/table-data/<table_name>', type='http', auth='user', methods=['GET'])
    def get_table_data(self, table_name, **kwargs):
        """API endpoint to get table data"""
        try:
            # Check if database.viewer model exists
            if 'database.viewer' not in request.env:
                return Response(json.dumps({'error': 'Module not properly installed'}), 
                              content_type='application/json', status=500)
            
            DatabaseViewer = request.env['database.viewer']
            viewers = DatabaseViewer.search([('active', '=', True)])
            
            if not viewers:
                return Response(json.dumps({'error': 'No active database configuration'}), 
                              content_type='application/json', status=404)
            
            viewer = viewers[0]
            
            # Validate table name
            if not table_name or not re.match(r'^[a-zA-Z0-9_-]+$', table_name):
                return Response(json.dumps({'error': 'Invalid table name'}), 
                              content_type='application/json', status=400)
            
            limit = max(1, min(1000, int(kwargs.get('limit', 50))))
            offset = max(0, int(kwargs.get('offset', 0)))
            
            data = viewer.get_table_data(table_name, limit=limit, offset=offset)
            
            return Response(json.dumps(data), content_type='application/json')
            
        except Exception as e:
            _logger.error(f"Error getting table data for {table_name}: {str(e)}")
            return Response(json.dumps({'error': str(e)}), 
                          content_type='application/json', status=500)

    @http.route('/database-viewer/api/stats', type='http', auth='user', methods=['GET'])
    def get_database_stats(self, **kwargs):
        """API endpoint to get database statistics"""
        try:
            # Check if database.viewer model exists
            if 'database.viewer' not in request.env:
                return Response(json.dumps({'error': 'Module not properly installed'}), 
                              content_type='application/json', status=500)
            
            DatabaseViewer = request.env['database.viewer']
            viewers = DatabaseViewer.search([('active', '=', True)])
            
            if not viewers:
                return Response(json.dumps({'error': 'No active database configuration'}), 
                              content_type='application/json', status=404)
            
            viewer = viewers[0]
            tables = viewer.get_table_list()
            
            total_rows = 0
            for table in tables[:10]:  # Limit to first 10 tables for performance
                try:
                    count = viewer.get_table_count(table)
                    total_rows += count
                except:
                    pass
            
            stats = {
                'total_tables': len(tables),
                'total_rows': total_rows,
                'database_name': viewer.database
            }
            
            return Response(json.dumps(stats), content_type='application/json')
            
        except Exception as e:
            _logger.error(f"Error getting database stats: {str(e)}")
            return Response(json.dumps({'error': str(e)}), 
                          content_type='application/json', status=500) 